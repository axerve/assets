function common() {}

common.variantId = '701644329402M';
common.shippingAddress = {
    firstName: 'John',
    lastName: 'Doe',
    address1: 'Po 10',
    address2: '',
    country: 'TO',
    stateCode: 'IT',
    city: 'Turin',
    postalCode: '10100',
    phone: '3106143376'
};
common.shippingMethodId = '001';
common.billingAddress = {
    firstName: 'John',
    lastName: 'Doe',
    address1: 'Po 10',
    address2: '',
    country: 'IT',
    stateCode: 'CI',
    city: 'Turin',
    postalCode: '10100',
    email: 'qwe@qwe.com',
    phone: '3106143376'
};
common.paymentMethod = {
    id: 'CREDIT_CARD',
    type: 'Visa',
    cardNumber: '4775718800002026',
    cardPlace: 'XXXXXXXXXXXX2026',
    cvc: "123",
    cvcPlace: "XXX",
    expireMonth: "5",
    expireYear: "2027"
};

common.gestpaySandbox = {
    url: "https://sandbox.gestpay.net/Pagam/hiddenIframe.aspx?a={shopLogin}&b={Encrypted}&MerchantUrl={host}/Checkout-Begin"
}

module.exports = common;