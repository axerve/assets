'use strict';

module.exports = {
    payment: require("*/cartridge/scripts/facade/middleware/payment")
};