'use strict';
/**
 * GestPay payment gateway processor
 * Handle:  create paymentinstrument with selected payment gateway
 *
 * Authorize: save order number as transaction id
 */
var gestpayProcessorService = require('*/cartridge/scripts/service/gestpayProcessorService');

function Handle() {
  return gestpayProcessorService.Handle(arguments);
}

function Authorize() {
  return gestpayProcessorService.Authorize(arguments);
}

/**
 * Capture a payment using a credit card. The payment is authorized by using callReadTrxS2S (if fraud prevention is enabled).
 */
function Capture() {
  return gestpayProcessorService.Capture(arguments); 
}

/*
 * Module exports
 */
exports.Handle = Handle;
exports.Authorize = Authorize;
exports.Capture = Capture;
