'use strict';

function Handle(dwBasket, paymentInformation, paymentMethodID, req) {
    var Transaction = require('dw/system/Transaction');
    var PaymentMgr = require('dw/order/PaymentMgr');
    var Logger = require('dw/system/Logger');

    var result = {
        fieldErrors: [],
        serverErrors: [],
        error: false
    };

    var dwPaymentInstrument = null;

    var paymentProcessor = PaymentMgr.getPaymentMethod(paymentInformation.paymentMethod.value).getPaymentProcessor();

    Transaction.wrap(function () {
        dwBasket.removeAllPaymentInstruments();

        dwPaymentInstrument = dwBasket.createPaymentInstrument(paymentInformation.paymentMethod.value, dwBasket.totalGrossPrice);
        dwPaymentInstrument.paymentTransaction.paymentProcessor = paymentProcessor;
    });

    Logger.info("Gestpay_payByLink - PaymentMethodID: " + paymentInformation.paymentMethodID + " - on Basket: " + dwBasket.UUID + " with amount: " + paymentInformation.amount);

    return result;
}

function Authorize(orderNo, dwOrderPaymentInstrument, dwPaymentProcessor, orderToken, dwOrder) {
    var OrderMgr = require('dw/order/OrderMgr');
    var Transaction = require('dw/system/Transaction');
    var PaymentInstrument = require('dw/order/PaymentInstrument');

    var gestpayFacade = require("*/cartridge/scripts/facade/gestpayFacade");
    var payByLinkSettings = require("*/cartridge/scripts/utils/payByLinkSettings");

    if (!dwOrder) {
        dwOrder = OrderMgr.getOrder(orderNo, orderToken);
    }

    var result = gestpayFacade.payment.create(orderNo, dwOrder.orderToken, dwOrder.customerEmail, dwOrder.customerName, dwOrderPaymentInstrument.paymentTransaction.amount.value, dwOrderPaymentInstrument.paymentTransaction.amount.currencyCode);

    Transaction.wrap(function () {
        dwOrderPaymentInstrument.paymentTransaction.custom.gestPayPaymentID = result.paymentID;
        dwOrderPaymentInstrument.paymentTransaction.custom.gestPayCreatePaymentRequest = result.request;
        dwOrderPaymentInstrument.paymentTransaction.custom.gestPayCreatePaymentResponse = result.response;
        dwOrderPaymentInstrument.custom.gestPayTransactionResult = "XX";
        dwOrderPaymentInstrument.custom.gestPayShopLogin = payByLinkSettings.getShopLogin();

        dwOrder.trackOrderChange("PayByLink-Authorize - Request: " + result.request);
        dwOrder.trackOrderChange("PayByLink-Authorize - Response: " + result.response);
    });

    return result;
}

function Capture() {}

module.exports = {
    Handle: Handle,
    Authorize: Authorize,
    Capture: Capture
};