'use strict';

function createPayment(orderNo, orderToken, buyerEmail, buyerName, amount, currencyCode, shopLogion, apiKey, type) {
    var Logger = require('dw/system/Logger');

    var PaymentCreateRequest = require("*/cartridge/scripts/lib/payment/create/paymentCreateRequest");
    var PaymentCreateService = require("*/cartridge/scripts/service/payment/create/paymentCreateService");

    var result = {
        error: true,
        paymentID: null,
        request: null,
        response: null,
        errorMessage: null
    };

    try {
        var paymentCreateRequest = new PaymentCreateRequest(orderNo, orderToken, buyerEmail, buyerName, amount, currencyCode, shopLogion, apiKey, type);

        var resultService = PaymentCreateService.post(paymentCreateRequest);

        result.request = paymentCreateRequest ? paymentCreateRequest.getBodyStringify() : null;
        result.response = resultService.object ? JSON.stringify(resultService.object) : null;

        if (resultService.ok) {
            result.paymentID = resultService.object.payload.paymentID;

            if (resultService.object.error.code == 0) {
                result.error = false;
            }
        } else {
            result.errorMessage = resultService.errorMessage;
        }

    } catch (e) {
        var error = e;

        Logger.error("[payment.createPayment] - error exception: " + e.errorMessage + " paymentCreateRequest" + JSON.stringify(paymentCreateRequest));
    }

    if (result.error) {
        Logger.error("[payment.createPayment] - " + paymentCreateRequest.getBodyStringify() + " errorMessage: " + result.errorMessage);
    }

    return result;
}

function paymentDetails(transactionID, shopLogin, apiKey, paymentID, type) {
    var Logger = require('dw/system/Logger');

    var PaymentDetailsRequest = require("*/cartridge/scripts/lib/paymentDetailRequest");
    var PaymentDetailsService = require("*/cartridge/scripts/service/payment/details/paymentDetailsService");

    var result = {
        error: true,
        paymentID: null,
        bankTransactionID: null,
        request: null,
        response: null,
        errorMessage: null
    };

    try {
        var paymentDetailsRequest = new PaymentDetailsRequest(transactionID, shopLogin, apiKey, paymentID, type);

        var resultService = PaymentDetailsService.post(paymentDetailsRequest);

        result.request = paymentDetailsRequest ? paymentDetailsRequest.getBodyStringify() : null;
        result.response = resultService.object ? JSON.stringify(resultService.object) : null;

        if (resultService.ok) {
            result.paymentID = resultService.object.payload.paymentID;
            result.bankTransactionID = resultService.object.payload.bankTransactionID;

            if (resultService.object.error.code == 0) {
                result.error = false;
            }
        } else {
            result.errorMessage = resultService.errorMessage;
        }
    } catch (e) {
        var error = e;

        Logger.error("[payment.paymentDetails] - error exception: " + e.errorMessage + " " + JSON.stringify(paymentDetailsRequest));
    }

    if (result.error) {
        Logger.error("[payment.paymentDetails] - " + result.request + " errorMessage: " + result.errorMessage);
    }

    return result;
}

module.exports = {
    create: createPayment,
    details: paymentDetails
};