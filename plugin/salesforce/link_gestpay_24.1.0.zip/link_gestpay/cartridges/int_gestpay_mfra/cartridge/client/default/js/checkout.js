'use strict';

var processInclude = require('base/util');

processInclude(require('./checkout/checkout'));
processInclude(require('./google/googlePay'));