'use strict';

var processInclude = require('base/util');

processInclude(require('./checkout/eventResponse'));