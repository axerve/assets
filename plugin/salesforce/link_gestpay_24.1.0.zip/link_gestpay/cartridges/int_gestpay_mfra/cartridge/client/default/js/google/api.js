async function getConfig() {
    var url = $('.googlepay-attributes').attr('data-config');

    var response = await fetch(url, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    });

    var result = await response.json();

    return result;
}

/**
 * 
 * @param {object} data Object with transaction info
 * @returns {Promise<{
 *  data: {
 *      transactionState: string
 *  }
 * }>}
 */
async function authorizePayment(data) {
    var url = $('.googlepay-attributes').attr('data-authorize');

    var response = await fetch(url, {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    var result = response.json();

    return result
}

async function callPlaceOrder(data) {
    var url = $('.googlepay-attributes').attr('data-placeorder');

    var response = await fetch(url, {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    var result = await response.json();

    return result;
}

/**
 * Provide Google Pay API with a payment amount, currency, and amount status
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/request-objects#TransactionInfo|TransactionInfo}
 * @returns {Promise<any>} transaction info, suitable for use as transactionInfo property of PaymentDataRequest
 */
async function getGoogleTransactionInfo() {
    var url = $('.googlepay-attributes').attr('data-transaction');

    var response = await fetch(url, {
        method: 'GET',
        headers: {
            accept: 'application/json',
            'Content-Type': 'application/json'
        }
    });

    var result = await response.json();

    return result.data;
}

async function getGooglePayDataChange(data) {
    var url = $('.googlepay-attributes').attr('data-change');

    var response = await fetch(url, {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    var result = await response.json();

    return result.data;
}

module.exports = {
    getConfig: getConfig,
    authorizePayment: authorizePayment,
    callPlaceOrder: callPlaceOrder,
    getGoogleTransactionInfo: getGoogleTransactionInfo,
    getGooglePayDataChange: getGooglePayDataChange
}