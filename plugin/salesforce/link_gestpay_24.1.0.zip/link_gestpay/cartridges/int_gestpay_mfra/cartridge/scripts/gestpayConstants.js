'use strict';

module.exports = {
    processors: [
        "GESTPAY_CREDIT",
        "GESTPAY_PAYMENT_GATEWAY",
        "GESTPAY_PAYBYLINK"
    ],
    type: {
        DEFAULT: "DEFAULT",
        PAYBYLINK: "PAYBYLINK"
    },
    services: {
        payment: {
            detail: {
                name: "gestpay.rest.paymentDetails",
                method: "POST"
            },
            create: {
                name: "gestpay.rest.paymentCreate",
                method: "POST"
            }
        }
    }
};