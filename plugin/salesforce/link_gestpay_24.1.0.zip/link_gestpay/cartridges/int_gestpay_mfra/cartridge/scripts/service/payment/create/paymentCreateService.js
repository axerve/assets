'use strict'

module.exports = {
	post: function (paymentCreateRequest) {
		var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

		var GestpayConstants = require("*/cartridge/scripts/gestpayConstants");
		var PaymentCreateServiceCallBack = require('*/cartridge/scripts/service/payment/create/paymentCreateServiceCallBack');

		var service = LocalServiceRegistry.createService(GestpayConstants.services.payment.create.name + "." + GestpayConstants.services.payment.create.method.toLowerCase(), PaymentCreateServiceCallBack.post);

		return service.call(paymentCreateRequest);
	}
};