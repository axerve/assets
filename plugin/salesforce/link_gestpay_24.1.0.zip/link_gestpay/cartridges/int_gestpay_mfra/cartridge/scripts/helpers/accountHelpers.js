'use strict';

var base = module.superModule;

if (!base) {
    base = {};
}

function isOnBehalf() {
    var result = false;

    if (session.userName != "storefront") {
        result = true;
    }

    return result;
}

function disableFilterThisForCustomer() {
    var result = false;

    try {
        if (customer.registered && "showAllPaymentCustomerCare" in customer.profile.custom && customer.profile.custom.showAllPaymentCustomerCare == true) {
            result = true;
        }
    } catch (e) {

    }

    return result;
}

base.isOnBehalf = isOnBehalf;
base.disableFilterThisForCustomer = disableFilterThisForCustomer;

module.exports = base;