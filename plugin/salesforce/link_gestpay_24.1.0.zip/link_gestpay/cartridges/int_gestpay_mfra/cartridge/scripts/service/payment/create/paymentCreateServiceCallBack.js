'use strict';

module.exports = {
	post: {
		createRequest: function (svc, params) {
			svc.setRequestMethod(params.getMethod());
			svc.setURL(params.getUrl());

			var headers = params.getHeaders();
			var headersKeys = headers.keySet().iterator();

			while (headersKeys.hasNext()) {
				var key = headersKeys.next();
				svc.addHeader(key, headers[key]);
			}

			return params.getBodyStringify();
		},
		parseResponse: function (svc, response) {
			var res = JSON.parse(response.text)

			return res;
		},
		filterLogMessage: function (msg) {
			return msg;
		}
	}
};