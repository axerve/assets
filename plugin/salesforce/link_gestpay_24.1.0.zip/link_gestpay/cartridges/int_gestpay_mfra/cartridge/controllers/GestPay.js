'use strict';

/**
 * This controller implements encrypt, 3d secure callback, s2s notifications and
 * payment gateway response
 */
var utils = require('int_gestpay/cartridge/scripts/utils/utils');
var log = utils.getLogger();
var settings = require('int_gestpay/cartridge/scripts/utils/settings');

var OrderMgr = require('dw/order/OrderMgr');
var Site = require('dw/system/Site');

var server = require('server');

const currentSiteId = dw.system.Site.getCurrent().getID();

/**
 * Encrypt is the main entrypoint for Gestpay. You must call Encrypt either if
 * you want to use the standard payment page, or the custom iframe solution.
 */
server.get('Encrypt', server.middleware.https, function (req, res, next) {
	var result = {};
	var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	var isS2s = req.querystring.savedcard === 'true';
	var saveCard = session.forms.billing.creditCardFields.saveCard.value === true;
	try {
		var paymentMethod = request.httpParameterMap.dwfrm_billing_paymentMethod.submitted ? request.httpParameterMap.dwfrm_billing_paymentMethod.stringValue : '';
		var myBankListValue = null;

		if (paymentMethod == "MYBANK") {
			myBankListValue = request.httpParameterMap.dwfrm_billing_myBank_myBankList.stringValue;
		}

		var hookName = 'app.payment.extension.GESTPAY_' + paymentMethod.toUpperCase();
		if (dw.system.HookMgr.hasHook(hookName)) {
			dw.system.HookMgr.callHook(hookName, 'PreEncrypt', {
				Basket: dw.order.BasketMgr.getCurrentBasket()
			});
		}
		var encrypt = cryptDecrypt.encryptByCurrentBasket(settings.selectShopLogin(isS2s), saveCard, myBankListValue).getObject();
		encrypt.shopLogin = settings.selectShopLogin(isS2s);
		session.privacy.shopLogin = encrypt.shopLogin;
		result = encrypt;
		log.info('[GestPay.Encrypt] Site {0}, encrypt result: {1}', currentSiteId, JSON.stringify(result));
	} catch (e) {
		var error = e;
		log.error(error);
		res.json({
			success: false,
			error: error
		});
	}
	res.json(result);
	return next();
});

/**
 * Encrypt is the main entrypoint for Gestpay. You must call Encrypt either if
 * you want to use the standard payment page, or the custom iframe solution.
 */
server.get('AmazonPayCart', server.middleware.https, function (req, res, next) {
	var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	var error = null;
	var order = null;
	try {
		const gestpayAmazonUtils = require('*/cartridge/scripts/payment/extension/GESTPAY_AMAZONPAY');

		var basket = dw.order.BasketMgr.getCurrentBasket();
		if (basket) {
			// @ts-ignore
			gestpayAmazonUtils.preEncrypt({
				Basket: basket
			});
			var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
			order = COHelpers.createOrder(basket);

			if (order) {
				var result = cryptDecrypt.encryptByOrderPaymentInstrument(order.paymentInstruments[0], order, false).getObject();

				if (result.errorCode == 0) {
					var shopLogin = settings.getShopLogin();
					res.redirect(settings.gestPayPagamPageUrl() + '?a=' + shopLogin + '&b=' + result.cryptDecryptString);
					log.info('[GestPay.AmazonPayCart] Encrypt result: {0}', JSON.stringify(result));

					return next();
				}

				error = result.errorCode;
			} else {
				error = 'createorder';
			}
		} else {
			error = 'nocart';
		}
	} catch (e) {
		log.error('[GestPay.AmazonPayCart] Error result: {0}', error);
	}
	if (order && !dw.order.BasketMgr.getCurrentBasket()) {
		dw.order.OrderMgr.failOrder(order, true);
	}
	// there is an error, go back to cart
	res.redirect(dw.web.URLUtils.url('Cart-Show', 'paymentGatewayResponseError', true, 'message', dw.web.Resource.msg('gestpay.checkout.error.' + error, 'checkout', dw.web.Resource.msgf('gestpay.checkout.default', 'checkout', 'Error'))));
	return next();
});

/**
 * 3d secure callback
 */
server.use('GestPay3dSecureCallback', server.middleware.https, function (req, res, next) {
	var order;
	var token;
	var URLUtils = require('dw/web/URLUtils');
	var OrderMgr = require('dw/order/OrderMgr');
	var Transaction = require('dw/system/Transaction');
	var redirectUrl = 'Cart-Show';
	var redirectParamsGenericError = ['paymentGatewayResponseError', true];
	var redirectErrorUrl = URLUtils.url(redirectUrl, redirectParamsGenericError);
	try {
		order = OrderMgr.getOrder(req.querystring.orderId, req.querystring.orderToken);
		token = req.querystring.orderToken ? req.querystring.orderToken : null;
		if (!order || !token || token !== order.orderToken) {
			res.redirect(redirectErrorUrl);
		} else {
			Transaction.wrap(function () {
				order.trackOrderChange("Start GestPay3dSecureCallback, render gestpay-3dsecuretemplate");
			});
			var paymentInstrument = order.getPaymentInstruments().toArray().filter(function (paymentInstrumentTemp) {
				return paymentInstrumentTemp.paymentTransaction.custom.gestPayTransKey == req.querystring.transKey;
			})[0];
			res.render('checkout/billing/gestpay-3dsecure', {
				gestpayApiJs: settings.getJsGestPay(),
				redirectErrorUrl: redirectErrorUrl,
				orderId: req.querystring.orderId,
				orderToken: req.querystring.orderToken,
				shopLogin: paymentInstrument.custom.gestPayShopLogin,
				PaRes: req.form.PaRes || req.form.pares,
				transKey: paymentInstrument.paymentTransaction.custom.gestPayTransKey,
				cryptDecryptString: JSON.parse(paymentInstrument.getPaymentTransaction().getCustom().gestPayEncryptResult).cryptDecryptString
			});
		}
	} catch (e) {
		var error = e;
		log.error(error);
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange("GestPay3dSecureCallback error: " + e);
				OrderMgr.failOrder(order);
			});
		}
		res.redirect(redirectErrorUrl);
	}
	return next();
});

server.post('CheckIFrameCreation3dSecure', server.middleware.https, function (req, res, next) {
	var result = {};
	var order;
	var token;
	var OrderMgr = require('dw/order/OrderMgr');
	var Transaction = require('dw/system/Transaction');
	try {
		order = OrderMgr.getOrder(req.form.orderId, req.form.orderToken);
		token = req.form.orderToken ? req.form.orderToken : null;
		if (!order || !token || token !== order.orderToken) {
			result.error = true
		} else {
			Transaction.wrap(function () {
				order.trackOrderChange("Start CheckIFrameCreation3dSecure, iframe creation result: " + JSON.stringify(req.form));
			});
			if (req.form.ErrorCode == 10) {
				result.error = false;
			} else {
				result.error = true;
				Transaction.wrap(function () {
					order.trackOrderChange("CheckIFrameCreation3dSecure error, fail order");
					OrderMgr.failOrder(order);
				});
			}
		}
	} catch (e) {
		var error = e;
		log.error(error);
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange("IFrame3dSecureResponse error: " + e);
				OrderMgr.failOrder(order);
			});
		}
	} finally {
		res.json(result);
	}
	return next();
});

server.post('IFrame3dSecureSendResponse', server.middleware.https, function (req, res, next) {
	var result = {
		error: true
	};

	var order;
	var token;
	var URLUtils = require('dw/web/URLUtils');
	var OrderMgr = require('dw/order/OrderMgr');
	var Transaction = require('dw/system/Transaction');
	var gestpayService = require('*/cartridge/scripts/service/gestpayService');

	var version = Site.current.preferences.custom.GestPayCompatibilityVersion.value;

	try {
		order = OrderMgr.getOrder(req.form.orderId, req.form.orderToken);
		token = req.form.orderToken ? req.form.orderToken : null;

		if (order && token && token === order.orderToken) {
			Transaction.wrap(function () {
				order.trackOrderChange("Start IFrame3dSecureResponse, iframe send result: " + JSON.stringify(req.form));
			});

			if (req.form.ErrorCode == settings.getGestPayWsSuccessCode()) {
				result = gestpayService.placeOrderByCryptDecryptString(req.form.EncryptedString || req.form.cryptDecryptString, req, res);

				if (!result.error) {

					if (version == 6) {
						result.redirectUrl = URLUtils.url('Order-Confirm').toString();
					} else if (version == 5) {
						result.redirectUrl = URLUtils.url('Order-Confirm', 'ID', req.form.orderId, 'token', req.form.orderToken).toString();
					}

					result.version = version;

					log.info('GestPay.js redirectUrl is ' + result.redirectUrl);
				}
			} else {
				Transaction.wrap(function () {
					order.trackOrderChange("IFrame3dSecureResponse error, fail order");
					OrderMgr.failOrder(order);
				});
			}
		}
	} catch (e) {
		var error = e;

		log.error(error);

		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange("IFrame3dSecureResponse error: " + e);
				OrderMgr.failOrder(order);
			});
		}
	} finally {

		if (result.error && !result.errorMessage) {
			result.errorMessage = dw.web.Resource.msgf('gestpay.checkout.error', 'checkout', null);
		}

		if (result.errorMessage && !result.redirectUrl) {
			result.redirectUrl = URLUtils.url('Cart-Show', 'paymentGatewayResponseError', true, 'message', result.errorMessage).toString();
		}

		res.json(result);
	}
	return next();
});

server.use('PaymentGatewayResponse', server.middleware.https, function (req, res, next) {
	var URLUtils = require('dw/web/URLUtils');
	var gestpayService = require('*/cartridge/scripts/service/gestpayService');
	var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	var cryptDecryptString = req.querystring.b;
	var decrypt = cryptDecrypt.decrypt(cryptDecryptString, null).getObject();
	var infoMap = settings.convertCustomInfoToMap(decrypt.customInfo);
	var sentRedirectSiteId = infoMap.get('SITE');
	var sentRedirectLocale = infoMap.get('LOCALE') || dw.system.Site.getCurrent().getDefaultLocale();
	var currentLocale = req.locale.id;

	if (sentRedirectSiteId && (currentSiteId != sentRedirectSiteId || currentLocale != sentRedirectLocale)) {
		var redirectURL = URLUtils.url(new dw.web.URLAction('GestPay-PaymentGatewayResponse', sentRedirectSiteId, sentRedirectLocale)).toString() + '?' + req.querystring;
		res.redirect(redirectURL);
		return next();
	}

	var version = Site.current.preferences.custom.GestPayCompatibilityVersion.value;
	var error = false;
	var result = {};

	var redirectUrl = 'Cart-Show';
	var redirectParams = [];
	var redirectParamsGenericError = ['paymentGatewayResponseError', true];
	try {
		var placeOrderResult = gestpayService.placeOrderByCryptDecryptString(req.querystring.b, req, res);

		if (placeOrderResult.Order) {
			placeOrderResult.orderID = placeOrderResult.Order.orderNo;
			placeOrderResult.orderToken = placeOrderResult.Order.orderToken;
		}

		if (!placeOrderResult.error) {

			if (version == 6) {
				if (placeOrderResult.Order.status != 8) {
					result.redirectUrl = URLUtils.url('Order-Confirm').toString();
					result.orderId = placeOrderResult.orderID;
					result.orderToken = placeOrderResult.orderToken;
				} else {
					error = true;
					result.redirectUrl = URLUtils.url('Checkout-Begin').toString();
				}
			} else if (version == 5) {
				redirectParams = ['ID', placeOrderResult.orderID, 'token', dw.crypto.Encoding.toURI(placeOrderResult.orderToken)];
				redirectUrl = 'Order-Confirm';
			}

		} else {
			error = true;
			redirectParams = redirectParamsGenericError;
			redirectParams = redirectParams.concat('code', placeOrderResult.errorCode, 'message', placeOrderResult.errorMessage);
		}
	} catch (e) {
		redirectParams = redirectParamsGenericError;
		log.error(e);
	} finally {
		if (error) {
			res.redirect(URLUtils.url(redirectUrl, redirectParams));
		} else {
			if (version == 6) {
				res.render("checkout/billing/gestpayGatewayResponse", {
					result: result
				});
			} else if (version == 5) {
				res.redirect(URLUtils.url(redirectUrl, redirectParams));
			}
		}
	}
	return next();
});

server.use('S2S', server.middleware.https, function (req, res, next) {
	var message = '';
	try {
		var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
		var Transaction = require('dw/system/Transaction');
		var StringUtils = require('dw/util/StringUtils');
		var Calendar = require('dw/util/Calendar');
		var CustomObjectMgr = require('dw/object/CustomObjectMgr');
		var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

		log.info("Gestpay S2S called with params");

		if (req.querystring.a && req.querystring.b) {
			// get parameter map values
			var requestShopLogin = req.querystring.a;
			var requestCryptDecryptString = req.querystring.b;
			var decryptNotificationResult = cryptDecrypt.decryptNotificationS2S(requestCryptDecryptString, requestShopLogin).getObject();

			var infoMap = settings.convertCustomInfoToMap(decryptNotificationResult.customInfo);
			var notificationSiteId = infoMap.get('SITE');
			var orderToken = infoMap.get("ORDER_TOKEN");

			Transaction.wrap(function () {
				// create custom object
				var keyValue = settings.selectShopLogin(true) + '-' + StringUtils.formatCalendar(new Calendar(), 'yyyyMMddhhmmssSSS');
				var decryptNotificationResultStringify = JSON.stringify(decryptNotificationResult);

				if (decryptNotificationResult && decryptNotificationResult.shopTransactionID) {
					// save with order number
					keyValue = decryptNotificationResult.shopTransactionID + '-' + StringUtils.formatCalendar(new Calendar(), 'yyyyMMddhhmmssSSS');
				}

				var customObj = CustomObjectMgr.createCustomObject('gestpayNotification', keyValue);
				customObj.custom.requestShopLogin = requestShopLogin;
				customObj.custom.requestCryptDecryptString = requestCryptDecryptString;
				customObj.custom.status = "PROCESS";
				customObj.custom.notificationSiteId = notificationSiteId;
				customObj.custom.decryptNotificationResult = decryptNotificationResultStringify;
				log.info('Gestpay - s2s - save notification (' + keyValue + ') from banca sella, decryptNotificationResult: ' + decryptNotificationResultStringify);

				var order = OrderMgr.getOrder(decryptNotificationResult.shopTransactionID, orderToken);
				var paymentsXX = ["S2PGIR", "S2PIDE", "S2PUNI", "SATISPAY", "MYBANK"];

				if (order.status == dw.order.Order.ORDER_STATUS_CREATED && paymentsXX.indexOf(order.paymentInstrument.paymentMethod) >= 0) {
					if (decryptNotificationResult.transactionResult == 'OK') {
						OrderMgr.placeOrder(order);

						COHelpers.sendConfirmationEmail(order, req.locale.id);
					} else if (decryptNotificationResult.transactionResult == 'K0') {
						order.status == dw.order.Order.ORDER_STATUS_FAILED;
					}
				}
			});

			message = "{notificationCreated}"
		} else {
			message = "{error: shop login or cryptDecryptString not found in httpParameters}";
			log.error(message);
		}
	} catch (e) {
		var error = e;
		log.error(error);
	}
	res.json(message);
	return next();
});

server.post('GestPay3dSecureResponse', server.middleware.https, function (req, res, next) {
	var URLUtils = require('dw/web/URLUtils');
	var gestpayService = require('*/cartridge/scripts/service/gestpayService');
	var redirectUrl = 'Cart-Show';

	var version = Site.current.preferences.custom.GestPayCompatibilityVersion.value;
	var error = false;
	var result = {};

	var redirectParams = [];
	var redirectParamsGenericError = ['paymentGatewayResponseError', true];
	try {
		var placeOrderResult = gestpayService.placeOrderBy3dSecureResponse(req.querystring.transKey, req.form.PaRes || req.form.pares, req.querystring.orderNo, req.querystring.orderToken, req);

		if (!placeOrderResult.error) {

			redirectParams = ['ID', placeOrderResult.orderID, 'token', dw.crypto.Encoding.toURI(placeOrderResult.orderToken)];
			redirectUrl = 'Order-Confirm';

			if (version == 6) {
				result.redirectUrl = URLUtils.url('Order-Confirm').toString();
				result.orderId = placeOrderResult.orderID;
				result.orderToken = placeOrderResult.orderToken;
			} else if (version == 5) {
				redirectParams = ['ID', placeOrderResult.orderID, 'token', dw.crypto.Encoding.toURI(placeOrderResult.orderToken)];
				redirectUrl = 'Order-Confirm';
			}
		} else {
			error = true
			redirectParams = redirectParamsGenericError;
		}
	} catch (e) {
		redirectParams = redirectParamsGenericError;
		log.error(e);
	} finally {

		if (error) {
			res.redirect(URLUtils.url(redirectUrl, redirectParams));
		} else {
			if (version == 6) {
				res.render("checkout/billing/gestpayGatewayResponse", {
					result: result
				});
			} else if (version == 5) {
				res.redirect(URLUtils.url(redirectUrl, redirectParams));
			}
		}
	}
	return next()
});

server.get('ShowBankList', server.middleware.https, function (req, res, next) {
	var gestpay = require('*/cartridge/scripts/gestpay');
	var orderUtils = require('*/cartridge/scripts/utils/orderUtils');
	var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

	var paymentMethodID = req.querystring.paymentMethodID;

	var bankListForm = COHelpers.prepareBankListForm();
	var resultService = null;

	if (paymentMethodID == "MYBANK") {
		resultService = gestpay.callMyBankListS2S(orderUtils.getMyBankListBody());
	} else if (paymentMethodID == "S2PIDE") {
		resultService = gestpay.callIdealListS2S(orderUtils.getMyBankListBody());
	}

	var result = {
		success: false,
		bankListForm: bankListForm,
		banks: null
	}

	if (resultService && resultService.ok) {
		result.success = true;
		result.banks = resultService.object.banks;
	}

	res.render('checkout/billing/paymentOptions/bankContent', result);

	next();
});

server.get('GooglePayData', function (req, res, next) {
	var Money = require('dw/value/Money');
	var BasketMgr = require('dw/order/BasketMgr');
	var Locale = require('dw/util/Locale');

	var result = {};

	var dwBasket = BasketMgr.getCurrentBasket();

	if (dwBasket) {
		result = {
			data: {
				displayItems: [{
						label: "Subtotal",
						type: "SUBTOTAL",
						price: dwBasket.totalNetPrice.valueOrNull.toString()
					},
					{
						label: "Tax",
						type: "TAX",
						price: dwBasket.totalTax.valueOrNull.toString()
					}
				],
				countryCode: Locale.getLocale(request.locale).getCountry(),
				currencyCode: dwBasket.getCurrencyCode(),
				totalPriceStatus: "FINAL",
				totalPrice: dwBasket.totalGrossPrice.valueOrNull.toString(),
				totalPriceLabel: "Total"
			}
		};
	}

	res.json(result);

	return next();
});

server.get('GooglePayConfig', function (req, res, next) {
	var settings = require('*/cartridge/scripts/utils/settings');
	var Locale = require('dw/util/Locale');
	var Site = require('dw/system/Site');

	var isTest = Site.current.preferences.custom.GestPayGooglePayTestMode;
	var googleMerchantName = !empty(Site.current.preferences.custom.GestPayGooglePayMerchantName) ? Site.current.preferences.custom.GestPayGooglePayMerchantName : 'Axerve';
	var googlePayMerchantID = !empty(Site.current.preferences.custom.GestPayGooglePayMerchantID) ? Site.current.preferences.custom.GestPayGooglePayMerchantID : settings.getShopLogin();

	var countryCode = Locale.getLocale(request.locale).getCountry();
	var result = {
		isExpress: (request.getHttpReferer().toLowerCase().indexOf('checkout') >= 0) ? false : true,
		isTest: isTest,
		data: {
			apiVersion: 2,
			apiVersionMinor: 0,
			allowedPaymentMethods: [{
				type: "CARD",
				parameters: {
					allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
					allowedCardNetworks: ["AMEX", "DISCOVER", "INTERAC", "JCB", "MASTERCARD", "VISA"]
				},
				tokenizationSpecification: {
					type: "PAYMENT_GATEWAY",
					parameters: {
						gateway: "gestpay",
						gatewayMerchantId: settings.getShopLogin()
					}
				}
			}],
			shippingAddressParameters: {
				"phoneNumberRequired": true
			},
			merchantInfo: {
				merchantId: googlePayMerchantID,
				merchantName: googleMerchantName
			}
		}
	};

	res.json(result);

	return next();
});

server.post('GooglePayDataChange', function (req, res, next) {
	var Locale = require('dw/util/Locale');
	var BasketMgr = require('dw/order/BasketMgr');
	var ShippingMgr = require('dw/order/ShippingMgr');
	var Transaction = require('dw/system/Transaction');

	var dataChange = JSON.parse(req.body);
	var dwBasket = BasketMgr.getCurrentOrNewBasket();

	var result = null;
	var data = {};

	var dwShippingModel = ShippingMgr.getShipmentShippingModel(dwBasket.defaultShipment);
	var dwApplicableShippingMethods = dwShippingModel.applicableShippingMethods;

	Transaction.wrap(function () {
		if (dataChange.shippingAddress) {
			var shippingAddress = dwBasket.defaultShipment.shippingAddress;

			if (!shippingAddress) {
				shippingAddress = dwBasket.defaultShipment.createShippingAddress();
			}

			shippingAddress.city = dataChange.shippingAddress.locality;
			shippingAddress.stateCode = dataChange.shippingAddress.administrativeArea;
			shippingAddress.postalCode = dataChange.shippingAddress.postalCode;
			shippingAddress.countryCode = dataChange.shippingAddress.countryCode;
		}

		if (dataChange.shippingOptionData) {
			var dwShippingMethod = null;

			for (var i = 0; i < dwApplicableShippingMethods.length && !dwShippingMethod; i++) {
				if (dwApplicableShippingMethods[i].ID == dataChange.shippingOptionData.id) {
					dwShippingMethod = dwApplicableShippingMethods[i];
				}
			}

			if (!dwShippingMethod) {
				dwShippingMethod = dwApplicableShippingMethods.length > 0 ? dwApplicableShippingMethods[0] : null;
			}
			dwBasket.defaultShipment.shippingMethod = dwShippingMethod;
		}

		dw.system.HookMgr.callHook('dw.order.calculateTax', 'calculateTax', dwBasket);

		var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

		basketCalculationHelpers.calculateTotals(dwBasket);
	});

	var countryCode = Locale.getLocale(request.locale).getCountry();

	data = {
		newTransactionInfo: {
			displayItems: [{
					label: 'Subtotal',
					type: 'SUBTOTAL',
					price: dwBasket.totalGrossPrice.value.toString(),
				},
				{
					label: 'Shipping',
					type: 'SHIPPING_OPTION',
					price: dwBasket.shippingTotalPrice.value.toString(),
				},
			],
			currencyCode: dwBasket.currencyCode,
			countryCode: countryCode,
			totalPriceStatus: 'FINAL',
			totalPrice: dwBasket.totalGrossPrice.value.toString(),
			totalPriceLabel: 'Total'
		}
	};

	if (dwShippingModel) {
		var dwApplicableShippingMethods = dwShippingModel.applicableShippingMethods;

		if (dwApplicableShippingMethods && dwApplicableShippingMethods.length > 0) {
			data.newShippingOptionParameters = {
				defaultSelectedOptionId: dwBasket.defaultShipment.shippingMethodID,
				shippingOptions: []
			};

			for (var i = 0; i < dwApplicableShippingMethods.length; i++) {
				var shippingMethod = dwApplicableShippingMethods[i];

				data.newShippingOptionParameters.shippingOptions.push({
					id: shippingMethod.ID,
					label: shippingMethod.displayName + ' ' + dwShippingModel.getShippingCost(shippingMethod).amount.toFormattedString(),
					description: shippingMethod.custom.estimatedArrivalTime || '-'
				});
			}
		}
	}

	if (data) {
		result = {
			data: data
		};
	}

	res.json(result);

	return next();
});

server.post("GooglePayAuthorize", function (req, res, next) {
	var HookMgr = require('dw/system/HookMgr');
	var BasketMgr = require('dw/order/BasketMgr');
	var PaymentMgr = require('dw/order/PaymentMgr');
	var ShippingMgr = require('dw/order/ShippingMgr');
	var Transaction = require('dw/system/Transaction');

	var settings = require('*/cartridge/scripts/utils/settings');

	var dataAuth = JSON.parse(req.body);

	var dwBasket = BasketMgr.getCurrentOrNewBasket();
	var dwShippingModel = ShippingMgr.getShipmentShippingModel(dwBasket.defaultShipment);
	var dwApplicableShippingMethods = dwShippingModel.applicableShippingMethods;

	var result = {};

	var processor = PaymentMgr.getPaymentMethod("GOOGLE_PAY").getPaymentProcessor();

	var isExpress = (request.getHttpReferer().toLowerCase().indexOf('checkout') >= 0) ? false : true;

	Transaction.wrap(function () {
		if (isExpress) {
			dwBasket.customerEmail = dataAuth.email;

			if (dataAuth.shippingAddress) {
				var shippingAddress = dwBasket.defaultShipment.shippingAddress;

				if (shippingAddress === null) {
					shippingAddress = dwBasket.defaultShipment.createShippingAddress();
				}

				shippingAddress.city = dataAuth.shippingAddress.locality;
				shippingAddress.stateCode = dataAuth.shippingAddress.administrativeArea;
				shippingAddress.postalCode = dataAuth.shippingAddress.postalCode;
				shippingAddress.countryCode = dataAuth.shippingAddress.countryCode;

				var name = dataAuth.shippingAddress.name;
				var lastname = dataAuth.shippingAddress.name;

				if (name.indexOf(' ')) {
					lastname = name.substr(name.indexOf(' ')).trim();
					name = name.substr(0, name.indexOf(' ')).trim();
				}

				shippingAddress.firstName = name || '-';
				shippingAddress.lastName = lastname || '-';
				shippingAddress.address1 = dataAuth.shippingAddress.address1;
				shippingAddress.address2 = dataAuth.shippingAddress.address2;

				var phone = dataAuth.shippingAddress.phoneNumber || ' ';

				shippingAddress.phone = phone.substr(phone.indexOf(' ')).replace(/ /g, '');

				if (!dwBasket.billingAddress) {
					dwBasket.createBillingAddress();
				}

				dwBasket.billingAddress.address1 = shippingAddress.address1;
				dwBasket.billingAddress.address2 = shippingAddress.address2;
				dwBasket.billingAddress.firstName = shippingAddress.firstName;
				dwBasket.billingAddress.lastName = shippingAddress.lastName;
				dwBasket.billingAddress.city = shippingAddress.city;
				dwBasket.billingAddress.stateCode = shippingAddress.stateCode;
				dwBasket.billingAddress.postalCode = shippingAddress.postalCode;
				dwBasket.billingAddress.countryCode = shippingAddress.countryCode;
				dwBasket.billingAddress.phone = shippingAddress.phone;
			}

			if (dataAuth.shippingOptionData) {
				var dwShippingMethod = null;

				for (var i = 0; i < dwApplicableShippingMethods.length && !dwShippingMethod; i++) {
					if (dwApplicableShippingMethods[i].ID == dataAuth.shippingOptionData.id) {
						dwShippingMethod = dwApplicableShippingMethods[i];
					}
				}

				if (dwShippingMethod) {
					dwBasket.defaultShipment.shippingMethod = dwShippingMethod;
				}
			}

			var billingData = {
				paymentMethod: {
					value: "GOOGLE_PAY"
				},
				paymentInformation: {
					amount: dwBasket.totalGrossPrice
				},
				paymentProcessor: processor,
				googlePayToken: dataAuth && dataAuth.paymentMethodData && dataAuth.paymentMethodData.tokenizationData && dataAuth.paymentMethodData.tokenizationData.token ? dataAuth.paymentMethodData.tokenizationData.token : null,
				extraPaymentInfo: {
					shopLogin: settings.getShopLogin()
				}
			};

			if (HookMgr.hasHook('app.payment.processor.' + processor.ID.toLowerCase())) {
				result = HookMgr.callHook('app.payment.processor.' + processor.ID.toLowerCase(), 'Handle', dwBasket, billingData);
			} else {
				result = HookMgr.callHook('app.payment.processor.default', 'Handle');
			}
		} else {
			if (dataAuth && dataAuth.paymentMethodData && dataAuth.paymentMethodData.tokenizationData && dataAuth.paymentMethodData.tokenizationData.token) {
				session.privacy.googlePayToken = dataAuth.paymentMethodData.tokenizationData.token;
			}
		}
	});

	res.json({
		data: {
			transactionState: 'SUCCESS'
		}
	});

	res.json(result);

	return next();
});

server.get('PayByLinkResult', server.middleware.https, function (req, res, next) {
	var OrderMgr = require('dw/order/OrderMgr');
	var Transaction = require('dw/system/Transaction');
	var URLUtils = require('dw/web/URLUtils');
	var Resource = require('dw/web/Resource');

	var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
	var paymentHelpers = require('*/cartridge/scripts/helpers/payment/paymentHelpers');

	var GestpayConstants = require("*/cartridge/scripts/gestpayConstants");
	var gestpayFacade = require("*/cartridge/scripts/facade/gestpayFacade");

	var result = {
		error: true,
		errorMessage: null
	}

	var orderNo = req.querystring.orderNo;
	var orderToken = req.querystring.orderToken;

	var shopLogin = req.querystring.a;
	var paymentID = req.querystring.paymentID;
	var bankTransactionID = null;
	var paymentToken = req.querystring.paymentToken;
	var gestPayPaymentMethod = null;
	var status = null;

	var dwOrder = OrderMgr.getOrder(orderNo, orderToken);

	//var capturedLoyalty = false;

	var dwPaymentInstrument = paymentHelpers.getPayByLinkPaymentInstrument(dwOrder);

	if (orderNo && orderToken) {
		res.render('/error', {
			message: Resource.msg('error.confirmation.error', 'confirmation', null)
		});
	} else {
		res.redirect(URLUtils.url("Home-Show"));
	}

	if (dwOrder && dwPaymentInstrument) {
		var result = gestpayFacade.payment.details(null, null, null, paymentID, GestpayConstants.type.PAYBYLINK);

		var responseDetails = JSON.parse(result.response);

		if (responseDetails && responseDetails.payload) {
			if (responseDetails.payload.transactionResult == "APPROVED" || responseDetails.payload.transactionResult == "OK") {
				status = "OK";

				bankTransactionID = responseDetails.payload.bankTransactionID;
				gestPayPaymentMethod = responseDetails.payload.paymentMethod;
			} else if (responseDetails.payload.transactionResult == "DECLINED" || responseDetails.payload.transactionResult == "KO") {
				status = "KO";

				bankTransactionID = result.payload.bankTransactionID;
				gestPayPaymentMethod = responseDetails.payload.paymentMethod;
			}
		}

		if (status == "OK") {
			Transaction.wrap(function () {
				OrderMgr.placeOrder(dwOrder);

				dwPaymentInstrument.custom.gestPayTransactionResult = "OK";
				dwPaymentInstrument.custom.gestPayPaymentMethod = gestPayPaymentMethod;
				dwPaymentInstrument.paymentTransaction.transactionID = result.bankTransactionID;
			});

			COHelpers.sendConfirmationEmail(dwOrder, req.locale.id);

			res.render("checkout/billing/gestpayGatewayResponse", {
				result: {
					orderId: orderNo,
					orderToken: orderToken
				}
			});
		} else if (status == "KO") {
			Transaction.wrap(function () {
				OrderMgr.failOrder(dwOrder, true);

				dwPaymentInstrument.custom.gestPayTransactionResult = "KO";
			});

			res.redirect(URLUtils.url("Cart-Show"));
		}
	}

	next();
});

module.exports = server.exports();