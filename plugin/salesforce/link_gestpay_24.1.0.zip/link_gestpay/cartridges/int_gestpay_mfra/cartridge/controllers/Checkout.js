'use strict';

var page = module.superModule;
var server = require('server');

server.append('Begin', function (req, res, next) {
	var BasketMgr = require('dw/order/BasketMgr');

	var settings = require('int_gestpay/cartridge/scripts/utils/settings');
	var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

	const assets = require('*/cartridge/scripts/assets');

	assets.addJs('https://sandbox.gestpay.net/pagam/javascript/TLSCHK_TE.js');
	assets.addJs('https://ecomm.sella.it/pagam/javascript/TLSCHK_PRO.js');
	assets.addJs('https://www.gestpay.it/checkbrowser/checkBrowser.js');

	var viewData = res.getViewData();

	viewData.paymentModeIframe = settings.isPaymentModeIframe();
	viewData.gestpayApiJs = settings.getJsGestPay();
	viewData.isEnabledGestPayIframeToken = settings.isEnabledGestPayIframeToken();

	var dwBasket = BasketMgr.getCurrentBasket();

	COHelpers.updateImageOnProductLineItem(dwBasket, viewData.order);

	var requestStage = req.querystring.stage;

	if (requestStage == "customer" || requestStage == "shipping") {
		session.privacy.googlePayToken = null;
	}

	res.setViewData(viewData);

	return next();
});

module.exports = server.exports();