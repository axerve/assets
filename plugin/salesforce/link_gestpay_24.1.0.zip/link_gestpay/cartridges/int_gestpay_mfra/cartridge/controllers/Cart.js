'use strict';

var page = module.superModule;
var server = require('server');

server.extend(page);

server.append('Show', function (req, res, next) {
    const assets = require('*/cartridge/scripts/assets');
    assets.addJs('https://sandbox.gestpay.net/pagam/javascript/TLSCHK_TE.js');
    assets.addJs('https://ecomm.sella.it/pagam/javascript/TLSCHK_PRO.js');
    assets.addJs('https://www.gestpay.it/checkbrowser/checkBrowser.js');
    assets.addJs('/js/gestpayCartErrors.js');
    return next();
});

module.exports = server.exports();