'use strict';

var base = module.superModule;

function Payment(currentBasket, currentCustomer, countryCode) {
    base.call(this, currentBasket, currentCustomer, countryCode);

    var paymentHelpers = require('*/cartridge/scripts/helpers/payment/paymentHelpers');

    var paymentInstruments = currentBasket.paymentInstruments;

    this.applicablePaymentMethods = paymentHelpers.setPaymentProcessor(this.applicablePaymentMethods);
}

module.exports = Payment;