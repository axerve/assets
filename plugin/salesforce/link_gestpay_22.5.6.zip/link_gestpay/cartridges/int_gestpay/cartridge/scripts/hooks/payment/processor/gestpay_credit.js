'use strict';
/**
 * GestPay credit card payment processor Handle: Verifies a credit card against
 * a valid card number and expiration date and possibly invalidates invalid form
 * fields. If the verification was successful a credit card payment instrument
 * is created.
 *
 * Authorize: Authorizes a payment using a credit card
 */
var gestpayProcessorService = require('*/cartridge/scripts/service/gestpayProcessorService');

function Handle() {
	return gestpayProcessorService.Handle(arguments);
}

/**
 * Authorizes a payment using a credit card.
 */
function Authorize() {
	return gestpayProcessorService.Authorize(arguments);
}

/**
 * Capture a payment using a credit card. The payment is authorized by using
 * callReadTrxS2S (if fraud prevention is enabled).
 */
function Capture() {
	return gestpayProcessorService.Capture(arguments);
}

/**
 * @returns {string} a token
 */
function createMockToken() {
	return Math.random().toString(36).substr(2);
}

/*
 * Module exports
 */
exports.Handle = Handle;
exports.Authorize = Authorize;
exports.Capture = Capture;
exports.createMockToken = createMockToken;