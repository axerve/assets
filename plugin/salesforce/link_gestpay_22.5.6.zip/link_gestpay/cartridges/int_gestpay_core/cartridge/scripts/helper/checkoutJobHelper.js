'use strict'

var Resource = require('dw/web/Resource');
var Transaction = require('dw/system/Transaction');
var Site = require('dw/system/Site');
var OrderMgr = require('dw/order/OrderMgr');
var Order = require('dw/order/Order');

const logHelper = require('int_gestpay_core/cartridge/scripts/helper/logHelper');

/**
 * Attempts to place the order
 * @param {dw.order.Order} order - The order object to be placed
 * @returns {Object} an error object
 */
function placeOrder(order, logger) {
    var placed = false;

    logHelper.info("orderNo: " + order.orderNo + " trying to place order....", logger);
    Transaction.wrap(function () {

        var placeOrderStatus = OrderMgr.placeOrder(order);

        if (placeOrderStatus.isError()) {

            logHelper.error("orderNo: " + order.orderNo + "  Can't place the order. Error: " + placeOrderStatus.message, logger);
            Transaction.wrap(function () {
                order.trackOrderChange("Can't place the order. Error: " + placeOrderStatus.message);
            });

            placed = false;

        } else {

            order.setExportStatus(Order.EXPORT_STATUS_READY);
            placed = true;
            logHelper.info("orderNo: " + order.orderNo + " order placed.", logger);

            Transaction.wrap(function () {
                order.trackOrderChange(" order placed.");
            });
        }
    });

    return placed;
}

/**
 * Attempts fail the order
 * @param {dw.order.Order} order - The order object to be failed
 */
function failOrder(order, logger) {
    var result = false;

    logHelper.info("orderNo: " + order.orderNo + " trying to fail the order....", logger);
    var failed = Transaction.wrap(function () {

        return OrderMgr.failOrder(order);
    });

    if (failed.code == "OK") {
        Transaction.wrap(function () {
            order.trackOrderChange(" order failed.");
        });

        logHelper.info("orderNo: " + order.orderNo + " order failed.", logger);

        result = true;

    } else {
        Transaction.wrap(function () {
            order.trackOrderChange("Can't fail the order. Error: " + failed.message);
        });

        logHelper.error("orderNo: " + order.orderNo + "  Can't fail the order. Error: " + failed.message, logger);

        result = false;
    }

    return result;
}

/**
 * Attempts fail the order if older than 'hours' param
 * @param {dw.order.Order} order - The order object to be failed
 * @param {int} hours - amount of hours an order need to be older to be failed.
 * @param {dw.system.Log} logger - ....
 * @param {string} failMsg - message logged  in the logger and order log if expired and failed.
 */

function failOrderIfExpired(order, hours, logger, failMsg) {
    var failed = false;

    if (isOrderExpired(order, hours)) {
        Transaction.wrap(function () {
            order.trackOrderChange(failMsg);
        });

        logHelper.warn("orderNo: " + order.orderNo + ". " + failMsg, logger);
        failed = failOrder(order, logger);

    } else {
        logHelper.info("orderNo: " + order.orderNo + "  Order is NOT older than " + hours + "H. No operation.", logger);
    }

    return failed;
}

/**
 * Check if an order is older than hours parameter.
 * @param {dw.order.Order} order - The order object to check.
 * @param {Int} hours - Time in hours .
 * @returns {Object} return true if order is older than hours param. , false otherwise.
 */

function isOrderExpired(order, hours) {

    var creationDateString = order.creationDate;
    var creationDate = new Date(creationDateString);
    var now = new Date();

    creationDate.setHours(creationDate.getHours() + hours);

    return now.getTime() > creationDate.getTime();
}

function sendConfirmationEmail(order, locale) {
    var OrderModel = require('*/cartridge/models/order');
    var EmailHelpers = require('*/cartridge/scripts/helpers/emailHelpers');
    var Locale = require('dw/util/Locale');

    var currentLocale = Locale.getLocale(locale);

    var orderModel = new OrderModel(order, {
        countryCode: currentLocale.country,
        containerView: 'order'
    });

    var orderObject = {
        order: orderModel
    };

    var emailObj = {
        to: order.customerEmail,
        subject: Resource.msg('subject.order.confirmation.email', 'order', null),
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: EmailHelpers.emailTypes.orderConfirmation
    };

    EmailHelpers.sendEmail(emailObj, 'checkout/confirmation/confirmationEmail', orderObject);

}

function sendFailEmail(order, locale) {
    var OrderModel = require('*/cartridge/models/order');
    var EmailHelpers = require('*/cartridge/scripts/helpers/emailHelpers');
    var Locale = require('dw/util/Locale');

    var currentLocale = Locale.getLocale(locale);

    var orderModel = new OrderModel(order, {
        countryCode: currentLocale.country,
        containerView: 'order'
    });

    var orderObject = {
        order: orderModel
    };

    var emailObj = {
        to: order.customerEmail,
        subject: Resource.msg('subject.order.fail.email', 'fail', null),
        from: Site.current.getCustomPreferenceValue('customerServiceEmail') || 'no-reply@salesforce.com',
        type: EmailHelpers.emailTypes.orderConfirmation
    };

    EmailHelpers.sendEmail(emailObj, 'checkout/fail/failEmail', orderObject);

}


function isRiskified(response) {
    return response.payload && response.payload.risk && response.payload.risk.riskResponseCode;
}

module.exports = {
    sendConfirmationEmail: sendConfirmationEmail,
    placeOrder: placeOrder,
    failOrder: failOrder,
    failOrderIfExpired: failOrderIfExpired,
    isRiskified: isRiskified,
    sendFailEmail: sendFailEmail
};