'use strict';

/**
 * @returns {boolean} whether the card is a saved one
 */
function isSavedCard() {
    return $('.saved-payment-instrument.selected-payment').is(':visible');
}

/**
 * @returns {boolean} whether the card is being saved
 */
function isSavingCard() {
    return $('#saveCreditCard').is(':checked:visible');
}

module.exports = {
    isSavedCard: isSavedCard,
    isSavingCard: isSavingCard
};
