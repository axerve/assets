'use strict';

var eventResponse = $("#creditCardSaved");

if (eventResponse.length > 0) {
    var action = eventResponse.attr("data-urlAction");
    var idOrder = eventResponse.attr("data-orderId");
    var orderToken = eventResponse.attr("data-orderToken");

    $('<form class="d-none" action="' + action + '" method="POST">' +
        '<input type="hidden" name="orderID" value="' + idOrder + '" />' +
        '<input type="hidden" name="orderToken" value="' + orderToken + '" />' +
        '</form>').appendTo($(document.body)).submit();
}