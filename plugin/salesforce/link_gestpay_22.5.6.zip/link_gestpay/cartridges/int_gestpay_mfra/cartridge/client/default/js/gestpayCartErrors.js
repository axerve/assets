$(document).ready(function(){
  $('#cart-errors').appendTo($('.cart-error-messaging')).removeClass('hide').addClass('show');
});