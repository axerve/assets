'use strict'

const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

const constants = require("int_gestpay_mfra/cartridge/scripts/GestpayConstants.js")
const PaymentStatusServiceCallBack = require('int_gestpay_mfra/cartridge/scripts/service/payment/details/PaymentDetailsServiceCallBack.js');

var paymentDetailsService = {
	post: function (paymentStatusRequest) {
		var serviceName = constants.services.payment.detail.name + "." + constants.services.payment.detail.method.toLowerCase();

		var service = LocalServiceRegistry.createService(serviceName, PaymentStatusServiceCallBack.post);

		var response = service.call(paymentStatusRequest);
		return response;
	}

};

module.exports = paymentDetailsService;