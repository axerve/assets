'use strict';
var server = require('server');

server.get('Render', server.middleware.https, function(req, res, next) {
	res.render('riskified/riskifiedBeacon');
	return next();
});

module.exports = server.exports();