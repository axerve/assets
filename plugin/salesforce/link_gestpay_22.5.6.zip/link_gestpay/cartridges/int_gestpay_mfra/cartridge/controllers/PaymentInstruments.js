'use strict';

var page = module.superModule;
var server = require('server');

var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.extend(page);
/**
 * Check payment mode before add credit card
 */
server.prepend('AddPayment', function (req, res, next) {
	var URLUtils = require('dw/web/URLUtils');
	var settings = require('int_gestpay/cartridge/scripts/utils/settings');
	if (!settings.isPaymentModeS2s()) {
		res.redirect('Account-Show');
	}
	return next();
});
/**
 * Check payment mode before add credit card
 */
server.prepend('SavePayment', csrfProtection.validateAjaxRequest, function (req, res, next) {
	var URLUtils = require('dw/web/URLUtils');
	var settings = require('int_gestpay/cartridge/scripts/utils/settings');
	if (!settings.isPaymentModeS2s()) {
		res.redirect('Account-Show');
	}
	return next();
});

server.replace('SavePayment', csrfProtection.validateAjaxRequest, function (req, res, next) {
	var settings = require('int_gestpay/cartridge/scripts/utils/settings');
	var formErrors = require('*/cartridge/scripts/formErrors');
	var HookMgr = require('dw/system/HookMgr');

	var paymentForm = server.forms.getForm('creditCard');
	var result = getDetailsObject(paymentForm);

	if (paymentForm.valid && !verifyCard(result, paymentForm) && settings.isPaymentModeS2s()) {
		res.setViewData(result);
		this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line
			// no-shadow
			var URLUtils = require('dw/web/URLUtils');
			var CustomerMgr = require('dw/customer/CustomerMgr');
			var Transaction = require('dw/system/Transaction');

			var formInfo = res.getViewData();
			var customer = CustomerMgr.getCustomerByCustomerNumber(req.currentCustomer.profile.customerNo);
			var walvar = customer.getProfile().getWallet();

			Transaction.wrap(function () {
				var paymentInstrument = wallet.createPaymentInstrument('CREDIT_CARD');
				paymentInstrument.setCreditCardHolder(formInfo.name);
				paymentInstrument.setCreditCardNumber(formInfo.cardNumber);
				paymentInstrument.setCreditCardType(formInfo.cardType);
				paymentInstrument.setCreditCardExpirationMonth(formInfo.expirationMonth);
				paymentInstrument.setCreditCardExpirationYear(formInfo.expirationYear);
				paymentInstrument.setCreditCardToken(formInfo.cardNumber);
			});
			res.json({
				success: true,
				redirectUrl: URLUtils.url('PaymentInstruments-List').toString()
			});
		});
	} else {
		res.json({
			success: false,
			fields: formErrors.getFormErrors(paymentForm)
		});
	}
	return next();
});

module.exports = server.exports();