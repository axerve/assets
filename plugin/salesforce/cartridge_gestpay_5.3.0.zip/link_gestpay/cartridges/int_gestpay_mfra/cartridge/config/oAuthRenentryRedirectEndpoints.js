'use strict';

const oAuthRenentryRedirectEndpoints = module.superModule;
oAuthRenentryRedirectEndpoints[42] = 'GestPay-AmazonPayCart';

module.exports = oAuthRenentryRedirectEndpoints;
