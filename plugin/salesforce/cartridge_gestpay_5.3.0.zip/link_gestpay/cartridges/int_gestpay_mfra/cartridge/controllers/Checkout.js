'use strict';

var page = module.superModule;
var server = require('server');

server.append('Begin', function(req, res, next) {
	let settings = require('int_gestpay/cartridge/scripts/utils/settings');
	const assets = require('*/cartridge/scripts/assets');
	assets.addJs('https://sandbox.gestpay.net/pagam/javascript/TLSCHK_TE.js');
	assets.addJs('https://ecomm.sella.it/pagam/javascript/TLSCHK_PRO.js');
	assets.addJs('https://www.gestpay.it/checkbrowser/checkBrowser.js');

	res.setViewData({
		paymentModeIframe: settings.isPaymentModeIframe(),
		gestpayApiJs: settings.getJsGestPay(),
		isEnabledGestPayIframeToken: settings.isEnabledGestPayIframeToken()
	});

	return next();
});

module.exports = server.exports();
