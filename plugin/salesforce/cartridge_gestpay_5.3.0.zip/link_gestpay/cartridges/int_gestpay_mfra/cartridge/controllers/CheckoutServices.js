'use strict';

const Resource = require('dw/web/Resource');

var server = require('server');

var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var log = require('dw/system/Logger').getLogger('CheckoutServices');

const currentSiteId = dw.system.Site.getCurrent().getID();
const genericError = {
	error: true,
	errorMessage: Resource.msg('error.technical', 'checkout', null)
};

var page = module.superModule;
server.extend(page);

server.replace('PlaceOrder', server.middleware.https, function (req, res, next) {
	var result;
	try {
		let gestpayService = require('*/cartridge/scripts/service/gestpayService');
		result = gestpayService.createOrder(req, res);
		if (!result.continueUrl) {
			const URLUtils = require('dw/web/URLUtils');
			result.continueUrl = URLUtils.url('Order-Confirm').toString();
		}
	} catch (e) {
		dw.system.Logger.error('[CheckoutServices.PlaceOrder] Site {0}, error: {1}', currentSiteId, e.message);
		result = genericError;
	} finally {
		dw.system.Logger.error('[CheckoutServices.PlaceOrder] Site {0}, result: {1}', currentSiteId, JSON.stringify(result));
		res.json(result);
	}
	return next();
});

server.post('PlaceOrderByIframeResult', server.middleware.https, function (req, res, next) {
	let order;
	let token;
	let result;
	let URLUtils = require('dw/web/URLUtils');
	let OrderMgr = require('dw/order/OrderMgr');
	let Transaction = require('dw/system/Transaction');
	let settings = require('int_gestpay/cartridge/scripts/utils/settings');
	let gestpayService = require('*/cartridge/scripts/service/gestpayService');
	try {
		order = OrderMgr.getOrder(req.form.orderId);
		token = req.form.orderToken ? req.form.orderToken : null;
		if (!order || !token || token !== order.orderToken || order.customer.ID !== req.currentCustomer.raw.ID) {
			result = genericError;
		} else {
			Transaction.wrap(function () {
				order.trackOrderChange('Start place order iframe mode - gestpay result: ' + JSON.stringify(req.form));
			});
			// find payment instrument using cryptDecryptString
			var paymentInstrument = order.getPaymentInstruments().toArray().filter(function (pi) {
				var gestPayEncryptResult = pi.getPaymentTransaction().getCustom().gestPayEncryptResult;
				return (gestPayEncryptResult && JSON.parse(gestPayEncryptResult).cryptDecryptString == req.form.cryptDecryptString);
			})[0];
			// check 3d secure error code
			if (req.form.ErrorCode == settings.getGestPayWs3dSecureCheck()) {
				Transaction.wrap(function () {
					order.trackOrderChange('3d secure check required, update transKey value: ' + String(req.form.TransKey));
					paymentInstrument.paymentTransaction.custom.gestPayTransKey = String(req.form.TransKey);
				});
				// set redirect url from gestpay 3d secure
				var checkoutPageUrl = URLUtils.https('GestPay-GestPay3dSecureCallback', 'transKey', req.form.TransKey, 'orderId', req.form.orderId, 'orderToken', req.form.orderToken);
				result = {
					error: false,
					redirectUrl: [settings.gestPay3dSecureUrl(), '?a=', paymentInstrument.custom.gestPayShopLogin, '&b=', req.form.VBVRisp, '&c=', dw.crypto.Encoding.toURI(checkoutPageUrl)].join('')
				};
				Transaction.wrap(function () {
					order.trackOrderChange('3d secure check required, redirect to: ' + result.redirectUrl);
				});
			} else {
				// start place order
				result = gestpayService.placeOrderByCryptDecryptString(req.form.EncryptedString || req.form.cryptDecryptString, req, res);
				if (!result.error) {
					result.orderID = order.orderNo;
					result.orderToken = order.orderToken;
					result.continueUrl = URLUtils.url('Order-Confirm').toString();
					log.info('PlaceOrderByIframeResult - continueUrl is ' + result.continueUrl);
				}
			}
		}
		if (order && result.error) {
			Transaction.wrap(function () {
				order.trackOrderChange('PlaceOrderByIframeResult error: ' + JSON.stringify(result));
				OrderMgr.failOrder(order);
			});
		}
	} catch (e) {
		result = genericError;
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange('PlaceOrderByIframeResult error: ' + e);
				OrderMgr.failOrder(order);
			});
		}
	} finally {
		res.json(result);
	}
	return next();
});

server.replace('SubmitPayment', server.middleware.https, csrfProtection.validateAjaxRequest, function (req, res, next) {
	var paymentForm = server.forms.getForm('billing');
	var billingFormErrors = {};
	var creditCardErrors = {};
	var viewData = {};
	var formFieldErrors = [];

	// verify billing form data
	billingFormErrors = COHelpers.validateBillingForm(paymentForm.addressFields);
	var contactInfoFormErrors = COHelpers.validateFields(paymentForm.contactInfoFields);
	var paymentMethodCreditCard = paymentForm.paymentMethod.value === 'CREDIT_CARD';

	if (!req.form.storedPaymentUUID && paymentMethodCreditCard) {
		// verify credit card form data
		creditCardErrors = COHelpers.validateCreditCard(paymentForm);
	}

	if (Object.keys(creditCardErrors).length || Object.keys(billingFormErrors).length) {
		// respond with form data and errors
		res.json({
			form: paymentForm,
			fieldErrors: [billingFormErrors, creditCardErrors],
			serverErrors: [],
			error: true
		});
	} else {
		viewData.address = {
			firstName: {
				value: paymentForm.addressFields.firstName.value
			},
			lastName: {
				value: paymentForm.addressFields.lastName.value
			},
			address1: {
				value: paymentForm.addressFields.address1.value
			},
			address2: {
				value: paymentForm.addressFields.address2.value
			},
			city: {
				value: paymentForm.addressFields.city.value
			},
			postalCode: {
				value: paymentForm.addressFields.postalCode.value
			},
			countryCode: {
				value: paymentForm.addressFields.country.value
			}
		};

		if (Object.prototype.hasOwnProperty.call(paymentForm.addressFields, 'states')) {
			viewData.address.stateCode = {
				value: paymentForm.addressFields.states.stateCode.value
			};
		}

		viewData.paymentMethod = {
			value: paymentForm.paymentMethod.value,
			htmlName: paymentForm.paymentMethod.value
		};

		if (paymentMethodCreditCard) {
			viewData.paymentInformation = {
				cardType: {
					value: paymentForm.creditCardFields.cardType.value,
					htmlName: paymentForm.creditCardFields.cardType.htmlName
				},
				cardNumber: {
					value: paymentForm.creditCardFields.cardNumber.value,
					htmlName: paymentForm.creditCardFields.cardNumber.htmlName
				},
				securityCode: {
					value: paymentForm.creditCardFields.securityCode.value,
					htmlName: paymentForm.creditCardFields.securityCode.htmlName
				},
				expirationMonth: {
					value: parseInt(paymentForm.creditCardFields.expirationMonth.selectedOption, 10),
					htmlName: paymentForm.creditCardFields.expirationMonth.htmlName
				},
				expirationYear: {
					value: parseInt(paymentForm.creditCardFields.expirationYear.value, 10),
					htmlName: paymentForm.creditCardFields.expirationYear.htmlName
				}
			};
			viewData.saveCard = paymentForm.creditCardFields.saveCard.checked;
		} else {
			viewData.paymentInformation = {};
		}
		if (Object.keys(contactInfoFormErrors).length) {
			formFieldErrors.push(contactInfoFormErrors);
		} else {

			viewData.phone = {
				value: paymentForm.contactInfoFields.phone.value
			};

			viewData.profile = {
				phone: paymentForm.contactInfoFields.phone.value
			}
		}
		if (req.form.storedPaymentUUID) {
			viewData.storedPaymentUUID = req.form.storedPaymentUUID;
		}

		res.setViewData(viewData);

		this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line
			// no-shadow
			var BasketMgr = require('dw/order/BasketMgr');
			var CustomerMgr = require('dw/customer/CustomerMgr');
			var HookMgr = require('dw/system/HookMgr');
			var PaymentMgr = require('dw/order/PaymentMgr');
			var Transaction = require('dw/system/Transaction');
			var AccountModel = require('*/cartridge/models/account');
			var OrderModel = require('*/cartridge/models/order');
			var URLUtils = require('dw/web/URLUtils');
			var array = require('*/cartridge/scripts/util/array');
			var Locale = require('dw/util/Locale');
			var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

			var currentBasket = BasketMgr.getCurrentBasket();
			var billingData = res.getViewData();
			var settings = require('int_gestpay/cartridge/scripts/utils/settings');

			if (!currentBasket) {
				delete billingData.paymentInformation;

				res.json({
					error: true,
					cartError: true,
					fieldErrors: [],
					serverErrors: [],
					redirectUrl: URLUtils.url('Cart-Show').toString()
				});
				return;
			}

			var billingAddress = currentBasket.billingAddress;
			var billingForm = server.forms.getForm('billing');
			var paymentMethodID = billingData.paymentMethod.value;
			var result;

			billingForm.creditCardFields.cardNumber.htmlValue = '';
			billingForm.creditCardFields.securityCode.htmlValue = '';

			var paymentMethodCreditCard = billingForm.paymentMethod.value === 'CREDIT_CARD';

			Transaction.wrap(function () {
				if (!billingAddress) {
					billingAddress = currentBasket.createBillingAddress();
				}

				billingAddress.setFirstName(billingData.address.firstName.value);
				billingAddress.setLastName(billingData.address.lastName.value);
				billingAddress.setAddress1(billingData.address.address1.value);
				billingAddress.setAddress2(billingData.address.address2.value);
				billingAddress.setCity(billingData.address.city.value);
				billingAddress.setPostalCode(billingData.address.postalCode.value);
				if (Object.prototype.hasOwnProperty.call(billingData.address, 'stateCode')) {
					billingAddress.setStateCode(billingData.address.stateCode.value);
				}
				billingAddress.setCountryCode(billingData.address.countryCode.value);

				if (billingData.storedPaymentUUID) {
					billingAddress.setPhone(req.currentCustomer.profile.phone);
					//currentBasket.setCustomerEmail(req.currentCustomer.profile.email);
				} else {
					billingAddress.setPhone(billingData.profile.phone);
					//currentBasket.setCustomerEmail(billingData.profile.email);
				}
			});

			// if there is no selected payment option and balance is greater than zero
			if (!paymentMethodID && currentBasket.totalGrossPrice.value > 0) {
				var noPaymentMethod = {};

				noPaymentMethod[billingData.paymentMethod.htmlName] = Resource.msg('error.no.selected.payment.method', 'creditCard', null);

				delete billingData.paymentInformation;

				res.json({
					form: billingForm,
					fieldErrors: [noPaymentMethod],
					serverErrors: [],
					error: true
				});
				return;
			}

			var processor = PaymentMgr.getPaymentMethod(paymentMethodID).getPaymentProcessor();
			// check to make sure there is a payment processor
			if (!processor) {
				throw new Error(Resource.msg('error.payment.processor.missing', 'checkout', null));
			}

			if (paymentMethodCreditCard && billingData.storedPaymentUUID && req.currentCustomer.raw.authenticated && req.currentCustomer.raw.registered) {
				var paymentInstruments = req.currentCustomer.wallet.paymentInstruments;
				var paymentInstrument = array.find(paymentInstruments, function (item) {
					return billingData.storedPaymentUUID === item.UUID;
				});

				billingData.paymentInformation.cardNumber.value = paymentInstrument.creditCardNumber;
				billingData.paymentInformation.cardType.value = paymentInstrument.creditCardType;
				billingData.paymentInformation.securityCode.value = req.form.securityCode || '';
				billingData.paymentInformation.expirationMonth.value = paymentInstrument.creditCardExpirationMonth;
				billingData.paymentInformation.expirationYear.value = paymentInstrument.creditCardExpirationYear;
				billingData.paymentInformation.creditCardToken = paymentInstrument.raw.creditCardToken;

				// add securityCode in billing form
				paymentForm.creditCardFields.securityCode.value = req.form.securityCode || '';
			}

			billingData.extraPaymentInfo = {
				shopLogin: session.custom.shopLogin ? session.custom.shopLogin : settings.getShopLogin()
			};
			delete session.custom.shopLogin;
			billingData.paymentProcessor = processor;
			if (HookMgr.hasHook('app.payment.processor.' + processor.ID.toLowerCase())) {
				result = HookMgr.callHook('app.payment.processor.' + processor.ID.toLowerCase(), 'Handle', currentBasket, billingData);
			} else {
				result = HookMgr.callHook('app.payment.processor.default', 'Handle');
			}
			delete billingData.extraPaymentInfo;

			// need to invalidate credit card fields
			if (result.error) {
				delete billingData.paymentInformation;

				res.json({
					form: billingForm,
					fieldErrors: result.fieldErrors,
					serverErrors: result.serverErrors,
					error: true
				});
				return;
			}

			if (settings.isPaymentModeS2s() && !billingData.storedPaymentUUID && req.currentCustomer.raw.authenticated &&
				req.currentCustomer.raw.registered && billingData.saveCard && (paymentMethodID === 'CREDIT_CARD')) {
				var customer = CustomerMgr.getCustomerByCustomerNumber(req.currentCustomer.profile.customerNo);

				var saveCardResult = COHelpers.savePaymentInstrumentToWallet(billingData, currentBasket, customer);

				req.currentCustomer.wallet.paymentInstruments.push({
					creditCardHolder: saveCardResult.creditCardHolder,
					maskedCreditCardNumber: saveCardResult.maskedCreditCardNumber,
					creditCardType: saveCardResult.creditCardType,
					creditCardExpirationMonth: saveCardResult.creditCardExpirationMonth,
					creditCardExpirationYear: saveCardResult.creditCardExpirationYear,
					UUID: saveCardResult.UUID,
					creditCardNumber: Object.hasOwnProperty.call(saveCardResult, 'creditCardNumber') ? saveCardResult.creditCardNumber : null,
					raw: saveCardResult
				});
			}

			// Calculate the basket
			Transaction.wrap(function () {
				basketCalculationHelpers.calculateTotals(currentBasket);
			});

			// Re-calculate the payments.
			var calculatedPaymentTransaction = COHelpers.calculatePaymentTransaction(currentBasket);

			if (calculatedPaymentTransaction.error) {
				res.json({
					form: paymentForm,
					fieldErrors: [],
					serverErrors: [Resource.msg('error.technical', 'checkout', null)],
					error: true
				});
				return;
			}

			var usingMultiShipping = req.session.privacyCache.get('usingMultiShipping');
			if (usingMultiShipping === true && currentBasket.shipments.length < 2) {
				req.session.privacyCache.set('usingMultiShipping', false);
				usingMultiShipping = false;
			}

			var currentLocale = Locale.getLocale(req.locale.id);

			var basketModel = new OrderModel(currentBasket, {
				usingMultiShipping: usingMultiShipping,
				countryCode: currentLocale.country,
				containerView: 'basket'
			});

			var accountModel = new AccountModel(req.currentCustomer);
			var renderedStoredPaymentInstrument = COHelpers.getRenderedPaymentInstruments(req, accountModel);

			delete billingData.paymentInformation;

			res.json({
				renderedPaymentInstruments: renderedStoredPaymentInstrument,
				customer: accountModel,
				order: basketModel,
				form: billingForm,
				error: false
			});
		});
	}
	return next();
});

module.exports = server.exports();