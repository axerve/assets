'use strict';

var server = require('server');
var page = module.superModule;
const settings = require('int_gestpay/cartridge/scripts/utils/settings');

server.extend(page);

server.append('Confirm', function (req, res, next) {
    var viewData = res.getViewData();

    var OrderMgr = require('dw/order/OrderMgr');
    var Order = require('dw/order/Order');

    var orderId = (req.form.orderID) ? req.form.orderID : req.querystring.ID;
    var order = OrderMgr.getOrder(orderId);

    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

    var isKlarna = COHelpers.checkOrderPaymentMethod(order, "KLARNA");
    var isCard = COHelpers.checkOrderPaymentMethod(order, "CREDIT_CARD");
    var isPaypal = COHelpers.checkOrderPaymentMethod(order, "PayPal");
    var isCreated = order.status.value === Order.ORDER_STATUS_CREATED;
    var isFraudPreventionOn = settings.isFraudPreventionEnabled();

    if ((isKlarna || (isFraudPreventionOn && (isCard || isPaypal))) && isCreated) {

        var data = {
            order: viewData.order,
            returningCustomer: viewData.returningCustomer,
            reportingURLs: viewData.reportingURLs,
            orderUUID: viewData.orderUUID
        };

        if (!req.currentCustomer.profile) {
            data.passwordForm = viewData.passwordForm;
        }

        res.render('/checkout/confirmation/waitingConfirmation', data);
    }

    return next();
});

module.exports = server.exports();