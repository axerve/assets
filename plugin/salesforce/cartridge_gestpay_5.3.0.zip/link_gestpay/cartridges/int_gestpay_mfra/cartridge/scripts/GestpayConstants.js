'use strict';

const Site = require('dw/system/Site');

module.exports = {
    services: {
        payment: {
            detail: {
                name: "gestpay.rest.paymentDetails",
                method: "POST"
            }
        }
    }
};