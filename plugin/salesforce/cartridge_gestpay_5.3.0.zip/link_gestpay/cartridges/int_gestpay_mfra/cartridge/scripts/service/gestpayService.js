/**
 *
 * Gestpay service
 *
 * service for handle create order - 3d secure response and payment gateway
 * request, all this methods are used in COPlaceOrder and COSummary controllers
 *
 * gestpayCreateOrder: create order before call gestpay
 *
 * gestpayPlaceOrder: submit order and check gestpay response
 *
 * gestPay3dSecureResponse: check 3d secure response
 *
 * callDeleteS2S: call delete gestpay service
 *
 * submitGestpayGateway: submit a payment gateway request
 *
 */
'use strict';

const OrderMgr = require('dw/order/OrderMgr');
const Resource = require('dw/web/Resource');
const Transaction = require('dw/system/Transaction');
const Status = require('dw/system/Status');

const server = require('server');
const COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
const CustomerPaymentInstrument = require('int_gestpay/cartridge/scripts/utils/CustomerPaymentUtils');
const settings = require('int_gestpay/cartridge/scripts/utils/settings');
const utils = require('int_gestpay/cartridge/scripts/utils/utils');
const wsS2S = require('int_gestpay/cartridge/scripts/wsS2S');

const logger = utils.getLogger();
const currentSiteId = dw.system.Site.getCurrent().getID();
const technicalError = {
	error: true,
	errorMessage: Resource.msg('error.technical', 'checkout', null),
};

/**
 * create order before call gestpay with first status (created)
 *
 * @param {Object} req
 * @return {*}
 */
function createOrder(req) {
	let result = {};
	/** @type {dw.order.Order} */
	let order;
	let BasketMgr = require('dw/order/BasketMgr');
	let PaymentMgr = require('dw/order/PaymentMgr');
	let checkoutValidator = require('int_gestpay_mfra/cartridge/scripts/service/gestpayCheckoutValidator');
	let billingData = server.forms.getForm('billing');
	// gestpay vars
	let cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	try {
		let currentBasket = BasketMgr.getCurrentBasket();
		result = checkoutValidator.validateCurrentBasket(currentBasket, req);
		if (result.error === true) {
			return result;
		}

		order = COHelpers.createOrder(currentBasket);
		if (!order) {
			return technicalError;
		}

		Transaction.wrap(function () {
			order.trackOrderChange('GestpayService - createOrder - order created with id: ' + order.orderNo);
		});
		result.orderID = order.orderNo;
		result.orderToken = order.getOrderToken();
		// check payment instruments
		let paymentInstruments = order.getPaymentInstruments();
		for (let i = 0; i < paymentInstruments.length; i++) {

			var paymentInstrument = paymentInstruments[i];
			switch (
				PaymentMgr.getPaymentMethod(paymentInstrument.paymentMethod)
				.getPaymentProcessor()
				.getID()
			) {
				case settings.GESTPAY_CREDIT:
					// check gestpay mode
					switch (settings.getGestpayMode()) {
						case settings.GESTPAY_IFRAME_MODE:
							if (paymentInstrument.creditCardToken) {
								logger.info(
									'[gestpayService.createOrder] Site {0}, iframe: place order for credit card already saved',
									currentSiteId
								);
								result = placeOrderAndPopulateResult(order, req, result);
							} else {
								logger.info(
									'[gestpayService.createOrder] Site {0}, iframe: place order for new credit card',
									currentSiteId
								);
								var encryptResult = cryptDecrypt
									.encryptByOrderPaymentInstrument(
										paymentInstrument,
										order,
										billingData.creditCardFields.saveCard.checked,
										currentBasket
									)
									.getObject();
								if (encryptResult.errorCode == settings.getGestPayWsSuccessCode()) {
									result.cryptDecryptString = encryptResult.cryptDecryptString;
									result.shopLogin = paymentInstrument.custom.gestPayShopLogin;
								} else {
									result = technicalError;
								}
							}
							break;
						case settings.GESTPAY_S2S_MODE:
							logger.error('[gestpayService.createOrder] Site {0}, s2s: place order');
							result = placeOrderAndPopulateResult(order, req, result);
							break;
					}
					break;
				case settings.GESTPAY_PAYMENT_GATEWAY:
					let requestToken =
						CustomerPaymentInstrument.isPaymentSaved(paymentInstrument) ||
						(billingData.creditCardFields.savePayment.checked && paymentInstrument.paymentMethod === 'PAYPAL');
					let useToken = CustomerPaymentInstrument.isPaymentSaved(paymentInstrument);
					if (!useToken) {
						let encrypt = cryptDecrypt
							.encryptByOrderPaymentInstrument(paymentInstrument, order, requestToken)
							.getObject();
						result.continueUrl =
							settings.gestPayPagamPageUrl() +
							'?a=' +
							paymentInstrument.custom.gestPayShopLogin +
							'&b=' +
							encrypt.cryptDecryptString;
						Transaction.wrap(function () {
							order.trackOrderChange(
								'GestpayService - createOrder - call payment gateway with url : ' + result.continueUrl
							);
						});
					} else {
						result = placeOrderAndPopulateResult(order, req, result);
					}
					break;
			}
			if (result.error) {
				Transaction.wrap(function () {
					OrderMgr.failOrder(order);
				});
				break;
			}
		}
	} catch (e) {
		let error = e;
		result = technicalError;
		logger.error(error);
		if (order) {
			Transaction.wrap(function () {
				OrderMgr.failOrder(order);
			});
		}
	}
	return result;
}

/**
 * @param {dw.order.Order} order
 * @param {Object} req
 * @param {Object} result
 */
function placeOrderAndPopulateResult(order, req, result) {
	let placeOrderResult = placeOrder(order, req);
	let returnResult = result;
	if (placeOrderResult.error) {
		returnResult = technicalError;
	} else if (placeOrderResult.redirect3dSecure) {
		returnResult.continueUrl = placeOrderResult.redirect3dSecure;
	} else {
		returnResult.showConfirmOrder = true;
	}
	return returnResult;
}

/**
 *
 * @param cryptDecryptString
 * @param req
 * @returns
 */
function placeOrderByCryptDecryptString(cryptDecryptString, req) {
	let result;
	let cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	try {
		var decrypt = cryptDecrypt.decrypt(cryptDecryptString, null).getObject();
		result = placeOrderByCryptDecryptObj(decrypt, settings.getShopLogin(), req);
	} catch (e) {
		var error = e;
		logger.error(
			'[gestpayService.placeOrderByCryptDecryptString] decrypt response: code {0} - description {1}',
			decrypt.errorCode,
			decrypt.errorDescription
		);
		result = {
			error: true,
			errorMessage: Resource.msg('error.technical', 'checkout', null),
		};
	}
	return result;
}

/**
 * @param {dw.object.CustomObject} gestpayNotificationObj
 * @param req
 * @returns
 */
function placeOrderByNotificationObj(gestpayNotificationObj, req) {
	let result = {};
	try {
		result = placeOrderByCryptDecryptObj(
			JSON.parse(gestpayNotificationObj.custom.decryptNotificationResult),
			gestpayNotificationObj.custom.requestShopLogin,
			req
		);
	} catch (e) {
		result = {
			error: true,
			errorMessage: Resource.msg('error.technical', 'checkout', null),
		};
	}
	return result;
}

function placeOrderByCryptDecryptObj(decrypt, shopLogin, req) {
	/**
	 * @type {dw.order.Order}
	 */
	let order = null;
	let orderUtils = require('int_gestpay/cartridge/scripts/utils/orderUtils');
	let orderPlacementStatus = {
		error: false
	};
	try {
		logger.info(
			'[gestpayService.placeOrderByCryptDecryptObj] Site {0} decrypt response: {1}',
			currentSiteId,
			JSON.stringify(decrypt)
		);
		// check shop login
		if (shopLogin === settings.getShopLogin()) {
			order = OrderMgr.getOrder(decrypt.shopTransactionID);
			// add orderNo and token for PlaceOrderByIframeResult response
			orderPlacementStatus.orderID = order.orderNo;
			orderPlacementStatus.orderToken = order.getOrderToken();
			// update payment transaction result using decrypt result

			var customInfoMap = settings.convertCustomInfoToMap(decrypt.customInfo);
			// find paymentInstrumentId: cryptDecrpt.encryptByOrderPaymentInstrument
			var paymentInstrument = order
				.getPaymentInstruments()
				.toArray()
				.filter(function (paymentInstrumentTemp) {
					return paymentInstrumentTemp.getUUID() == customInfoMap.get(settings.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID);
				})[0];
			Transaction.wrap(function () {
				paymentInstrument.paymentTransaction.custom.gestPayDencryptResult = JSON.stringify(decrypt);
			});
			orderUtils.changePaymentTransactionResult(paymentInstrument, order, decrypt.transactionResult);

			// check error code
			if (decrypt.errorCode === settings.getGestPayWsSuccessCode()) {
				if (decrypt.paymentMethod === 'AMAZONPAY') {
					var txDetails = wsS2S.callReadTrxS2S(decrypt.shopTransactionID, decrypt.bankTransactionID).getObject();

					if (txDetails.errorCode == 0) {
						Transaction.wrap(function () {
							order.custom.amazonOrderReferenceID = txDetails.amazonOrderReferenceID;
							if (!customer || !customer.authenticated) {
								order.customerEmail = txDetails.buyerEmail;
								order.customerName = txDetails.buyerName;
							}
						});

						const gestpayAmazonUtils = require('*/cartridge/scripts/payment/extension/GESTPAY_AMAZONPAY');
						var status = Transaction.wrap(function () {
							var status = gestpayAmazonUtils.validateShippingAddress(txDetails.shippingAddress, order, txDetails);
							if (!status.isError()) {
								status = gestpayAmazonUtils.copyShippingAddress(txDetails.shippingAddress, order, txDetails);
								if (!status.isError()) {
									status = gestpayAmazonUtils.applyShippingMethod(txDetails, order);
									if (!status.isError()) {
										status = gestpayAmazonUtils.validateBillingAddress(txDetails.billingAddress, order, txDetails);
										if (!status.isError()) {
											status = gestpayAmazonUtils.copyBillingAddress(txDetails.billingAddress, order, txDetails);
										}
									}
								}
							}
							return status;
						});

						if (status.isError()) {
							orderPlacementStatus.error = true;
							orderPlacementStatus.errorCode = status.code;
							orderPlacementStatus.errorMessage = (status.message !== status.code) ? status.message : Resource.msg(status.code, 'checkout');
						}

					} else {
						orderPlacementStatus.error = true;
					}
				}
				// place order
				var isCard = COHelpers.checkOrderPaymentMethod(order, "CREDIT_CARD");
				var isFraudPreventionOn = settings.isFraudPreventionEnabled();

				if (isFraudPreventionOn && isCard) {
					orderPlacementStatus.error = false;
				} else {
					if (!orderPlacementStatus.error) {
						orderPlacementStatus = placeOrder(order, req, decrypt);
					}
				}
			} else {
				orderPlacementStatus.error = true;
				orderPlacementStatus.errorMessage = decrypt.errorDescription || Resource.msg('gestpay.errors.' + decrypt.errorCode, 'gestpay_errors');
				orderPlacementStatus.errorCode = decrypt.errorCode;
				Transaction.wrap(function () {
					order.trackOrderChange('Decrypt error: ' + decrypt.errorCode + ', ' + decrypt.errorDescription);
				});
			}
		} else {
			logger.warn('shop login (' + shopLogin + ') different from admin config: ' + settings.getShopLogin());
		}
	} catch (e) {
		var error = e;
		logger.warn('Error in placeOrderByCryptDecryptObj:\n{0}', error);
		orderPlacementStatus.error = true;
	}

	if (orderPlacementStatus.error) {
		if (!orderPlacementStatus.errorMessage) {
			orderPlacementStatus.errorMessage = Resource.msg('error.technical', 'checkout', null);
		}

		if (order && order.orderNo) {
			var trx = wsS2S.callReadTrxS2S(decrypt.shopTransactionID, decrypt.bankTransactionID).getObject();

			if (trx.transactionResult == 'OK') {
				var reason = "Error processing order: " + orderPlacementStatus.errorMessage;
				if (trx.transactionState == 'MOV') {
					// this should not happen; if it happens there is a problem in the configuration
					wsS2S.callRefundS2S(
						decrypt.currency,
						decrypt.amount,
						decrypt.shopTransactionID,
						decrypt.bankTransactionID,
						reason,
						true
					);
					Transaction.wrap(function () {
						order.trackOrderChange('Gestpay - order refunded');
					});

					Transaction.wrap(function () {
						OrderMgr.cancelOrder(order);
					});
				} else if (['AUT', 'PRE'].indexOf(trx.transactionState) >= 0) {
					wsS2S.callDeleteS2S(decrypt.bankTransactionID, decrypt.shopTransactionID, reason);
					Transaction.wrap(function () {
						order.trackOrderChange('Gestpay - order void');
					});

					Transaction.wrap(function () {
						order.trackOrderChange('Gestpay - gestpayPlaceOrder - error: ' + orderPlacementStatus.errorMessage);
						OrderMgr.failOrder(order, true);
					});
				}
			}
		}
	}

	if (order && !orderPlacementStatus.Order) {
		orderPlacementStatus.Order = order;
	}

	return orderPlacementStatus;
}

/**
 * Submit order and check gestpay response - change order status from CREATED to
 * NEW or FAILED
 *
 * @param {dw.order.Order} order
 * @param req
 * @return {Object}
 */
function placeOrder(order, req, decrypt) {
	var orderPlacementStatus = {
		error: true,
		errorMessage: Resource.msg('error.technical', 'checkout', null),
	};

	if (!order) {
		logger.error('[gestpayService.placeOrder] Site {0}, order is null or undefined', currentSiteId);
	}

	try {
		orderPlacementStatus.orderID = order.orderNo;
		orderPlacementStatus.orderToken = order.orderToken;
		// check order status
		switch (order.status.value) {
			case dw.order.Order.ORDER_STATUS_NEW:
			case dw.order.Order.ORDER_STATUS_OPEN:
			case dw.order.Order.ORDER_STATUS_FAILED:
				orderPlacementStatus.error = false;
				orderPlacementStatus.errorMessage = null;
				break;
			case dw.order.Order.ORDER_STATUS_CREATED:
				orderPlacementStatus = handlePayments(order, orderPlacementStatus);

				logger.info('[gestpayService.placeOrder] orderPlacementStatus {0} - decrypt {1}', JSON.stringify(orderPlacementStatus), decrypt);

				// place order
				if (!orderPlacementStatus.error && !orderPlacementStatus.redirect3dSecure) {
					logger.info('[gestpayService.placeOrder] processing order');

					// check Gestpay Guaranteed Payment
					var riskResponseCode;
					var paymentInstruments = [dw.order.PaymentInstrument.METHOD_CREDIT_CARD, 'PAYPAL']
						.map(function (paymentMethod) {
							return order.getPaymentInstruments(paymentMethod);
						})
						.reduce(function (acc, pi) {
							if (pi && pi.size() > 0) {
								acc = acc.concat(pi.toArray());
							}
							return acc;
						}, []);
					var isFraudPreventionEnabled = settings.isFraudPreventionEnabled() && paymentInstruments.length;
					if (isFraudPreventionEnabled && decrypt) {
						Transaction.wrap(function () {
							paymentInstruments[0].custom.fraudCheckMode = settings.getFraudPreventionMode();
							if (settings.isFraudPreventionInShadowMode()) {
								riskResponseCode = 'approved';
								order.trackOrderChange(
									[
										'PlaceOrder: ',
										paymentInstruments[0].getPaymentMethod(),
										' Fraud Prevention Approved (in Shadow Mode)',
									].join(' ')
								);
							} else {
								var riskResponse = wsS2S.callReadTrxS2S(decrypt.shopTransactionID, decrypt.bankTransactionID, order);
								if (riskResponse && riskResponse.object) {
									riskResponseCode = riskResponse.object.riskResponseCode.toLowerCase();

									paymentInstruments[0].custom.fraudCheckCode = riskResponseCode;
									var fraudCheckResponseList = [].concat(
										('fraudCheckResponseList' in paymentInstruments[0].custom &&
											paymentInstruments[0].custom.fraudCheckResponseList && paymentInstruments[0].custom.fraudCheckResponseList[0]) || []
									);
									fraudCheckResponseList.push(new Date().toDateString() + ' ' + riskResponseCode);
									paymentInstruments[0].custom.fraudCheckResponseList = fraudCheckResponseList;
									order.trackOrderChange(
										[
											'PlaceOrder: ',
											paymentInstruments[0].getPaymentMethod(),
											'fraudCheckResponse: ',
											JSON.stringify(fraudCheckResponseList),
										].join(' ')
									);
								}
							}
						});
					}

					if ((!isFraudPreventionEnabled || !riskResponseCode || (riskResponseCode && ['approved', 'captured'].indexOf(riskResponseCode) >= 0)) && (!decrypt || decrypt.transactionResult != 'XX')) {

						// Guaranteed Payment is not active or transaction has been approved

						var isFraudPreventionOn = settings.isFraudPreventionEnabled();
						var isCard = COHelpers.checkOrderPaymentMethod(order, "CREDIT_CARD");
						var isPaypal = COHelpers.checkOrderPaymentMethod(order, "PayPal");

						if (isFraudPreventionOn && (isCard || isPaypal)) {

							orderPlacementStatus.error = false;

						} else {

							logger.info('[gestpayService.placeOrder] Site {0}, place order', currentSiteId);
							let placeOrderResult = COHelpers.placeOrder(order, {});
							logger.info('[gestpayService.placeOrder] Site {0}, orderPlacementStatus: {1}', currentSiteId, JSON.stringify(placeOrderResult));

							orderPlacementStatus.error = placeOrderResult.error;
						}
					} else if (
						riskResponseCode &&
						(riskResponseCode === 'declined' || ['created', 'submitted'].indexOf(riskResponseCode) < 0)
					) {
						// transaction has been declined or some errors happend
						orderPlacementStatus = {
							error: true,
							Order: order,
							PlaceOrderError: new Status(Status.ERROR, 'confirm.error.declined'),
							fraudCheckDeclined: true,
						};
					} else {
						// riskResponseCode is still in status "created" or "submitted" or transactionResult is XX like MyBank, Sofort and Prezlewey24
						// but we give a positive response to the customer

						// build a positive orderPlacementStatus
						orderPlacementStatus = {
							Order: order,
							order_created: true,
							fraudCheckInProgress: true,
						};
						// send confirmation email if Fraud Prevention not enabled
						var isFraudPreventionOn = settings.isFraudPreventionEnabled();
						var isCard = COHelpers.checkOrderPaymentMethod(order, "CREDIT_CARD");
						var isPaypal = COHelpers.checkOrderPaymentMethod(order, "PayPal");
						var isKlarna = COHelpers.checkOrderPaymentMethod(order, "KLARNA");

						if (!(isKlarna) || (!isFraudPreventionEnabled && (isCard || isPaypal))) {
							sendConfirmationEmail(order, req);
						}

					}

					if (orderPlacementStatus.error) {
						handlePlaceOrderError(order, decrypt);
					} else {
						var isFraudPreventionOn = settings.isFraudPreventionEnabled();
						var isCard = COHelpers.checkOrderPaymentMethod(order, "CREDIT_CARD");
						var isPaypal = COHelpers.checkOrderPaymentMethod(order, "PayPal");
						var isKlarna = COHelpers.checkOrderPaymentMethod(order, "KLARNA");

						if (!(isKlarna) || (!isFraudPreventionEnabled && (isCard || isPaypal))) {
							sendConfirmationEmail(order, req);
						}
					}
				}
				break;
			default:
				logger.info(
					'[gestpayService.placeOrder] Site {0} order already placed, status: {1}',
					currentSiteId,
					order.status.value
				);
		}
	} catch (e) {
		var error = e;
		logger.error('[gestpayService.placeOrder] Site {0} error during call gestpayPlaceOrder: {1}', currentSiteId, error);
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange('Gestpay - gestpayPlaceOrder - error: ' + error);
			});

			Transaction.wrap(function () {
				OrderMgr.failOrder(order);
			});
		}
	} finally {
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange('place order result: ' + JSON.stringify(orderPlacementStatus));
			});
		}
	}
	return orderPlacementStatus;
}

/**
 * @param {dw.order.Order} order
 * @param {Object} orderPlacementStatus
 * @returns {Object}
 */
function handlePayments(order, orderPlacementStatus) {
	try {
		let handlePaymentsResult = COHelpers.handlePayments(order, order.orderNo);
		if (handlePaymentsResult.error) {
			orderPlacementStatus.error = true;
		} else if (handlePaymentsResult.redirect3dSecure) {
			orderPlacementStatus.redirect3dSecure = handlePaymentsResult.redirect3dSecure;
			orderPlacementStatus.error = false;
			orderPlacementStatus.errorMessage = null;
		} else {
			orderPlacementStatus.error = false;
			orderPlacementStatus.errorMessage = null;
		}
	} catch (e) {
		logger.error('[gestpayService.handlePayments] Site {0}: {1}', currentSiteId, e.message);
		orderPlacementStatus.error = true;
	}
	return orderPlacementStatus;
}

/**
 * @param {dw.order.Order} order
 */
function handlePlaceOrderError(order, decrypt) {
	try {
		logger.error('[gestpayService.placeOrder] Site {0} create order failed - callDeleteS2S', currentSiteId);

		let trx = wsS2S.callReadTrxS2S(decrypt.shopTransactionID, decrypt.bankTransactionID).getObject();
		if (trx.transactionResult == 'OK') {
			if (trx.transactionState == 'MOV') {
				let refundReason = 'create order failed - callDeleteS2S';
				let result = wsS2S.callRefundS2S(
					decrypt.currency,
					decrypt.amount,
					decrypt.shopTransactionID,
					decrypt.bankTransactionID,
					refundReason,
					true
				);
				logger.error(
					'[gestpayService.placeOrder] Site {0} callRefundS2S result: {1}',
					currentSiteId,
					JSON.stringify(result)
				);
			} else if (['AUT', 'PRE'].indexOf(trx.transactionState) >= 0) {
				let result = wsS2S.callDeleteS2S(decrypt.bankTransactionID, decrypt.shopTransactionID, 'create order failed');
				logger.error(
					'[gestpayService.placeOrder] Site {0} callDeleteS2S result: {1}',
					currentSiteId,
					JSON.stringify(result)
				);
			}
		} else {
			let result = wsS2S.callDeleteS2S(decrypt.bankTransactionID, decrypt.shopTransactionID, 'create order failed');
			logger.error(
				'[gestpayService.placeOrder] Site {0} callDeleteS2S result: {1}',
				currentSiteId,
				JSON.stringify(result)
			);
		}
	} catch (ex) {
		logger.error(ex);
	}
	switch (order.status.value) {
		case dw.order.Order.ORDER_STATUS_NEW:
		case dw.order.Order.ORDER_STATUS_OPEN:
		case dw.order.Order.ORDER_STATUS_COMPLETED:
			Transaction.wrap(function () {
				OrderMgr.cancelOrder(order);
			});
			break;
		case dw.order.Order.ORDER_STATUS_CREATED:
			Transaction.wrap(function () {
				OrderMgr.failOrder(order);
			});
			break;
	}
}

/**
 * Check 3d secure response
 */
function placeOrderBy3dSecureResponse(transKey, pares, orderNo, req) {
	let result = {};
	let order;
	let orderUtils = require('int_gestpay/cartridge/scripts/utils/orderUtils');
	try {
		order = OrderMgr.getOrder(orderNo);
		Transaction.wrap(function () {
			order.trackOrderChange('Gestpay - 3d secure response - call pagams2s with transKey and pares');
		});
		// find paymentInstrument
		let paymentInstruments = order
			.getPaymentInstruments()
			.toArray()
			.filter(function (paymentInstrument) {
				return paymentInstrument.paymentTransaction.custom.gestPayTransKey === transKey;
			});
		if (paymentInstruments.length == 1) {
			let paymentInstrument = paymentInstruments[0];
			let currency = paymentInstrument.paymentTransaction.amount.currencyCode;
			let amount = paymentInstrument.paymentTransaction.amount.decimalValue;
			var isCard = COHelpers.checkOrderPaymentMethod(order, "CREDIT_CARD");
			// call pagam S2S and track result
			let callPagamResult = wsS2S
				.callPagamS2S3DSecureResponse(amount, currency, orderNo, transKey, pares, order)
				.getObject();
			Transaction.wrap(function () {
				order.trackOrderChange('Gestpay - callPagamS2S3DSecureResponse: ' + JSON.stringify(callPagamResult));
			});
			// update transaction result
			orderUtils.changePaymentTransactionResult(paymentInstrument, order, callPagamResult.transactionResult);
			// check error code
			if (callPagamResult.errorCode == settings.getGestPayWsSuccessCode()) {
				Transaction.wrap(function () {
					paymentInstrument.paymentTransaction.transactionID = callPagamResult.bankTransactionID;
				});
				// place order
				if (settings.isFraudPreventionEnabled() && isCard) {
					result.error = false;

				} else {
					result = COHelpers.placeOrder(order, {});
					logger.info('orderPlacementStatus: ' + JSON.stringify(result));
				}
				// check place order error
				if (result.error) {
					// fail order
					Transaction.wrap(function () {
						OrderMgr.failOrder(order);
					});
					try {
						// delete gestpay transaction
						logger.error('create order failed - callDeleteS2S');
						let resultDelete = wsS2S.callDeleteS2S(
							callPagamResult.bankTransactionID,
							callPagamResult.shopTransactionID,
							'place order failed'
						);
						logger.error('callDeleteS2S result: ' + JSON.stringify(resultDelete));
					} catch (ex) {
						logger.error(ex);
					}
				} else {
					if (!(settings.isFraudPreventionEnabled() && isCard)) {
						sendConfirmationEmail(order, req);
					}
					result.error = false;
					result.orderToken = order.orderToken;
					result.orderID = order.orderNo;
				}
			}
		} else {
			result.error = true;
		}
	} catch (e) {
		result.error = true;
		logger.error(e);
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange('Gestpay - placeOrderBy3dSecureResponse - error: ' + e.message);
				OrderMgr.failOrder(order);
			});
		}
	}
	return result;
}
/**
 * Send confirmation email and reset usingMultiShip after successful Order
 * placement
 */
function sendConfirmationEmail(order, req) {
	COHelpers.sendConfirmationEmail(order, req.locale.id);
	req.session.privacyCache.set('usingMultiShipping', false);
}

function authorizeApplePay() {
	return {};
}

exports.placeOrder = placeOrder;

exports.createOrder = createOrder;

exports.placeOrderByNotificationObj = placeOrderByNotificationObj;

exports.placeOrderByCryptDecryptObj = placeOrderByCryptDecryptObj;

exports.placeOrderBy3dSecureResponse = placeOrderBy3dSecureResponse;

exports.placeOrderByCryptDecryptString = placeOrderByCryptDecryptString;

exports.authorizeApplePay = authorizeApplePay;