'use strict';

var Status = require('dw/system/Status');

/**
 * @param {object} args
 * @param {dw.value.Money} args.Amount
 * @param {dw.order.Basket} args.Basket
 */
function preEncrypt(args) {
  let amount = args.Amount;
  let basket = args.Basket;
  return dw.system.Transaction.wrap(function() {
    if (!basket.customerEmail) {
      basket.customerEmail = (customer.authenticated && customer.profile.email) || 'temporaryemail@axerve.com';
    }
    if (!basket.billingAddress) {
      basket.createBillingAddress();
      basket.billingAddress.setLastName('-');
    }

    basket
      .getShipments()
      .toArray()
      .filter(
        /**
         * 
         * @param {dw.order.Shipment} s
         */
        function(s) {
        return !s.shippingMethodID;
      })
      .forEach(function(s) {
        s.setShippingMethod(dw.order.ShippingMgr.defaultShippingMethod || dw.order.ShippingMgr.allShippingMethods[0]);
      });
    basket
      .getShipments()
      .toArray()
      .filter(function(s) {
        return !s.shippingAddress;
      })
      .forEach(function(s) {
        s.createShippingAddress();
      });

    if (dw.system.HookMgr.hasHook('dw.order.calculate')) {
      dw.system.HookMgr.callHook('dw.order.calculate', 'calculate', basket);
    }

    if (!amount || !amount.available) {
      amount = basket.getTotalGrossPrice();
    }
    basket
      .getPaymentInstruments('AMAZONPAY')
      .toArray()
      .forEach(function(pi) {
        basket.removePaymentInstrument(pi);
      });
      var paymentInstrument = basket.createPaymentInstrument('AMAZONPAY', amount);
      const orderUtils = require('int_gestpay/cartridge/scripts/utils/orderUtils');
      const settings = require('int_gestpay/cartridge/scripts/utils/settings');
      var PaymentMgr = require('dw/order/PaymentMgr');
      var processor = PaymentMgr.getPaymentMethod('AMAZONPAY').getPaymentProcessor();
      paymentInstrument.paymentTransaction.custom.gestPayShopTransactionID = orderUtils.createGestPayShopTransactionID(basket);
      paymentInstrument.paymentTransaction.paymentProcessor = processor;
      paymentInstrument.custom.gestPayShopLogin = session.custom.shopLogin ? session.custom.shopLogin : settings.getShopLogin();

    return {
      success: true,
    };
  });
}

/**
 *
 * @param {object} transactionInfo
 * @param {dw.order.Order} order
 */
function applyShippingMethod(transactionInfo, order) {
  order.shipments.toArray().forEach(function(shipment) {
    if (!shipment.shippingMethod) {
      shipment.setShippingMethod(dw.order.ShippingMgr.getDefaultShippingMethod());
    }
  });
  return new Status(Status.OK);
}

function copyProperties(source, target, mapping) {
  Object.keys(mapping).forEach(function(key) {
    if (source && key in source) {
      target[mapping[key]] = source[key];
    }
  });
}

/**
 * @param {object} sourceShippingAddress
 * @param {dw.order.Order} order
 */
function validateShippingAddress(sourceShippingAddress, order) {
    return new Status(Status.OK);
}

/**
 * @param {object} sourceShippingAddress
 * @param {dw.order.Order} order
 */
function copyShippingAddress(sourceShippingAddress, order) {
  order.shipments.toArray().forEach(function(shipment) {
    let shippingAddress = shipment.getShippingAddress();
    if (shippingAddress === null) {
      shippingAddress = shipment.createShippingAddress();
    }

    copyProperties(sourceShippingAddress, shippingAddress, {
      firstName: 'firstName',
      lastName: 'lastName',
      address1: 'address1',
      address2: 'address2',
      city: 'city',
      postal: 'postalCode',
      country: 'countryCode',
      phone: 'phone',
      stateOrRegion: 'stateCode',
    });
  });

  return new Status(Status.OK);
}

/**
 * @param {object} sourceBillingAddress
 * @param {dw.order.Order} order
 */
function validateBillingAddress(sourceBillingAddress, order) {
    return new Status(Status.OK);
}

/**
 * @param {object} sourceBillingAddress
 * @param {dw.order.Order} order
 */
function copyBillingAddress(sourceBillingAddress, order, transactionInfo) {
  /** @type {dw.order.OrderAddress} */
  var billingAddress = order.getBillingAddress();
  if (!billingAddress) {
    billingAddress = order.createBillingAddress();
  }

  copyProperties(sourceBillingAddress, billingAddress, {
    firstName: 'firstName',
    lastName: 'lastName',
    address1: 'address1',
    address2: 'address2',
    city: 'city',
    postal: 'postalCode',
    country: 'countryCode',
    phone: 'phone',
    stateOrRegion: 'stateCode',
  });

  if (order.getCustomerEmail() === null) {
    if (!empty(transactionInfo.buyerEmail)) {
      order.setCustomerEmail(transactionInfo.buyerEmail);
    } else if (customer.authenticated && customer.profile.email !== null) {
      order.setCustomerEmail(customer.profile.email);
    }
  }

  return new Status(Status.OK);
}

module.exports.preEncrypt = preEncrypt;
module.exports.validateShippingAddress = validateShippingAddress;
module.exports.copyShippingAddress = copyShippingAddress;
module.exports.applyShippingMethod = applyShippingMethod;
module.exports.validateBillingAddress = validateBillingAddress;
module.exports.copyBillingAddress = copyBillingAddress;
