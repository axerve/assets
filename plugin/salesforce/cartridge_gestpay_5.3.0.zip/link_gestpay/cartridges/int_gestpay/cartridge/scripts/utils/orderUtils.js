'use strict';
/**
 * Utility for setup basic info before soap calls, create order detail for
 * riskified and alternative payment methods like klarna
 */
var log = dw.system.Logger.getLogger('GestPay', '');
var settings = require('int_gestpay/cartridge/scripts/utils/settings');

const currentSiteId = dw.system.Site.getCurrent().getID();

function setUpBasicInfo(lineItemCtnr) {
	var paymentInstrumentAmount = lineItemCtnr.getTotalGrossPrice().decimalValue;
	if (dw.system.HookMgr.hasHook('gestpay.paymentInstrumentAmount')) {
		paymentInstrumentAmount = dw.system.HookMgr.callHook(
			'gestpay.paymentInstrumentAmount',
			'computePaymentInstrumentAmount', {
				lineItemCtnr: lineItemCtnr
			}
		);
	}
	var result = {
		currency: lineItemCtnr.getCurrencyCode(),
		amount: paymentInstrumentAmount
	};
	if (!empty(lineItemCtnr.getCustom().bankTransactionID)) {
		result.bankTransactionID = lineItemCtnr.getCustom().bankTransactionID;
	}
	return result;
}

function extendWithBasicParams(lineItemCtnr, obj) {
	var basicInfo = setUpBasicInfo(lineItemCtnr);
	for (var i in basicInfo) {
		if (!obj[i]) {
			obj[i] = basicInfo[i];
		}
	}
	return obj;
}

/**
 * @param {dw.order.Basket} basket
 */
function createGestPayShopTransactionID(basket) {
	basket = basket || dw.order.BasketMgr.getCurrentBasket();
	return (basket.getUUID() + '-' + (Math.random() * 1000).toFixed(0)).slice(
		-20
	);
}

function getCategory(product) {
	if (product.primaryCategory) return product.primaryCategory.ID;
	if (product.categories && product.categories.size() > 0)
		return product.categories.iterator().next().ID;
	return null;
}

/**
 * @param {dw.order.LineItemCtnr} lineItemCtnr
 * @param {*} objecFactory
 */
function createOrderDetails(lineItemCtnr, objecFactory) {
	try {
		if (lineItemCtnr != null) {
			var root = objecFactory.createEcommGestpayPaymentDetails();
			var customerDetail = objecFactory.createCustomerDetail();
			var fraudPrevention = objecFactory.createFraudPrevention();
			var shippingAddress = objecFactory.createShippingAddress();
			var billingAddress = objecFactory.createBillingAddress();
			var arrayOfProductDetail = objecFactory.createArrayOfProductDetail();
			var arrayOfShippingLine = objecFactory.createArrayOfShippingLine();

			var paymentInstruments = lineItemCtnr.getPaymentInstruments().toArray();
			var isCC = paymentInstruments.some(function (pi) {
				var pm = dw.order.PaymentMgr.getPaymentMethod(pi.paymentMethod);
				return pm.paymentProcessor.ID === 'GESTPAY_CREDIT';
			});
			var isPayPal = paymentInstruments.some(function (pi) {
				return pi.paymentMethod === 'PAYPAL';
			});
			var isFraudPreventionEnabled =
				settings.isFraudPreventionEnabled() && (isCC || isPayPal);

			var isKlarna = paymentInstruments.some(function (pi) {
				return pi.paymentMethod === 'S2PKLA' || pi.paymentMethod === 'KLARNA' || pi.paymentMethod === 'KLARNAPAYNOW';
			});

			var onlyEmail = paymentInstruments.some(function (pi) {
				return pi.paymentMethod === 'S2PYAN';
			});

			var onlyEmailAndPhone = paymentInstruments.some(function (pi) {
				return pi.paymentMethod === 'S2PUNI';
			});

			var isCardRu = paymentInstruments.some(function (pi) {
				return pi.paymentMethod === 'S2PCRU';
			});

			try {
				if (isFraudPreventionEnabled) {
					fraudPrevention.setBeaconSessionID(session.getSessionID());
					fraudPrevention.setOrderDateTime(lineItemCtnr.getCreationDate());
					fraudPrevention.setOrderNote('');
					fraudPrevention.setSource('website');
					fraudPrevention.setSubmissionReason('rule_decision');
					fraudPrevention.setSubmitForReview(
						settings.isFraudPreventionEnabled() ? '1' : '0'
					);
					fraudPrevention.setVendorID(
						settings.getVendorID() || dw.system.Site.current.ID
					);
					fraudPrevention.setVendorName(
						settings.getVendorName() || dw.system.Site.current.ID
					);

					if (
						dw.system.HookMgr.hasHook(
							'gestpay.createorderdetails.fraudPrevention'
						)
					) {
						fraudPrevention = dw.system.HookMgr.callHook(
							'gestpay.createorderdetails.fraudPrevention',
							'process',
							fraudPrevention
						);
					}
				}
			} catch (e) {
				log.error(
					'Site {0}, Error during create order detail - fraudPrevention: {1}',
					currentSiteId,
					e.message
				);
			}

			try {
				if (onlyEmail) {
					customerDetail.setPrimaryEmail(lineItemCtnr.getCustomerEmail());
				} else {
					customerDetail.setPrimaryEmail(lineItemCtnr.getCustomerEmail());
					if (
						lineItemCtnr.customer != null &&
						lineItemCtnr.customer.profile != null && onlyEmailAndPhone
					) {
						var customerProfile = lineItemCtnr.customer.profile;
						customerDetail.setPrimaryPhone(customerProfile.getPhoneMobile());
					} else if (lineItemCtnr.customer != null &&
						lineItemCtnr.customer.profile != null) {
						var customerProfile = lineItemCtnr.customer.profile;
						customerDetail.setCompany(
							lineItemCtnr.billingAddress != null ?
							lineItemCtnr.billingAddress.companyName :
							''
						);
						customerDetail.setCreatedAtDate(
							dw.util.StringUtils.formatCalendar(
								new dw.util.Calendar(customerProfile.getCreationDate()),
								'dd/MM/yyyy'
							)
						);
						customerDetail.setFirstName(customerProfile.getFirstName());
						customerDetail.setLastname(customerProfile.getLastName());
						customerDetail.setMerchantCustomerID(lineItemCtnr.customer.ID);
						customerDetail.setPrimaryPhone(customerProfile.getPhoneMobile());
						customerDetail.setMiddleName(customerProfile.getSecondName());
						customerDetail.setProfileID(customerProfile.getCustomerNo());
						customerDetail.setVerifiedEmail(customer.authenticated);
						if (customerProfile.getGender() !== null) {
							customerDetail.setGender(customerProfile.female ? 1 : 0);
						}
						if (customerProfile.birthday != null) {
							customerDetail.setDateOfBirth(
								dw.util.StringUtils.formatCalendar(
									new dw.util.Calendar(customerProfile.birthday),
									'dd/MM/yyyy'
								)
							);
						}
					} else {
						if (onlyEmailAndPhone && lineItemCtnr.billingAddress != null) {
							customerDetail.setPrimaryPhone(lineItemCtnr.billingAddress.phone);
						} else if (lineItemCtnr.billingAddress != null) {
							customerDetail.setCompany(lineItemCtnr.billingAddress.companyName);
							customerDetail.setCreatedAtDate(
								dw.util.StringUtils.formatCalendar(
									new dw.util.Calendar(
										lineItemCtnr.billingAddress.getCreationDate()
									),
									'dd/MM/yyyy'
								)
							);
							customerDetail.setFirstName(lineItemCtnr.billingAddress.firstName);
							customerDetail.setLastname(lineItemCtnr.billingAddress.lastName);
							customerDetail.setPrimaryPhone(lineItemCtnr.billingAddress.phone);
						}
						if (!onlyEmailAndPhone) {
							customerDetail.setVerifiedEmail(false);
							if (lineItemCtnr.customer != null) {
								customerDetail.setMerchantCustomerID(lineItemCtnr.customer.ID);
							}
						}
					}
				}
			} catch (e) {
				log.error(
					'Site {0}, Error during create order detail - customerDetail: {1}',
					e.message
				);
			}

			try {
				if (
					lineItemCtnr.shipments != null &&
					lineItemCtnr.shipments.length > 0
				) {
					var shipment = lineItemCtnr.shipments.iterator().next();
					var shippingAddressItem = shipment.shippingAddress;

					var shipToStore = false;
					if (
						dw.system.HookMgr.hasHook('gestpay.createorderdetails.shiptostore')
					) {
						shipToStore = dw.system.HookMgr.callHook(
							'gestpay.createorderdetails.shiptostore',
							'process',
							shipment
						);
					}

					if (!shipToStore) {
						shippingAddress.setFirstName(shippingAddressItem.firstName);
						shippingAddress.setLastname(shippingAddressItem.lastName);
					}

					shippingAddress.setCity(shippingAddressItem.city);
					shippingAddress.setCompany(shippingAddressItem.companyName);
					shippingAddress.setCountryCode(
						shippingAddressItem.countryCode.value.toUpperCase()
					);
					shippingAddress.setEmail(lineItemCtnr.getCustomerEmail());
					shippingAddress.setMiddleName(shippingAddressItem.secondName);
					shippingAddress.setPrimaryPhone(shippingAddressItem.phone);
					shippingAddress.setProfileID(
						lineItemCtnr.customer.profile ?
						lineItemCtnr.customer.profile.getCustomerNo() :
						null
					);
					shippingAddress.setSecondaryPhone('');
					shippingAddress.setStateCode(shippingAddressItem.stateCode);
					shippingAddress.setStreetName(shippingAddressItem.address1);
					shippingAddress.setStreetname2(shippingAddressItem.address2);
					shippingAddress.setZipCode(shippingAddressItem.postalCode);

					if (
						isKlarna &&
						dw.system.HookMgr.hasHook('gestpay.createorderdetails.klarna')
					) {
						shippingAddress = dw.system.HookMgr.callHook(
							'gestpay.createorderdetails.klarna',
							'fillShippingAddress',
							shippingAddress
						);
					}
				}
			} catch (e) {
				log.error('Error during create order detail - shippingAddress: ' + e);
				log.error(e);
			}

			try {
				if (lineItemCtnr.billingAddress != null) {
					var billingAddressLineItem = lineItemCtnr.billingAddress;

					billingAddress.setCountryCode(
						billingAddressLineItem.countryCode.value.toUpperCase()
					);
					billingAddress.setCity(billingAddressLineItem.city);
					billingAddress.setCompany(billingAddressLineItem.companyName);
					billingAddress.setEmail(lineItemCtnr.getCustomerEmail());
					billingAddress.setFirstName(billingAddressLineItem.firstName);
					billingAddress.setLastname(billingAddressLineItem.lastName);
					billingAddress.setMiddleName(billingAddressLineItem.secondName);
					billingAddress.setPrimaryPhone(billingAddressLineItem.phone);
					billingAddress.setProfileID(
						lineItemCtnr.customer.profile ?
						lineItemCtnr.customer.profile.getCustomerNo() :
						null
					);
					billingAddress.setStateCode(billingAddressLineItem.stateCode);
					billingAddress.setStreetName(billingAddressLineItem.address1);
					billingAddress.setStreetname2(billingAddressLineItem.address2);
					billingAddress.setZipCode(billingAddressLineItem.postalCode);

					if (
						isKlarna &&
						dw.system.HookMgr.hasHook('gestpay.createorderdetails.klarna')
					) {
						billingAddress = dw.system.HookMgr.callHook(
							'gestpay.createorderdetails.klarna',
							'fillBillingAddress',
							billingAddress
						);
					}
				}
			} catch (e) {
				log.error('Error during create order detail - billingAddress: ' + e);
				log.error(e);
			}

			try {
				var productDetails = arrayOfProductDetail.getProductDetail();
				var paymentInstrumentAmount = lineItemCtnr.getTotalNetPrice();
				var productShippingLinesGrossPrice = new dw.value.Money(0, lineItemCtnr.currencyCode);
				lineItemCtnr.getAllLineItems().toArray().filter(function (lineItem) {
					return lineItem instanceof dw.order.ProductShippingLineItem;
				}).forEach(function (lineItem) {
					productShippingLinesGrossPrice = productShippingLinesGrossPrice.add(lineItem.getAdjustedGrossPrice());
				});
				if (dw.system.HookMgr.hasHook('gestpay.paymentInstrumentAmount')) {
					paymentInstrumentAmount = dw.system.HookMgr.callHook(
						'gestpay.paymentInstrumentAmount',
						'computePaymentInstrumentAmount', {
							lineItemCtnr: lineItemCtnr
						}
					);
				}

				if (
					lineItemCtnr != null &&
					lineItemCtnr.getProductLineItems() != null
				) {
					var plis = lineItemCtnr.getProductLineItems().iterator();
					while (plis.hasNext()) {
						var pli = plis.next();
						if (pli.product != null) {
							// product detail
							var productDetail = objecFactory.createProductDetail();

							var productPrice = Number(pli.getAdjustedGrossPrice().divide(pli.quantity.value).getValue().toFixed(2));
							paymentInstrumentAmount = paymentInstrumentAmount.subtract(
								pli.getAdjustedGrossPrice()
							).subtract(productShippingLinesGrossPrice);

							if (productPrice > 0) {
								productDetail.setBrand(pli.product.brand);
								productDetail.setCategory(
									pli.categoryID ||
									getCategory(pli.product) ||
									getCategory(pli.product.variationModel.master)
								);
								productDetail.setName(pli.product.name);
								productDetail.setProductCode((pli.product.EAN || pli.product.ID).substr(0, 12));
								productDetail.setQuantity(pli.quantity.value);
								productDetail.setSKU(pli.manufacturerSKU || pli.product.ID);
								productDetail.setPrice(productPrice);
								productDetail.setUnitPrice(productPrice);

								var types = {
									PHYSICAL: 1
								};
								var productType = types.PHYSICAL;

								if (isKlarna) {
									types = {
										PHYSICAL: 5,
										DIGITAL: 8,
										GIFTCARD: 9
									};
									productType = types.PHYSICAL;
									if (
										dw.system.HookMgr.hasHook(
											'gestpay.createorderdetails.klarna'
										)
									) {
										productType = dw.system.HookMgr.callHook(
											'gestpay.createorderdetails.klarna',
											'getProductType', {
												product: pli.product,
												types: types
											}
										);
									}
								} else if (isFraudPreventionEnabled) {
									types = {
										PHYSICAL: 'physical',
										DIGITAL: 'digital',
										TRAVEL: 'travel',
										EVENT: 'event'
									};
									// @ts-ignore
									productType = types.PHYSICAL;
									if (
										dw.system.HookMgr.hasHook(
											'gestpay.createorderdetails.producttype'
										)
									) {
										productType = dw.system.HookMgr.callHook(
											'gestpay.createorderdetails.producttype',
											'process', {
												product: pli.product,
												types: types
											}
										);
									}
								}
								productDetail.setType(productType);
								productDetail.setRequiresShipping(
									productType === types.PHYSICAL
								);

								productDetails.add(productDetail);
							}
						}
					}

					/*if (isKlarna && paymentInstrumentAmount.getValue() > 0) {
						var productDetail = objecFactory.createProductDetail();

						productDetail.setBrand('discount');
						productDetail.setCategory('discount');
						productDetail.setName('discount');
						productDetail.setProductCode('discount');
						productDetail.setQuantity(1);
						productDetail.setType(4); // order discount
						productDetail.setSKU('discount');
						productDetail.setPrice((paymentInstrumentAmount.getValue() * -1).toFixed(2));
						productDetail.setRequiresShipping(false);

						productDetails.add(productDetail);
					}*/

					if (isKlarna) {

						if (lineItemCtnr.priceAdjustments && lineItemCtnr.priceAdjustments.length > 0) {

							for (var i = 0; i < lineItemCtnr.priceAdjustments.length; i++) {

								if (lineItemCtnr.priceAdjustments[i].grossPrice.valueOrNull) {
									var productDetail = objecFactory.createProductDetail();

									productDetail.setBrand('discount');
									productDetail.setCategory('discount');
									productDetail.setName('discount');
									productDetail.setProductCode('discount');
									productDetail.setQuantity(1);
									productDetail.setType(4); // order discount
									productDetail.setSKU('discount');
									productDetail.setPrice((lineItemCtnr.priceAdjustments[i].grossPrice.value).toFixed(2));
									productDetail.setRequiresShipping(false);

									productDetails.add(productDetail);
								}

							}

						}

						var shipmentsI = lineItemCtnr.shipments.iterator();
						while (shipmentsI.hasNext()) {
							var shipment = shipmentsI.next();
							if (shipment != null) {
								var productDetail = objecFactory.createProductDetail();
								productDetail.setBrand('shipping');
								productDetail.setCategory('shipping');
								productDetail.setName('shipping');
								productDetail.setProductCode('shipping');
								productDetail.setQuantity(1);
								productDetail.setType(6); // shipping fee
								productDetail.setSKU('shipping');
								productDetail.setPrice(shipment.shippingTotalGrossPrice.decimalValue);
								productDetail.setRequiresShipping(false);
								productDetails.add(productDetail);
							}
						}

						if (lineItemCtnr.allShippingPriceAdjustments && lineItemCtnr.allShippingPriceAdjustments.length > 0) {

							for (var i = 0; i < lineItemCtnr.allShippingPriceAdjustments.length; i++) {

								if (lineItemCtnr.allShippingPriceAdjustments[i].grossPrice.valueOrNull) {
									var productDetail = objecFactory.createProductDetail();

									productDetail.setBrand('discount');
									productDetail.setCategory('discount');
									productDetail.setName('discount');
									productDetail.setProductCode('discount');
									productDetail.setQuantity(1);
									productDetail.setType(4); // order discount
									productDetail.setSKU('discount');
									productDetail.setPrice((lineItemCtnr.allShippingPriceAdjustments[i].grossPrice.value).toFixed(2));
									productDetail.setRequiresShipping(false);

									productDetails.add(productDetail);
								}

							}

						}
					}


					/*
					          if (paymentInstrumentAmount > 0) {
					              // add fake product for fix price
					              var productDetail = objecFactory.createProductDetail();

					              productDetail.setBrand('fix_price');
					              productDetail.setCategory('fix_price');
					              productDetail.setName('fix_price');
					              productDetail.setProductCode('fix_price');
					              productDetail.setQuantity(1);
					              productDetail.setType('1');
					              productDetail.setSKU('fix_price');
					              productDetail.setPrice(paymentInstrumentAmount);

					              productDetails.add(productDetail);
					          }*/
				}
			} catch (e) {
				log.error(
					'Error during create order detail - arrayOfProductDetail: ' + e
				);
			}
			/*
			 * Shiping line
			 */
			try {
				var shippingLines = arrayOfShippingLine.getShippingLine();
				if (
					lineItemCtnr != null &&
					lineItemCtnr.getAllShippingPriceAdjustments() != null
				) {
					var shipments = lineItemCtnr.shipments;
					if (!shipments) {
						shipments = new dw.util.ArrayList(
							lineItemCtnr.getDefaultShipment()
						);
					}
					var shipmentsI = lineItemCtnr.shipments.iterator();
					while (shipmentsI.hasNext()) {
						var shipment = shipmentsI.next();
						if (shipment != null) {
							var shippingLine = objecFactory.createShippingLine();
							shippingLine.setCode(shipment.shipmentNo);
							shippingLine.setPrice(
								shipment.shippingTotalGrossPrice.decimalValue
							);
							shippingLine.setTitle(
								(shipment.shippingMethod &&
									shipment.shippingMethod.displayName) ||
								'Shipping'
							);

							shippingLines.add(shippingLine);
						}
					}
				}
			} catch (e) {
				log.error(
					'Site {0}, Error during create order detail - arrayOfShippingLine: {1}',
					currentSiteId,
					e.message
				);
			}
			// add fraud prevention tag
			if (!isKlarna && isFraudPreventionEnabled) {
				root.setFraudPrevention(fraudPrevention);
			}

			if (onlyEmail || onlyEmailAndPhone) {
				root.setCustomerDetail(customerDetail);
			} else {
				// add customer detail tag
				root.setCustomerDetail(customerDetail);
				// add billing address tag
				root.setBillingAddress(billingAddress);
				// add shipping address tag
				root.setShippingAddress(shippingAddress);
				// add shipping lines tag
				if (!isKlarna) {
					root.setShippingLines(arrayOfShippingLine);
				}

				// add product detail tag
				if (!isCardRu) {
					root.setProductDetails(arrayOfProductDetail);
				}
			}


			return root;
		}
	} catch (e) {
		log.error(
			'[orderUtils.createOrderDetails] Site {0}: {1}',
			currentSiteId,
			e
		);
	}
	return null;
}

exports.changePaymentTransactionResult = function (
	paymentInstrument,
	order,
	transactionResult
) {
	dw.system.Transaction.wrap(function () {
		order.trackOrderChange(
			'Change gestPayTransactionResult - new value: ' + transactionResult
		);
		paymentInstrument.custom.gestPayTransactionResult = transactionResult;
		order.custom.gestPayTransactionResult = transactionResult;
	});
};

function createShippingDetails(lineItemCtnr, objecFactory) {

	var shipment = lineItemCtnr.shipments[0]
	var shippingAddressItem = shipment.shippingAddress;

	var shippingDetails = objecFactory.createShippingDetails();

	shippingDetails.setShipToName(shippingAddressItem.lastName + " " + shippingAddressItem.firstName);
	shippingDetails.setShipToCity(shippingAddressItem.city);
	shippingDetails.setShipToCountryCode(shippingAddressItem.countryCode);
	shippingDetails.setShipToState(shippingAddressItem.stateCode);
	shippingDetails.setShipToStreet(shippingAddressItem.address1);
	shippingDetails.setShipToStreet2(shippingAddressItem.address2);
	shippingDetails.setShipToZip(shippingAddressItem.postalCode);

	return shippingDetails;
}

exports.createShippingDetails = createShippingDetails;

exports.createOrderDetails = createOrderDetails;

/**
 * Extends the given object with the basic parameters from the LineItemCtnr
 */
exports.extendWithBasicParams = extendWithBasicParams;
/**
 * Sets the basic parameters from the LineItemCtnr object: number, currency,
 * amount and bankTransactionID
 */
exports.setUpBasicInfo = setUpBasicInfo;

exports.createGestPayShopTransactionID = createGestPayShopTransactionID;