/**
 * GestPay WSs2s web service Server to Server communication between merchants
 * and GestPay is managed by consuming WSs2s SOAP web service. Consuming WSs2s
 * methods allow merchants to send requests and retrieve responses in XML
 * format.
 */
const gestpay = require('int_gestpay/cartridge/scripts/gestpay');
const orderUtils = require('int_gestpay/cartridge/scripts/utils/orderUtils');
const settings = require('int_gestpay/cartridge/scripts/utils/settings');
const utils = require('int_gestpay/cartridge/scripts/utils/utils');
const log = utils.getLogger();
const myPackageS2S = utils.getPackageS2S();
const WSs2sSoapFactory = new webreferences2[myPackageS2S].ObjectFactory();


function callPagamS2S3DSecureResponse(amount, currency, shopTransactionID, transkey, pares, order) {
	let params = {
		amount : amount,
		currency : currency,
		shopTransactionID : shopTransactionID,
		transkey : transkey,
		pares : pares,
		orderDetails : orderUtils.createOrderDetails(order, WSs2sSoapFactory)
	};
	let result = gestpay.callPagamS2S(params);
	return result;
}

/**
 * @param {number} amount
 * @param {string} currency
 * @param {string} shopTransactionID
 * @param {string} cardNumber
 * @param {string} expiryMonth
 * @param {string} expiryYear
 * @param {string} tokenValue
 * @param {string} cvv
 * @param {dw.order.OrderPaymentInstrument} orderPaymentInstrument
 * @param {dw.order.Order} order
 */
function callPagamS2S(amount, currency, shopTransactionID, cardNumber, expiryMonth, expiryYear, tokenValue, cvv, orderPaymentInstrument, order) {
	let params = {
		amount : amount,
		currency : currency,
		shopTransactionID : shopTransactionID,
		cardNumber : cardNumber,
		expiryMonth : ("0" + expiryMonth).slice(-2),
		expiryYear : ("" + expiryYear).slice(-2),
		tokenValue : tokenValue,
		cvv : cvv,
		customInfo : [ settings.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID, '=', (orderPaymentInstrument ? orderPaymentInstrument.getUUID() : '') ].join(''),
		orderDetails : orderUtils.createOrderDetails(order, WSs2sSoapFactory),
		order: order,
		buyerEmail: order.getCustomerEmail()
	};
	let result = gestpay.callPagamS2S(params);
	return result;
}

/**
 * @param {number} amount
 * @param {string} currency
 * @param {string} shopTransactionID
 * @param {object} applePaymentToken
 * @param {dw.order.OrderPaymentInstrument} orderPaymentInstrument
 * @param {dw.order.Order} order
 * @returns {dw.svc.Result}
 */
function callPagamAppleS2S(amount, currency, shopTransactionID, applePaymentToken, orderPaymentInstrument, order) {
	let params = {
		amount: amount,
		currency: currency,
		shopTransactionID: shopTransactionID,
		applePaymentToken: applePaymentToken,
		customInfo: [ settings.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID, '=', (orderPaymentInstrument ? orderPaymentInstrument.getUUID() : '') ].join(''),
		orderDetails: orderUtils.createOrderDetails(order, WSs2sSoapFactory),
		order: order
	};
	let result = gestpay.callPagamS2S(params);
	return result;
}

function callPagamS2SWithOrder(lineItemCtnr, paymentValue) {
	let params = orderUtils.extendWithBasicParams(lineItemCtnr, {
		cardNumber : paymentValue.cardNumber,
		expiryMonth : paymentValue.expiryMonth,
		expiryYear : paymentValue.expiryYear,
		tokenValue : paymentValue.tokenValue,
		cvv : paymentValue.cvv,
		orderDetails : orderUtils.createOrderDetails(lineItemCtnr, WSs2sSoapFactory),
		order: lineItemCtnr
	});
	let result = gestpay.callPagamS2S(params);
	return result;
}

function callSettleS2S(amount, currency, bankTransactionID, shopTransactionID, fullFillment, uicCode) {
	let params = {
		amount : amount,
		currency : currency,
		uicCode: uicCode,
		bankTransactionID : bankTransactionID,
		shopTransactionID : shopTransactionID,
		fullFillment : fullFillment
	};
	let result = gestpay.callSettleS2S(params);
	return result;
}

function callSettleS2SWithOrder(lineItemCtnr, fullFillment) {
	let params = orderUtils.extendWithBasicParams(lineItemCtnr, {
		fullFillment : fullFillment
	});

	let result = gestpay.callSettleS2S(params);
	return result;
}

function callDeleteS2S(bankTransactionID, shopTransactionID, cancelReason) {
	let params = {
		bankTransactionID : bankTransactionID,
		shopTransactionID : shopTransactionID,
		cancelReason : cancelReason
	};
	let result = gestpay.callDeleteS2S(params);
	return result;
}

function callDeleteS2SWithOrder(lineItemCtnr, params) {
	let callDeleteS2SRequest = orderUtils.extendWithBasicParams(lineItemCtnr, {
		bankTransactionID : params.bankTransactionID,
		shopTransactionID : params.shopTransactionID,
		cancelReason : params.cancelReason
	});
	let result = gestpay.callDeleteS2S(callDeleteS2SRequest);
	return result;
}

function callRefundS2S(currency, amount, shopTransactionID, bankTransactionID, refundReason, chargeBackFraud) {
	let params = {
		shopTransactionID : shopTransactionID,
		currency : currency,
		bankTransactionID : bankTransactionID,
		amount : amount,
		refundReason : refundReason,
		chargeBackFraud : chargeBackFraud
	};
	let result = gestpay.callRefundS2S(params);
	return result;
}

function callRefundS2SWithOrder(lineItemCtnr, params) {
	let callRefundRequest = orderUtils.extendWithBasicParams(lineItemCtnr, {
		bankTransactionID : params.bankTransactionID,
		shopTransactionID : params.shopTransactionID,
		amount : params.amount,
		refundReason : params.refundReason,
		chargeBackFraud : params.chargeBackFraud
	});
	let result = gestpay.callRefundS2S(callRefundRequest);
	return result;
}

function callReadTrxS2S(shopTransactionID, bankTransactionID, order) {
	let params = {
		shopTransactionID : shopTransactionID,
		bankTransactionID : bankTransactionID
	};
	if (order) {
		params.order = order;
	}
	let result = gestpay.callReadTrxS2S(params);
	return result;
}

function callReadTrxS2SWithOrder(lineItemCtnr, params) {
	let callReadTrxS2SRequest = orderUtils.extendWithBasicParams(lineItemCtnr, {
		bankTransactionID : params.bankTransID
	});
	let result = gestpay.callReadTrxS2S(callReadTrxS2SRequest);
	return result;
}

function callVerifycardS2S(shopTransactionID, cardNumber, expMonth, expYear, cvv2) {
	let params = {
		shopTransactionID : shopTransactionID,
		cardNumber : cardNumber,
		expMonth : expMonth,
		expYear : expYear,
		cvv2 : cvv2
	};
	let result = gestpay.callVerifycardS2S(params);
	return result;
}

function callVerifycardS2SWithOrder(lineItemCtnr, params) {
	let callVerifycardS2SRequest = orderUtils.extendWithBasicParams(lineItemCtnr, {
		cardNumber : params.cardNumber,
		expMonth : params.expMonth,
		expYear : params.expYear,
		cvv2 : params.cvv2
	});
	let result = gestpay.callVerifycardS2S(callVerifycardS2SRequest);
	return result;
}

function callCheckCartaS2S(shopTransactionID, cardNumber, expMonth, expYear, cvv2, tokenValue, withAuth, more) {
	let params = {
		shopTransactionID: shopTransactionID,
		withAuth: withAuth
	};
	if (empty(tokenValue)) {
		params.cardNumber = cardNumber;
		params.expMonth = ("00" + expMonth).slice(-2);
		params.expYear = ("" + expYear).slice(-2);
		params.cvv2 = cvv2;
	} else {
		params.tokenValue = tokenValue;
	}
	if (more) {
		params.shopLogin = more.shopLogin;
	}
	let result = gestpay.callCheckCartaS2S(params);
	return result;
}

function callCheckCartaS2SWithOrder(lineItemCtnr, params) {
	let callCheckCartaS2SRequest = orderUtils.extendWithBasicParams(lineItemCtnr, {
		cardNumber : params.cardNumber,
		expMonth : params.expMonth,
		expYear : params.expYear,
		cvv2 : params.cvv2,
		tokenValue : params.tokenValue,
		withAuth : params.withAuth
	});
	let result = gestpay.callCheckCartaS2S(callCheckCartaS2SRequest);
	return result;
}

function callRequestTokenS2S(requestToken, cardNumber, expMonth, expYear, cvv2, withAuth) {
	let params = {
		cardNumber : cardNumber,
		expMonth : expMonth,
		expYear : expYear,
		cvv2 : cvv2,
		withAuth : withAuth,
		requestToken : requestToken
	};
	let result = gestpay.callRequestTokenS2S(params);
	return result;
}

function callDeleteTokenS2S(tokenValue) {
	let params = {
		tokenValue : tokenValue
	};
	let result = gestpay.callDeleteTokenS2S(params);
	return result;
}

function callUpdateTokenS2S(tokenValue, expMonth, expYear, withAut) {
	let params = {
		tokenValue : tokenValue,
		expMonth : expMonth,
		expYear : expYear,
		withAut : withAut
	};
	let result = gestpay.callUpdateTokenS2S(params);
	return result;
}

function callIdealListS2S() {
	let result = gestpay.callIdealListS2S();
	return result;
}

function callMyBankListS2S(params) {
	let callMyBankListS2SRequest = {
		languageId : params.languageId
	};
	let result = gestpay.callMyBankListS2S(callMyBankListS2SRequest);
	return result;
}

function callUpdateOrderS2S(lineItemCtnr, params) {
	let callUpdateOrderS2SRequest = orderUtils.extendWithBasicParams(lineItemCtnr, {
		bankTransactionId : params.bankTransID,
		orderDetails : params.orderDetails
	});
	let result = gestpay.callUpdateOrderS2S(callUpdateOrderS2SRequest);
	return result;
}

/*
 * callPagamS2S method
 */
exports.callPagamS2S = callPagamS2S;
exports.callPagamAppleS2S = callPagamAppleS2S;
exports.callPagamS2SWithOrder = callPagamS2SWithOrder;
exports.callPagamS2S3DSecureResponse = callPagamS2S3DSecureResponse;
/*
 * callSettleS2S method
 */
exports.callSettleS2S = callSettleS2S;
exports.callSettleS2SWithOrder = callSettleS2SWithOrder;
/*
 * callDeleteS2S method
 */
exports.callDeleteS2S = callDeleteS2S;
exports.callDeleteS2SWithOrder = callDeleteS2SWithOrder;
/*
 * callRefundS2S method
 */
exports.callRefundS2S = callRefundS2S;
exports.callRefundS2SWithOrder = callRefundS2SWithOrder;
/*
 * callReadTrxS2S method
 */
exports.callReadTrxS2S = callReadTrxS2S;
exports.callReadTrxS2SWithOrder = callReadTrxS2SWithOrder;
/*
 * callVerifycardS2S method
 */
exports.callVerifycardS2S = callVerifycardS2S;
exports.callVerifycardS2SWithOrder = callVerifycardS2SWithOrder;
/*
 * callCheckCartaS2S method
 */
exports.callCheckCartaS2S = callCheckCartaS2S;
exports.callCheckCartaS2SWithOrder = callCheckCartaS2SWithOrder;
/*
 * callRequestTokenS2S method
 */
exports.callRequestTokenS2S = callRequestTokenS2S;
/*
 * callDeleteTokenS2S method
 */
exports.callDeleteTokenS2S = callDeleteTokenS2S;
/*
 * callUpdateTokenS2S method
 */
exports.callUpdateTokenS2S = callUpdateTokenS2S;
/*
 * callIdealListS2S method
 */
exports.callIdealListS2S = callIdealListS2S;
/*
 * callMyBankListS2S method
 */
exports.callMyBankListS2S = callMyBankListS2S;
/*
 * callUpdateOrderS2S method
 */
exports.callUpdateOrderS2S = callUpdateOrderS2S;