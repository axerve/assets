'use strict';
/**
 * @module app
 * overrive of app.ds file for using settings.getBaseCartridgeController()
 */
let settings = require('~/cartridge/scripts/utils/settings');
var BaseApp = require(settings.getBaseCartridgeController() + '/cartridge/scripts/app');

for (let i in BaseApp) {
  exports[i] = BaseApp[i];
}

/**
 * Returns the controller with the given name.
 */
exports.getController = function (controllerName) {
  try {
    return require('int_gestpay_controllers/cartridge/controllers/' + controllerName);
  } catch (e) {
    return require(settings.getBaseCartridgeController() + '/cartridge/controllers/' + controllerName);
  }
};

exports.getModel = function (modelName) {
  try {
    return require('./models/' + modelName + 'Model');
  } catch (e) {
    return require(settings.getBaseCartridgeController() + '/cartridge/scripts/models/' + modelName + 'Model');
  }
};


exports.getForm = function (formReference) {
  var formInstance, FormModel;

  FormModel = require(settings.getBaseCartridgeController() + '/cartridge/scripts/models/FormModel');
  formInstance = null;
  if (typeof formReference === 'string') {
    formInstance = require(settings.getBaseCartridgeController() + '/cartridge/scripts/object').resolve(session.forms, formReference);
  } else if (typeof formReference === 'object') {
    formInstance = formReference;
  }

  return new FormModel(formInstance);
};