'use strict';
/**
 * Utility for configure service and set url before soap call
 */
var GPrequest = function () {
  let self = this;
  /** @type {dw.svc.Service} */
  let service;
  let requestData;

  self.configureService = function (name) {
  	try{
  		let utils = require('int_gestpay/cartridge/scripts/utils/utils');
		let gestpayServiceInit = require('int_gestpay/cartridge/scripts/init/gestpayServiceInit');
	    service = gestpayServiceInit.serviceMapRegistry.get(name);
	    service.setURL(utils.getUrlByName(name));
	    return self;
  	}catch(e){
  		var error = e;
  		throw new Error(e);
  	}
  };

  self.getUrl = function () {
    return service.getURL();
  };

  self.setUrl = function (url) {
    service.setURL(url);
    return self;
  };

  self.setUrlParameters = function (params) {
    let url = service.getURL();
    for (let param in params) {
      if (params.hasOwnProperty(param)) {
        url = url.replace('{' + param + '}', params[param]);
      }
    }
    service.setURL(url);
    return self;
  };

  self.setParams = function (object) {
    return self;
  };

  self.call = function (args) {
    return service.call(args);
  }
};

module.exports = GPrequest;
