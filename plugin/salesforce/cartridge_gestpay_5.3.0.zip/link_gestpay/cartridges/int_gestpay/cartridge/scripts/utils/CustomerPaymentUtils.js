'use strict';


exports.addTokenToOrderPaymentIfNecessary = addTokenToOrderPaymentIfNecessary;
exports.isPaymentSaved = isPaymentSaved;
exports.isPaymentMethodSaved = isPaymentMethodSaved;


/**
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 */
function addTokenToOrderPaymentIfNecessary(paymentInstrument) {
	if (!customer.profile || !customer.profile.wallet) {
		return;
	}
	let savedPis = customer.profile.wallet.getPaymentInstruments(paymentInstrument.paymentMethod).toArray().filter(function(pi) {
		return pi.paymentMethod === 'PAYPAL' && !empty(pi.creditCardToken);
	});
	if (savedPis.length > 0) {
		paymentInstrument.creditCardToken = savedPis[0].creditCardToken;
	}
}

/**
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns {boolean}
 */
function isPaymentSaved(paymentInstrument) {
	if (!customer.profile || !customer.profile.wallet) {
		return false;
	}
    return customer.profile.wallet.getPaymentInstruments(paymentInstrument.paymentMethod).toArray().some(function(pi) {
		return pi.paymentMethod === 'PAYPAL' && !empty(pi.creditCardToken);
	});
}

/**
 * @param {string} paymentMethod
 * @returns {boolean}
 */
function isPaymentMethodSaved(paymentMethod) {
	if (!customer.profile || !customer.profile.wallet) {
		return false;
	}
	return customer.profile.wallet.getPaymentInstruments(paymentMethod).toArray().some(function(pi) {
		return pi.paymentMethod === 'PAYPAL' && !empty(pi.creditCardToken);
	});
}
