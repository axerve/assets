const Order = require('dw/order/Order');
const OrderMgr = require('dw/order/OrderMgr');
const PaymentInstrument = require('dw/order/PaymentInstrument');
const Logger = require('dw/system/Logger');
const Transaction = require('dw/system/Transaction');
const Money = require('dw/value/Money');


function execute(pdict) {
  try {
    captureAllShipped();
  } catch (e) {
    dw.system.Logger.error('[gestpay - capture.execute] error: ' + e.message);
  }
}

function captureAllShipped() {
  let query = 'paymentStatus = {0}';
  let orders = OrderMgr.searchOrders(
      query,
      'creationDate asc',
      Order.PAYMENT_STATUS_NOTPAID);
  while (orders.hasNext()) {
    let order = orders.next();
    if ([order.status, order.status.value].indexOf(Order.ORDER_STATUS_CANCELLED) > -1) {
      updateOrder(order, null, false, null);
    } else {
      captureByOrder(order);
    }
  }
  orders.close();
}

function captureByOrder(order) {
  let captured = false;
  order.getPaymentInstruments().toArray().forEach(function (paymentInstrument) {
    let paymentMethod = paymentInstrument.paymentMethod;
    let amountMoney = computeShippedAmount(order);
    switch (paymentMethod) {
      case PaymentInstrument.METHOD_CREDIT_CARD:
        let paymentServices = require('int_gestpay/cartridge/scripts/wsS2S');
        let amount = amountMoney.getDecimalValue();
        let currency = amountMoney.getCurrencyCode();
        let paymentTransaction = order.getPaymentInstruments('CREDIT_CARD').iterator().next().paymentTransaction;
        let bankTransactionID = paymentTransaction.transactionID;
        let shopTransactionID = paymentTransaction.custom.gestPayShopTransactionID;
        let fulfillment = null;
        Logger.info('[capture.captureByOrder] amount = {0}, currency = {1}, bankTransactionID = {2}, shopTransactionID = {3}, fulfillment = {4}', amount, currency, bankTransactionID, shopTransactionID, fulfillment);
        let result = paymentServices.callSettleS2S(amount, currency, bankTransactionID, shopTransactionID, fulfillment);
        let ok = result.isOk();
        let transactionResult = result.getObject() ? result.getObject().transactionResult : null;
        let errorCode = result.getObject() ? result.getObject().errorCode : null;
        Logger.info('[capture.captureByOrder] ok = {0}, transactionResult = {1}, errorCode = {2}', ok, transactionResult, errorCode);
        captured = ok && transactionResult === 'OK' && errorCode == '0';
        updateOrder(order, amountMoney, captured, paymentInstrument);
        break;
    }
  });
  return captured;
}

function computeShippedAmount(order) {
  let amount = computeProductsAmount(order);
  let maxAmount = computeMaxCapturable(order);
  Logger.info('[capture.computeShippedAmount] amount = {0}, maxAmount = {1}', amount.getDecimalValue(), maxAmount.getDecimalValue());
  return amount.compareTo(maxAmount) <= 0 ? amount : maxAmount;
}

function computeProductsAmount(order) {
  let amount = new Money(order.getTotalGrossPrice().getDecimalValue(), order.getCurrencyCode());
  return amount;
}

function computeMaxCapturable(order) {
  let maxAmount = new Money(0, order.getCurrencyCode());
  order.getPaymentInstruments().toArray().filter(function (paymentInstrument) {
    return [PaymentInstrument.METHOD_CREDIT_CARD].indexOf(paymentInstrument.getPaymentMethod()) > -1;
  }).map(function (paymentInstrument) {
    return paymentInstrument.getPaymentTransaction().getAmount();
  }).forEach(function (price) {
    maxAmount = maxAmount.add(price);
  });
  return maxAmount;
}

function updateOrder(order, amount, captured, paymentInstrument) {
  if (captured) {
    Transaction.wrap(function () {
      order.paymentStatus = Order.PAYMENT_STATUS_PAID;
    });
    addCaptureTransactionToPayment(order, amount, paymentInstrument);
  } else {
    Transaction.wrap(function () {
      order.paymentStatus = Order.PAYMENT_STATUS_NOTPAID;
    });
  }
}

function addCaptureTransactionToPayment(order, amount, paymentInstrument) {
  let invoice = findFirstInvoice(order);
  if (invoice) {
    invoice.addCaptureTransaction(paymentInstrument, amount);
  }
}

function findFirstInvoice(order) {
  let invoices = order.getInvoices();
  let invoice;
  if (invoices.size() > 0) {
    invoice = invoices[0];
  } else if (order.getShippingOrders().size() > 0) {
    let shippingOrder = order.getShippingOrders().toArray()[0];
    invoice = shippingOrder.getInvoice();
    if (invoice === null) {
      invoice = shippingOrder.createInvoice();
    }
  } else {
    invoice = null;
  }
  return invoice;
}

exports.execute = execute;

exports.captureAllShipped = captureAllShipped;

exports.captureByOrder = captureByOrder;
