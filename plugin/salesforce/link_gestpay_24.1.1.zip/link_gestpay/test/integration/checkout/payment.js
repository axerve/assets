var assert = require('chai').assert;
var request = require('request');
var requestPromise = require('request-promise');
var config = require('../it.config');
var testData = require('../helpers/common');

/**
 * Test case:
 * should be able to submit an order with Gestpay Payments Method and redirect customer to te Gestpay CashPage
 */

describe('Checkout Credit Card With Gestpay', function () {
    this.timeout(8000);

    var variantId = testData.variantId;
    var quantity = 1;
    var cookieJar = requestPromise.jar();
    var cookieString;

    var orderID = null;
    var orderToken = null;
    var continueUrl = null;
    var cryptDecryptString = null;


    it('should save Gestpay Payment Method and then redirect user to Gestpay cashpage', function () {
        var myRequest = {
            url: '',
            method: 'POST',
            rejectUnauthorized: false,
            resolveWithFullResponse: true,
            jar: cookieJar,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        };

        myRequest.url = config.baseUrl + '/Cart-AddProduct';
        myRequest.form = {
            pid: variantId,
            quantity: quantity
        };

        // ---- adding product to Cart
        return (
            requestPromise(myRequest)
            .then(function (response) {
                assert.equal(response.statusCode, 200, 'Expected add to Cart request statusCode to be 200.');
                cookieString = cookieJar.getCookieString(myRequest.url);
            })
            // ---- go to checkout
            .then(function () {
                myRequest.url = config.baseUrl + '/Checkout-Begin';
                myRequest.method = 'GET';
                return requestPromise(myRequest);
            })
            // ---- csrf token generation
            .then(function () {
                myRequest.method = 'POST';
                myRequest.url = config.baseUrl + '/CSRF-Generate';
                var cookie = request.cookie(cookieString);
                cookieJar.setCookie(cookie, myRequest.url);
                return requestPromise(myRequest);
            }) // ---- set customer
            .then(function (csrfResponse) {
                var csrfJsonResponse = JSON.parse(csrfResponse.body);
                myRequest.method = 'POST';
                myRequest.url =
                    config.baseUrl +
                    '/CheckoutServices-SubmitCustomer?' +
                    csrfJsonResponse.csrf.tokenName +
                    '=' +
                    csrfJsonResponse.csrf.token;
                myRequest.form = {
                    dwfrm_coCustomer_email: testData.billingAddress.email
                };
                return requestPromise(myRequest);
            }) // --- response of SubmitCustomer
            .then(function (response) {
                assert.equal(response.statusCode, 200, 'Expected CheckoutServices-SubmitCustomer statusCode to be 200.');
            })
            // ---- csrf token generation
            .then(function () {
                myRequest.method = 'POST';
                myRequest.url = config.baseUrl + '/CSRF-Generate';
                var cookie = request.cookie(cookieString);
                cookieJar.setCookie(cookie, myRequest.url);
                return requestPromise(myRequest);
            })
            // ---- set shipping address
            .then(function (csrfResponse) {
                var csrfJsonResponse = JSON.parse(csrfResponse.body);
                myRequest.method = 'POST';
                myRequest.url = config.baseUrl + '/CheckoutShippingServices-SubmitShipping?' + csrfJsonResponse.csrf.tokenName + '=' + csrfJsonResponse.csrf.token;
                myRequest.form = {
                    dwfrm_shipping_shippingAddress_addressFields_firstName: testData.shippingAddress.firstName,
                    dwfrm_shipping_shippingAddress_addressFields_lastName: testData.shippingAddress.lastName,
                    dwfrm_shipping_shippingAddress_addressFields_address1: testData.shippingAddress.address1,
                    dwfrm_shipping_shippingAddress_addressFields_address2: testData.shippingAddress.address2,
                    dwfrm_shipping_shippingAddress_addressFields_country: testData.shippingAddress.country,
                    dwfrm_shipping_shippingAddress_addressFields_states_stateCode: testData.shippingAddress.stateCode,
                    dwfrm_shipping_shippingAddress_addressFields_city: testData.shippingAddress.city,
                    dwfrm_shipping_shippingAddress_addressFields_postalCode: testData.shippingAddress.postalCode,
                    dwfrm_shipping_shippingAddress_addressFields_phone: testData.shippingAddress.phone,
                    dwfrm_shipping_shippingAddress_shippingMethodID: testData.shippingMethodId
                };
                return requestPromise(myRequest);
            })
            // --- response of submitshipping
            .then(function (response) {
                assert.equal(response.statusCode, 200, 'Expected CheckoutShippingServices-SubmitShipping statusCode to be 200.');
            })
            // ---- csrf token generation
            .then(function () {
                myRequest.method = 'POST';
                myRequest.url = config.baseUrl + '/CSRF-Generate';
                var cookie = request.cookie(cookieString);
                cookieJar.setCookie(cookie, myRequest.url);
                return requestPromise(myRequest);
            })
            .then(function (response) {
                myRequest.method = 'GET';
                myRequest.url = config.baseUrl + '/GestPay-Encrypt';

                var responseData = JSON.parse(response.body);

                myRequest.url += "?addressSelector=fa02c28faaa0467aff43e3bd3a" +
                    "&dwfrm_billing_addressFields_firstName=" + testData.billingAddress.firstName +
                    "&dwfrm_billing_addressFields_lastName=" + testData.billingAddress.firstName +
                    "&dwfrm_billing_addressFields_address1=" + testData.billingAddress.address1 +
                    "&dwfrm_billing_addressFields_address2=" + testData.billingAddress.address2 +
                    "&dwfrm_billing_addressFields_postalCode=" + testData.billingAddress.postalCode +
                    "&dwfrm_billing_addressFields_city=" + testData.billingAddress.city +
                    "&dwfrm_billing_addressFields_states_stateCode=" + testData.billingAddress.stateCode +
                    "&dwfrm_billing_addressFields_country=" + testData.billingAddress.country +
                    "&csrf_token=" + responseData.csrf.token +
                    "&localizedNewAddressTitle=Nuovo%20indirizzo" +
                    "&dwfrm_billing_contactInfoFields_phone=" + testData.billingAddress.phone +
                    "&dwfrm_billing_paymentMethod=" + testData.paymentMethod.id +
                    "&dwfrm_billing_creditCardFields_cardType=" + testData.paymentMethod.type +
                    "&dwfrm_billing_creditCardFields_cardNumber=" + testData.paymentMethod.cardNumber +
                    "&dwfrm_billing_creditCardFields_expirationMonth=" + testData.paymentMethod.expireMonth +
                    "&dwfrm_billing_creditCardFields_expirationYear=" + testData.paymentMethod.expireYear +
                    "&dwfrm_billing_creditCardFields_securityCode=" + testData.paymentMethod.cvc +
                    "&dwfrm_billing_creditCardFields_email=" + testData.billingAddress.email +
                    "&dwfrm_billing_creditCardFields_phone=" + testData.billingAddress.phone;

                return requestPromise(myRequest);
            })
            .then(function (response) {
                var responseData = JSON.parse(response.body);

                assert.equal(response.statusCode, 200);
                assert.equal(responseData.transactionResult, "OK");
                assert.equal(responseData.transactionType, "ENCRYPT");
            }));
    });
});