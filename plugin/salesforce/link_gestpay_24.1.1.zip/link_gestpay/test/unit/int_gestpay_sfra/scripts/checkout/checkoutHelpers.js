'use strict';

var assert = require('chai').assert;

var checkoutHelpers = require('../../../../mocks/helpers/checkoutHelpers');

var ArrayList = require('../../../../../../storefront-reference-architecture/test/mocks/dw.util.Collection');

describe('checkoutHelpers', function () {
    describe('updateImageOnProductLineItem', function () {
        it('should return an object with the updated image module', function () {
            var dwBasket = {
                productLineItems: {}
            };

            dwBasket.productLineItems = new ArrayList([{
                productID: 'pliuuid011111',
                custom: {}
            }, {
                productID: 'pliuuid011112',
                custom: {}
            }, {
                productID: 'pliuuid011113',
                custom: {}
            }, {
                productID: 'pliuuid011114',
                custom: {}
            }]);

            var orderModel = {
                items: {}
            };

            var image = {
                absURL: "urlImage"
            }

            var images = {
                large: [image]
            };

            orderModel.items.items = [{
                    id: 'pliuuid011111',
                    images: images
                },
                {
                    id: 'pliuuid011112',
                    images: images
                },
                {
                    id: 'pliuuid011113',
                    images: images
                },
                {
                    id: 'pliuuid011114',
                    images: images
                }
            ];

            checkoutHelpers.updateImageOnProductLineItem(dwBasket, orderModel);

            assert.equal(dwBasket.productLineItems.toArray()[0].custom.GestPayProductImage, "urlImage");
        });
    });

    describe('checkOrderPaymentMethod', function () {

        it('should return false if there are no payment methods', function () {
            var dwOrder = {
                getPaymentInstruments: function () {
                    return new ArrayList([]);
                }
            };

            var isCreditCard = checkoutHelpers.checkOrderPaymentMethod(dwOrder, "CREDIT_CARD");

            assert.isFalse(isCreditCard);
        });

        it('should return false if the CREDIT_CARD is not present in payment methods', function () {
            var dwOrder = {
                getPaymentInstruments: function () {
                    var paymentInstrument1 = {
                        getPaymentMethod: function () {
                            return "PAYPAL";
                        }
                    };

                    var paymentInstrument2 = {
                        getPaymentMethod: function () {
                            return "KLARNA";
                        }
                    };

                    return new ArrayList([paymentInstrument1, paymentInstrument2]);
                }
            };

            var isCreditCard = checkoutHelpers.checkOrderPaymentMethod(dwOrder, "CREDIT_CARD");

            assert.isFalse(isCreditCard);
        });

        it('should return true if Credit_card in payment methods is present', function () {
            var dwOrder = {
                getPaymentInstruments: function () {
                    var paymentInstrument1 = {
                        getPaymentMethod: function () {
                            return "PAYPAL";
                        }
                    };

                    var paymentInstrument2 = {
                        getPaymentMethod: function () {
                            return "CREDIT_CARD";
                        }
                    };

                    return new ArrayList([paymentInstrument1, paymentInstrument2]);
                }
            };

            var isCreditCard = checkoutHelpers.checkOrderPaymentMethod(dwOrder, "CREDIT_CARD");

            assert.isTrue(isCreditCard);
        });
    });
});