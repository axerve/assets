'use strict';
var log = require('dw/system/Logger').getRootLogger();

var gestPayPendingOrderTimeOut = null; //default value (24H)

function main(args) {
    var Site = require('dw/system/Site');
    var Order = require('dw/order/Order');
    var Status = require('dw/system/Status');
    var OrderMgr = require('dw/order/OrderMgr');
    var status = new Status(Status.OK);
    log.info("JOB started.");

    var currentSite = Site.getCurrent();
    gestPayPendingOrderTimeOut = currentSite.getCustomPreferenceValue("GestPayPendingOrderTimeOut");

    log.info("'GestPayPendingOrderTimeOut' custom preference value: " + gestPayPendingOrderTimeOut);

    var createdOrders = OrderMgr.searchOrders("status = {0}", null, Order.ORDER_STATUS_CREATED);

    log.info("Found " + createdOrders.count + " orders.");
    status = streamOrders(createdOrders);
    log.info("JOB ended.");

    return status;
}

//iterate over an order iterator
function streamOrders(ordersIterator) {
    var Status = require('dw/system/Status');
    var Site = require('dw/system/Site');

    var status = new Status(Status.OK);
    var currentSite = Site.getCurrent();
    var shopLogin = currentSite.getCustomPreferenceValue("GestPayShopLogin");
    var gestPayApikey = currentSite.getCustomPreferenceValue("GestPayApikey");
    var gestPayFraudPreventionMode = currentSite.getCustomPreferenceValue("GestPayFraudPreventionMode");

    if (!gestPayFraudPreventionMode) {
        //if "GestpayFraudPreventionMode" preference is null, no check for CARD or PAYPAL will be performed.
        log.warn("Impossible retrive 'GestPayFraudPreventionMode' from custom preference!!");
    }

    if (status.code == "OK") {
        while (ordersIterator.hasNext()) {
            var order = ordersIterator.next();

            if (gestPayFraudPreventionMode == "on" && checkPaymentMethod(order, ["CREDIT_CARD", "PayPal"])) {
                log.info("-------------------------------------------------------------------------");
                log.info("orderNo: " + order.orderNo + " found");
                processOrderRiskified(order, shopLogin, gestPayApikey);
                log.info("-------------------------------------------------------------------------");
            } else if (checkPaymentMethod(order, ["KLARNA", "S2PGIR", "S2PIDE", "S2PUNI", "KLARNAPAYNOW", "S2PCRU", "BANCOMATPAY", "BANCONTACT", "SATISPAY"])) {
                log.info("-------------------------------------------------------------------------");
                log.info("XX orderNo: " + order.orderNo + " found");
                processOrderXX(order, shopLogin, gestPayApikey);
                log.info("-------------------------------------------------------------------------");
            } else if (checkPaymentMethod(order, ["PAYBYLINK"])) {
                log.info("-------------------------------------------------------------------------");
                log.info("Recovery orderNo: " + order.orderNo + " found");
                processPBLXX(order, shopLogin, gestPayApikey);
                log.info("-------------------------------------------------------------------------");
            }
        }
    }

    return status;
}

//Send a request to Gestpay, to retrive the order payment detail .
//Update the order status  (placeOrder, failOrder, no operation) according to the payment status.
function processOrderRiskified(order, shopLogin, gestPayApikey) {
    var Transaction = require('dw/system/Transaction');

    var checkoutJobHelper = require('*/cartridge/scripts/helper/checkoutJobHelper');
    var PaymentDetatailRequest = require('*/cartridge/scripts/lib/PaymentDetailRequest');
    var PaymentDetailsService = require('*/cartridge/scripts/service/payment/details/PaymentDetailsService');

    var request = new PaymentDetatailRequest(order, shopLogin, gestPayApikey);
    var result = PaymentDetailsService.post(request);

    if (result.ok) { //GestPay request success.
        Transaction.wrap(function () {
            order.trackOrderChange("GestPay request-response detail: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        var response = result.object;

        if (checkoutJobHelper.isRiskified(response)) {

            handleTransactionStatusRiskified(response, order); //handle success

        } else if (response.payload && response.payload.transactionResult) {

            handleTransactionStatusXX(response, order);

        } else {
            log.error("Unexpected GestPay response : " + JSON.stringify(response) + "\nGestpay request body: " + request.getBodyStringify());
        }

    } else { //GestPay request failed, if error returned by GestPay is '2011' we handle it, oterwise log and ignore.
        Transaction.wrap(function () {
            order.trackOrderChange("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        log.error("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());

        handlePaymentDetailError(result, order); //handle error

    }

}


//Send a request to Gestpay, to retrive the order payment detail.
//Update the order status (placeOrder, failOrder, no operation) according to the payment status.
function processOrderXX(order, shopLogin, gestPayApikey) {
    var Transaction = require('dw/system/Transaction');

    var PaymentDetatailRequest = require('*/cartridge/scripts/lib/paymentDetailRequest');
    var PaymentDetailsService = require('*/cartridge/scripts/service/payment/details/paymentDetailsService');

    var request = new PaymentDetatailRequest(order, shopLogin, gestPayApikey);
    var result = PaymentDetailsService.post(request);

    if (result.ok) { //GestPay request success.
        Transaction.wrap(function () {
            order.trackOrderChange("GestPay request-response detail: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        var response = result.object;

        if (response.payload && response.payload.transactionResult) {
            handleTransactionStatusXX(response, order); //handle success
        } else {
            log.error("Unexpected GestPay response: " + JSON.stringify(response) + "\nGestpay request body: " + request.getBodyStringify());
        }

    } else { //GestPay request failed, if error returned by GestPay is '2011' we handle it, oterwise log and ignore.
        Transaction.wrap(function () {
            order.trackOrderChange("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        log.error("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());

        handlePaymentDetailError(result, order); //handle error
    }
}

/**
 * Check if an order is payed with a given methods ID.
 * @param {dw.order.Order} order - The order object to check.
 * @param {array} methodsId - the payment method ID .
 * @returns {Object} return true if order is payed with KLARNA. , false otherwise.
 */
function checkPaymentMethod(order, methodsId) {
    var GestpayConstants = require("*/cartridge/scripts/gestpayConstants");
    var result = false;

    var paymentInstruments = order.getPaymentInstruments();

    if (paymentInstruments) {
        var paymentInstyrumentsIterator = paymentInstruments.iterator();

        while (paymentInstyrumentsIterator.hasNext() && !result) {
            var paymentInstrument = paymentInstyrumentsIterator.next();
            var paymentMethod = paymentInstrument.getPaymentMethod();
            var paymentProcessor = paymentInstrument.paymentTransaction.paymentProcessor ? paymentInstrument.paymentTransaction.paymentProcessor.ID : null;

            if (paymentMethod && paymentProcessor && methodsId.indexOf(paymentMethod) != -1 && GestpayConstants.processors.indexOf(paymentProcessor) != -1) {
                result = true;
            }
        }
    }

    return result;
}

/**
 * Update order status according to payment status, Riskified case.
 * @param {dw.order.Order} order - The order to be handled.
 * @param {Object} paymentDetail - gestpay payment detail associeted to the order.
 */
function handleTransactionStatusRiskified(paymentDetail, order) {
    var checkoutJobHelper = require('*/cartridge/scripts/helper/checkoutJobHelper');

    var riskResponseCode = paymentDetail.payload.risk.riskResponseCode;

    log.info("Riskified orderNo: " + order.orderNo + " riskified status: " + riskResponseCode);

    if (riskResponseCode == "approved") {
        var placed = checkoutJobHelper.placeOrder(order, log);

        if (placed) {
            sendConfirmationEmail(paymentDetail, order);
        }
    } else if (riskResponseCode == "declined") {
        if (checkoutJobHelper.failOrder(order, log)) {
            sendFailEmail(paymentDetail, order);
        }
    } else {
        var msg = "Riskified status is '" + riskResponseCode + "' from more than " + gestPayPendingOrderTimeOut + "H. Order will be failed.";

        if (checkoutJobHelper.failOrderIfExpired(order, gestPayPendingOrderTimeOut, log, msg)) {
            sendFailEmail(paymentDetail, order);
        }
    }
}

/**
 * Update order status according to payment status, XX case.
 * @param {dw.order.Order} order - The order to be handled.
 * @param {Object} paymentDetail - gestpay payment detail associeted to the order.
 */
function handleTransactionStatusXX(paymentDetail, order) {
    var checkoutJobHelper = require('*/cartridge/scripts/helper/checkoutJobHelper');

    var paymentStatus = paymentDetail.payload.transactionResult;

    log.info("orderNo: " + order.orderNo + " payment status: " + paymentStatus);

    Transaction.wrap(function () {
        if (paymentStatus == "OK" || paymentStatus == "APPROVED") {
            var placed = checkoutJobHelper.placeOrder(order, log);

            if (placed) {
                sendConfirmationEmail(paymentDetail, order);
            }
        } else if (paymentStatus == "KO" || paymentStatus == "DECLINED") {
            if (checkoutJobHelper.failOrder(order, log)) {
                sendFailEmail(paymentDetail, order);
            }
        } else { //we expect only PENDING here.
            var msg = "Paymemt is PENDING from more than " + gestPayPendingOrderTimeOut + "H. Order will be failed.";

            if (checkoutJobHelper.failOrderIfExpired(order, gestPayPendingOrderTimeOut, log, msg)) {
                sendFailEmail(paymentDetail, order);
            }
        }
    });
}

function handlePaymentDetailError(result, order) {
    // If payment are not completed, some order are not associeted to a transaction
    //in this case error 400 (malformed request) is returned because transaction can't be found.
    //order is failed after some hours if no transaction in associeted.
    if (result.error == "400") {
        var message = null;

        try {
            message = JSON.parse(result.errorMessage);
        } catch (error) {
            log.error("orderNo: " + order.orderNo + "Can't parse Gestpay response error message. error code: " + result.error + ", error message: " + result.errorMessage);
        }

        if (message && message.error.code && message.error.description) {
            log.error("orderNo: " + order.orderNo + " error code: " + message.error.code + " description: " + message.error.description);

            // GestPay return error 2011 where there is no transaction associated to an order.
            if (message.error.code == "2011") {
                handleTransactionNotFound(order);
            }

        } else if (message) {
            log.error("Unexpected GestPay error message: " + result.errorMessage);
        }
    } else {
        log.error("orderNo: " + order.orderNo + "Gestpay request failed with: error: " + result.error + " and error message: " + result.errorMessage);
    }
}

/**
 * Handle order with no transaction associeted.
 * @param {dw.order.Order} order - The order to be handled.
 */
function handleTransactionNotFound(order) {
    var checkoutJobHelper = require('*/cartridge/scripts/helper/checkoutJobHelper');

    log.info("orderNo: " + order.orderNo + "  have no transaction associated");

    var msg = "Payment is  not found from more than " + gestPayPendingOrderTimeOut + "H. Order will be failed.";

    if (checkoutJobHelper.failOrderIfExpired(order, gestPayPendingOrderTimeOut, log, msg)) {
        sendFailEmail(null, order);
    }
}

function sendConfirmationEmail(paymentDetail, order) {
    var checkoutJobHelper = require('*/cartridge/scripts/helper/checkoutJobHelper');

    var locale = getLocale(paymentDetail, order);

    if (locale) {
        checkoutJobHelper.sendConfirmationEmail(order, locale);
        log.info("orderNo: " + order.orderNo + " confirmation email sended.");
    } else {
        log.error("orderNo: " + order.orderNo + " confirmation email not sended");
    }
}

function sendFailEmail(paymentDetail, order) {
    var checkoutJobHelper = require('*/cartridge/scripts/helper/checkoutJobHelper');
    var locale = getLocale(paymentDetail, order);

    if (locale) {
        checkoutJobHelper.sendFailEmail(order, locale);
        log.info("orderNo: " + order.orderNo + " fail email sended.");
    } else {
        log.error("orderNo: " + order.orderNo + " fail email not sended");
    }
}

function getLocale(paymentDetail, order) {
    var locale = null;

    if (paymentDetail && paymentDetail.payload && paymentDetail.payload.customInfo && paymentDetail.payload.customInfo.LOCALE) {
        locale = paymentDetail.payload.customInfo.LOCALE;
    } else if (order) {
        locale = order.customerLocaleID;
    } else {
        log.error("(Riskified) orderNo: " + order.orderNo + " 'Locale' can't be found in GestPay response.\n" + paymentDetail);
    }

    return locale;
}

function processPBLXX(order) {
    var Transaction = require('dw/system/Transaction');

    var gestpayFacade = require("*/cartridge/scripts/facade/gestpayFacade");
    var GestpayConstants = require("*/cartridge/scripts/gestpayConstants");
    var paymentHelpers = require('*/cartridge/scripts/helpers/payment/paymentHelpers');
    var checkoutJobHelper = require('*/cartridge/scripts/helper/checkoutJobHelper');

    var paymentInstrument = paymentHelpers.getPayByLinkPaymentInstrument(order);

    var result = null;
    var status = null;

    if (paymentInstrument) {
        result = gestpayFacade.payment.details(null, null, null, paymentInstrument.paymentTransaction.custom.gestPayPaymentID, GestpayConstants.type.PAYBYLINK);

        if (!result.error) {
            var response = JSON.parse(result.response);

            if (response && response.error && response.error.code == "0") {
                if (response.payload && (response.payload.transactionResult == "APPROVED" || response.payload.transactionResult == "OK")) {
                    status = "OK";

                    Transaction.wrap(function () {
                        paymentInstrument.paymentTransaction.transactionID = result.bankTransactionID;
                        paymentInstrument.custom.gestPayPaymentMethod = response.payload.paymentMethod;
                    });
                } else if (response.payload && (response.payload.transactionResult == "DECLINED" || response.payload.transactionResult == "KO")) {
                    status = "KO";
                } else if (response.payload && response.payload.transactionResult == "UNSUBMITTED" && checkoutJobHelper.isOrderExpiredPayByLink(order, order.custom.gestPayPayByLinkValdity || 50 * 60 * 60)) {
                    status = "KO";
                }

                if (status == "KO") {
                    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
                    var giftcardFacade = require("*/cartridge/scripts/facade/giftCardFacade");

                    var hasCapturedGiftcard = COHelpers.getGiftCardCaptured(order);

                    if (hasCapturedGiftcard) {
                        Logger.info("[processPBLXX] - Calling recharge giftcard service");

                        var result = giftcardFacade.recharge(hasCapturedGiftcard.amount, hasCapturedGiftcard.cardNumber, order);
                        var success = result && result.status == "OK" && !result.error;

                        if (success) {
                            Transaction.wrap(function () {
                                order.custom.giftCardRefundStatus = "REFUNDED";
                                order.custom.giftCardStatusUpdated = new Date();

                                order.trackOrderChange("[processPBLXX] - Job refunded giftcard " + cardNumber + " for amount: " + amount + " " + dwOrder.getCurrencyCode());
                            });
                        }
                    }
                }
            }
        } else {
            log.error("(processPBLXX) orderNo: " + order.orderNo + " response: " + result.response + " Error: " + result.errorMessage);
        }

        if (status == "OK") {
            var placed = checkoutJobHelper.placeOrder(order, log);

            if (placed) {
                sendConfirmationEmail(null, order);
            }

            log.info("(processPBLXX) orderNo - Placed: " + order.orderNo + " response: " + result.response + " Error: " + result.errorMessage);
        } else if (status == "KO") {
            if (checkoutJobHelper.failOrder(order, log)) {
                //sendFailEmail(null, order);
            }
            log.info("(processPBLXX) orderNo - Failed: " + order.orderNo + " response: " + result.response + " Error: " + result.errorMessage);
        }
    } else {
        log.error("(processPBLXX) orderNo: " + order.orderNo + " payment processor type not found.");
    }
}

exports.execute = main;