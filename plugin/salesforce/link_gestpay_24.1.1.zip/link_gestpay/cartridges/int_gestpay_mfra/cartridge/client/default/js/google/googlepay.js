'use strict';

const {
    getConfig,
    authorizePayment,
    callPlaceOrder,
    getGoogleTransactionInfo,
    getGooglePayDataChange
} = require("./api");

var isExpress = true;
var isTest = true;

/**
 * Define the version of the Google Pay API referenced when creating your
 * configuration
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/request-objects#PaymentDataRequest|apiVersion in PaymentDataRequest}
 */
var baseRequest = {
    apiVersion: 2,
    apiVersionMinor: 0
};

/**
 * HTML class name used for injection
 */
var containerName = 'g-container'

/**
 * Card networks supported by your site and your gateway
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/request-objects#CardParameters|CardParameters}
 * @todo confirm card networks supported by your site and gateway
 */
var allowedCardNetworks = ["AMEX", "DISCOVER", "INTERAC", "JCB", "MASTERCARD", "VISA"];

/**
 * Card authentication methods supported by your site and your gateway
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/request-objects#CardParameters|CardParameters}
 * @todo confirm your processor supports Android device tokens for your
 * supported card networks
 */
var allowedCardAuthMethods = ["PAN_ONLY", "CRYPTOGRAM_3DS"];

/**
 * Determine if the component has already been loaded
 */
var componentLoaded = false;

/**
 * Describe your site's support for the CARD payment method and its required
 * fields
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/request-objects#CardParameters|CardParameters}
 */
var baseCardPaymentMethod = {
    type: 'CARD',
    parameters: {
        allowedAuthMethods: allowedCardAuthMethods,
        allowedCardNetworks: allowedCardNetworks
    }
};

/**
 * An initialized google.payments.api.PaymentsClient object or null if not yet set
 *
 * @see {@link getGooglePaymentsClient}
 */
var paymentsClient = null;

/**
 * Configure your site's support for payment methods supported by the Google Pay
 * API.
 *
 * Each member of allowedPaymentMethods should contain only the required fields,
 * allowing reuse of this base request when determining a viewer's ability
 * to pay and later requesting a supported payment method
 *
 * @returns {object} Google Pay API version, payment methods supported by the site
 */
function getGoogleIsReadyToPayRequest() {
    return Object.assign({},
        baseRequest, {
            allowedPaymentMethods: [baseCardPaymentMethod]
        }
    );
}

/**
 * Configure support for the Google Pay API
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/request-objects#PaymentDataRequest|PaymentDataRequest}
 * @returns {Promise<object>} PaymentDataRequest fields
 */
async function getGooglePaymentDataRequest() {
    var googleConfig = await getConfig();
    isExpress = googleConfig.isExpress;
    var paymentDataRequest = googleConfig.data;
    paymentDataRequest.transactionInfo = await getGoogleTransactionInfo();

    if (isExpress) {
        paymentDataRequest.shippingAddressRequired = true;
        paymentDataRequest.shippingOptionRequired = true;
        paymentDataRequest.emailRequired = true;

        paymentDataRequest.callbackIntents = ["SHIPPING_ADDRESS", "PAYMENT_AUTHORIZATION", "SHIPPING_OPTION"];
    } else {
        paymentDataRequest.callbackIntents = ["PAYMENT_AUTHORIZATION"];
    }

    return paymentDataRequest;
}

/**
 * Return an active PaymentsClient or initialize
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/client#PaymentsClient|PaymentsClient constructor}
 * @returns {google.payments.api.PaymentsClient} Google Pay API client
 */
function getGooglePaymentsClient() {
    var paymentDataCallbacks = {
        onPaymentAuthorized: onPaymentAuthorized
    }

    if (isExpress) {
        paymentDataCallbacks.onPaymentDataChanged = onPaymentDataChanged;
    }

    // @ts-ignore
    paymentsClient = new google.payments.api.PaymentsClient({
        environment: isTest ? 'TEST' : 'PRODUCTION',
        paymentDataCallbacks: paymentDataCallbacks
    });

    return paymentsClient;
}

async function paymentAuthorize(data) {

    var result = await authorizePayment(data)

    if (result.data.transactionState == "SUCCESS") {

        if (isExpress) {
            var resultPlace = await callPlaceOrder(result.data);

            if (!resultPlace.error) {
                var url = resultPlace.redirect3dSecure ? resultPlace.redirect3dSecure : resultPlace.continueUrl;

                if (resultPlace.compatibilityVersion == 6) {
                    var redirect = $('<form class="d-none">')
                        .appendTo(document.body)
                        .attr({
                            method: 'POST',
                            action: url
                        });

                    $('<input>')
                        .appendTo(redirect)
                        .attr({
                            name: 'orderID',
                            value: resultPlace.orderID
                        });

                    $('<input>')
                        .appendTo(redirect)
                        .attr({
                            name: 'orderToken',
                            value: resultPlace.orderToken
                        });

                    redirect.submit();
                } else {
                    window.location.href = resultPlace.continueUrl;
                }
            } else {
                if (!$('.error-message').length) {
                    var newErrorMessage = '<div class="alert alert-danger error-message" role="alert"><p class="error-message-text"></p></div>'
                    if ($(".cart").length) {
                        $(".cart").prepend(newErrorMessage);
                    }
                }
                $('.error-message-text').text(resultPlace.errorMessage);
                $('html, body').animate({
                    scrollTop: '0px'
                }, 300);
                $('.error-message').show().delay(10000).fadeOut();
            }
        } else {
            $('.submit-payment').trigger('click')
            $('.next-step-button').removeClass('d-none')
        }
    }

    return result.data;
}

/**
 * Handles authorize payments callback intents.
 *
 * @param {object} paymentData response from Google Pay API after a payer approves payment through user gesture.
 * @see {@link https://developers.google.com/pay/api/web/reference/response-objects#PaymentData object reference}
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/response-objects#PaymentAuthorizationResult}
 * @returns Promise<{object}> Promise of PaymentAuthorizationResult object to acknowledge the payment authorization status.
 */
function onPaymentAuthorized(paymentData) {
    return paymentAuthorize(paymentData);
}

async function onPaymentDataChanged(paymentDataChange) {
    return await getGooglePayDataChange(paymentDataChange);
}

/**
 * Add a Google Pay purchase button alongside an existing checkout button
 *
 * @see {@link https://developers.google.com/pay/api/web/reference/request-objects#ButtonOptions|Button options}
 * @see {@link https://developers.google.com/pay/api/web/guides/brand-guidelines|Google Pay brand guidelines}
 */
async function addGooglePayButton() {
    var paymentsClient = getGooglePaymentsClient();
    document.querySelectorAll('.' + containerName).forEach(function (element) {
        var button = paymentsClient.createButton({
            onClick: onGooglePaymentButtonClicked
        });
        element.innerHTML = ''
        element.appendChild(button)
    });
}

/**
 * Show Google Pay payment sheet when Google Pay payment button is clicked
 */
async function onGooglePaymentButtonClicked() {
    var paymentDataRequest = await getGooglePaymentDataRequest(); // Carica dati Google Pay

    var paymentsClient = getGooglePaymentsClient(); // Autorizza client e carica funzione pagamento
    paymentsClient.loadPaymentData(paymentDataRequest); // Esegue pagamento;
}

/**
 * Initialize Google PaymentsClient after Google-hosted JavaScript has loaded
 *
 * Display a Google Pay payment button after confirmation of the viewer's
 * ability to pay.
 */
function onGooglePayLoaded() {
    if (!componentLoaded) {
        var paymentsClient = getGooglePaymentsClient();
        paymentsClient.isReadyToPay(getGoogleIsReadyToPayRequest())
            .then(function (response) {
                if (response.result) {
                    addGooglePayButton();
                    componentLoaded = true
                }
            })
            .catch(function (err) {
                // show error in developer console for debugging
                console.error("Error while using Google Pay:", err);
            });
    } else {
        addGooglePayButton();
    }
}

/**
 * The main function, which initialize the component
 */
function init() {
    // First call for elements in page
    onGooglePayLoaded()

    // Observer for minicart
    var googleObserver = new MutationObserver(function (mutations) {
        mutations.forEach(function (edit) {
            var container = null

            edit.addedNodes.forEach(function (node) {
                container = node.ELEMENT_NODE && node;
            });

            if (container) {
                onGooglePayLoaded()
            }
        })
    })

    var minicart = document.querySelector('.minicart .popover');
    if (minicart) {
        googleObserver.observe(minicart, {
            attributes: false,
            childList: true
        })
    }

    // Checkout tabs management
    $('.payment-options .nav-item').on('click', function (e) {
        var methodID = $(this).data('method-id');
        if (methodID == 'GOOGLE_PAY') {
            $('.next-step-button').addClass('d-none');
            onGooglePayLoaded();
        } else {
            $('.next-step-button').removeClass('d-none');
        }
    });
}

module.exports = {
    init: init
}