'use strict';

var baseBilling = require('base/checkout/billing');

baseBilling.methods.updatePaymentInformation = function updatePaymentInformation(order) {
    var $paymentSummary = $('.payment-details');
    var htmlToAppend = '';

    if (order.billing.payment && order.billing.payment.selectedPaymentInstruments &&
        order.billing.payment.selectedPaymentInstruments.length > 0) {

        if (order.billing.payment.selectedPaymentInstruments[0].paymentMethod != 'CREDIT_CARD') {
            var paymentName = null;

            for (var i = 0; i < order.billing.payment.applicablePaymentMethods.length && paymentName == null; i++) {
                if (order.billing.payment.selectedPaymentInstruments[0].paymentMethod == order.billing.payment.applicablePaymentMethods[i].ID) {
                    paymentName = order.billing.payment.applicablePaymentMethods[i].name;
                }
            }

            if (paymentName != null) {
                htmlToAppend += '<span>' + paymentName + '</span>';
            }

        } else {
            htmlToAppend += '<span>' + order.resources.cardType + ' ' +
                order.billing.payment.selectedPaymentInstruments[0].type +
                '</span><div>' +
                order.billing.payment.selectedPaymentInstruments[0].maskedCreditCardNumber +
                '</div><div><span>' +
                order.resources.cardEnding + ' ' +
                order.billing.payment.selectedPaymentInstruments[0].expirationMonth +
                '/' + order.billing.payment.selectedPaymentInstruments[0].expirationYear +
                '</span></div>';
        }
    }

    $paymentSummary.empty().append(htmlToAppend);

};

module.exports = baseBilling;