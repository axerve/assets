'use strict';

var server = require('server');
var page = module.superModule;
const settings = require('int_gestpay/cartridge/scripts/utils/settings');

server.extend(page);

server.append('Confirm', function (req, res, next) {
    var viewData = res.getViewData();

    var OrderMgr = require('dw/order/OrderMgr');
    var Order = require('dw/order/Order');

    var orderId = (req.form.orderID) ? req.form.orderID : req.querystring.ID;
    var orderToken = (req.form.orderToken) ? req.form.orderToken : req.querystring.token;

    var order = OrderMgr.getOrder(orderId, orderToken);

    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

    var isKlarna = COHelpers.checkOrderPaymentMethod(order, "KLARNA");
    var isCard = COHelpers.checkOrderPaymentMethod(order, "CREDIT_CARD");
    var isPaypal = COHelpers.checkOrderPaymentMethod(order, "PayPal") || COHelpers.checkOrderPaymentMethod(order, "PAYPAL_BNPL");
    var isIdeal = COHelpers.checkOrderPaymentMethod(order, "S2PIDE");
    var isPayByLink = COHelpers.checkOrderPaymentMethod(order, "PAYBYLINK");
    var isGooglePay = COHelpers.checkOrderPaymentMethod(order, "GOOGLE_PAY")

    var isCreated = order.status.value === Order.ORDER_STATUS_CREATED;
    var isFraudPreventionOn = settings.isFraudPreventionEnabled();

    if ((isGooglePay || isKlarna || isIdeal || (isFraudPreventionOn && (isCard || isPaypal)) || isPayByLink) && isCreated) {
        var data = {
            order: viewData.order,
            returningCustomer: viewData.returningCustomer,
            reportingURLs: viewData.reportingURLs,
            orderUUID: viewData.orderUUID
        };

        if (!req.currentCustomer.profile) {
            data.passwordForm = viewData.passwordForm;
        }

        res.render('/checkout/confirmation/waitingConfirmation', data);
    }

    return next();
});

module.exports = server.exports();