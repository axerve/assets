'use strict';

var base = module.superModule;

if (!base) {
    base = {};
}

/**
 *
 * @param {paymentMethods} paymentMethods model
 * @returns {paymentMethods} paymentMethods model with payment processors
 */
function setPaymentProcessor(paymentMethods) {
    var PaymentMgr = require('dw/order/PaymentMgr');

    paymentMethods = paymentMethods.map(function (method) {
        method.processor = PaymentMgr.getPaymentMethod(method.ID).getPaymentProcessor().getID();
        return method;
    });

    return paymentMethods;
}

function getPayByLinkPaymentInstrument(dwOrder) {
    var result = null;

    if (dwOrder) {
        var dwPaymentInstruments = dwOrder.getPaymentInstruments();

        for (var i = 0; i < dwPaymentInstruments.length && !result; i++) {
            if (dwPaymentInstruments[i].paymentMethod == "PAYBYLINK") {
                result = dwPaymentInstruments[i];
            }
        }
    }

    return result;
}

base.setPaymentProcessor = setPaymentProcessor;
base.getPayByLinkPaymentInstrument = getPayByLinkPaymentInstrument;

module.exports = base;