'use strict';

module.exports = {
    get: function (type) {
        var GestpayConstants = require("*/cartridge/scripts/gestpayConstants");

        var defaultSettings = require('*/cartridge/scripts/utils/settings');
        var payByLinkSettings = require("*/cartridge/scripts/utils/payByLinkSettings");

        var shopLogin = null;
        var apiKey = null;

        if (GestpayConstants.type.DEFAULT == type) {
            shopLogin = defaultSettings.getShopLogin();
            apiKey = defaultSettings.getApikey();
        } else if (GestpayConstants.type.PAYBYLINK == type) {
            shopLogin = payByLinkSettings.getShopLogin();
            apiKey = payByLinkSettings.getApikey();
        }

        return {
            shopLogin: shopLogin,
            apiKey: apiKey
        }
    }
};