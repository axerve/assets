const log = dw.system.Logger.getLogger('GestPay', '');

module.exports = {
  types: {
    RECURRING_FIRST: '01F',
    INSTALMENT_FIRST: '02F',
    ECOMMERCE: 'EC',
    NOT_PAYMENT: 'NPA'
  },

  createTransDetails: function createTransDetails(lineItemCtnr, objectFactory) {
    try {
      if (lineItemCtnr != null) {
        var transDetails = objectFactory.createThreeDSEncryptTransDetails();
        //transDetails.setType(this.types.ECOMMERCE);

        var threeDsContainer = objectFactory.createEncryptThreeDsContainer();

        var buyerDetails = objectFactory.createBuyerDetails();

        var billingAddress = objectFactory.createThreeDSBillingAddress();
        var billingAddressLineItem = lineItemCtnr.billingAddress;
        billingAddress.setCountry(
          billingAddressLineItem.countryCode.value.toUpperCase() || ''
        );
        billingAddress.setCity(billingAddressLineItem.city || '');
        billingAddress.setLine1(billingAddressLineItem.address1 || '');
        billingAddress.setLine2(billingAddressLineItem.address2 || '');
        billingAddress.setPostCode(billingAddressLineItem.postalCode || '');
        billingAddress.setState(billingAddressLineItem.stateCode || '');
        buyerDetails.setBillingAddress(billingAddress);

        var shippingAddress = objectFactory.createThreeDSShippingAddress();
        var shippingAddressLineItem = lineItemCtnr.shipments[0].shippingAddress;
        shippingAddress.setCountry(
          shippingAddressLineItem.countryCode.value.toUpperCase() || ''
        );
        shippingAddress.setCity(shippingAddressLineItem.city || '');
        shippingAddress.setLine1(shippingAddressLineItem.address1 || '');
        shippingAddress.setLine2(shippingAddressLineItem.address2 || '');
        shippingAddress.setPostCode(shippingAddressLineItem.postalCode || '');
        shippingAddress.setState(shippingAddressLineItem.stateCode || '');
        buyerDetails.setShippingAddress(shippingAddress);

        var creditCardHolder = null;

        if (lineItemCtnr.paymentInstruments && lineItemCtnr.paymentInstruments.length > 0 && lineItemCtnr.paymentInstruments[0].creditCardHolder) {
          creditCardHolder = lineItemCtnr.paymentInstruments[0].creditCardHolder;
        } else if (billingAddressLineItem && billingAddressLineItem.fullName) {
          createCardHolder = billingAddressLineItem.fullName;
        }

        if (creditCardHolder) {
          var cardholder = objectFactory.createCardHolder();
          cardholder.setName(creditCardHolder || '');
          cardholder.setEmail('');
          cardholder.setHomePhone_Cc('');
          cardholder.setHomePhone_Num('');
          cardholder.setMobilePhone_Cc('');
          cardholder.setMobilePhone_Num('');
          cardholder.setWorkPhone_Cc('');
          cardholder.setWorkPhone_Num('');
          buyerDetails.setCardHolder(cardholder);
        }

        threeDsContainer.setBuyerDetails(buyerDetails);

        transDetails.setThreeDsContainer(threeDsContainer);

        return transDetails;
      }
    } catch (e) {
      log.error(e);
    }
    return null;
  },
  createTransDetailsS2S: function createTransDetailsS2S(lineItemCtnr, objectFactory) {
    try {
      if (lineItemCtnr != null) {
        var transDetails = objectFactory.createTransDetails();
        var threeDsContainer = objectFactory.createThreeDsContainer();
        //transDetails.setType(this.types.ECOMMERCE);

        var buyerDetails = objectFactory.createBuyerDetails();

        var billingAddress = objectFactory.createThreeDSBillingAddress();
        var billingAddressLineItem = lineItemCtnr.billingAddress;
        billingAddress.setCountry(
          billingAddressLineItem.countryCode.value.toUpperCase() || ''
        );
        billingAddress.setCity(billingAddressLineItem.city || '');
        billingAddress.setLine1(billingAddressLineItem.address1 || '');
        billingAddress.setLine2(billingAddressLineItem.address2 || '');
        billingAddress.setPostCode(billingAddressLineItem.postalCode || '');
        billingAddress.setState(billingAddressLineItem.stateCode || '');
        buyerDetails.setBillingAddress(billingAddress);

        var shippingAddress = objectFactory.createThreeDSShippingAddress();
        var shippingAddressLineItem = lineItemCtnr.shipments[0].shippingAddress;
        shippingAddress.setCountry(
          shippingAddressLineItem.countryCode.value.toUpperCase() || ''
        );
        shippingAddress.setCity(shippingAddressLineItem.city || '');
        shippingAddress.setLine1(shippingAddressLineItem.address1 || '');
        shippingAddress.setLine2(shippingAddressLineItem.address2 || '');
        shippingAddress.setPostCode(shippingAddressLineItem.postalCode || '');
        shippingAddress.setState(shippingAddressLineItem.stateCode || '');
        buyerDetails.setShippingAddress(shippingAddress);

        var creditCardHolder = null;

        if (lineItemCtnr.paymentInstruments && lineItemCtnr.paymentInstruments.length > 0 && lineItemCtnr.paymentInstruments[0].creditCardHolder) {
          creditCardHolder = lineItemCtnr.paymentInstruments[0].creditCardHolder;
        } else if (billingAddressLineItem && billingAddressLineItem.fullName) {
          createCardHolder = billingAddressLineItem.fullName;
        }

        if (creditCardHolder) {
          var cardholder = objectFactory.createCardHolder();
          cardholder.setName(creditCardHolder || '');
          cardholder.setEmail('');
          cardholder.setHomePhone_Cc('');
          cardholder.setHomePhone_Num('');
          cardholder.setMobilePhone_Cc('');
          cardholder.setMobilePhone_Num('');
          cardholder.setWorkPhone_Cc('');
          cardholder.setWorkPhone_Num('');
          buyerDetails.setCardHolder(cardholder);
        }

        threeDsContainer.setBuyerDetails(buyerDetails);

        transDetails.setThreeDsContainer(threeDsContainer);

        return transDetails;
      }
    } catch (e) {
      log.error(e);
    }
    return null;
  }
}