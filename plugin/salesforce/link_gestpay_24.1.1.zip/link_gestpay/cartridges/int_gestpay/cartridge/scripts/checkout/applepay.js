var Status = require('dw/system/Status');
var ApplePayHookResult = require('dw/extensions/applepay/ApplePayHookResult');

const wsS2S = require('int_gestpay/cartridge/scripts/wsS2S');

/**
 * @param {dw.order.Order} order
 */
exports.authorizeOrderPayment = function (order) {
	const paymentInstrument = order.getPaymentInstruments('DW_APPLE_PAY').iterator().next();

	var appleResponse = JSON.parse(request.httpParameterMap.requestBodyAsString);

	var token = appleResponse.payment.token;
	var gpResult = wsS2S.callPagamAppleS2S(
		paymentInstrument.getPaymentTransaction().getAmount().getValueOrNull(),
		paymentInstrument.getPaymentTransaction().getAmount().getCurrencyCode(),
		order.getOrderNo(),
		token,
		paymentInstrument,
		order);

	var gpResponse = gpResult.getObject();

	if (gpResponse.errorCode == '0') {
		return new Status(Status.OK);
	}

	return new Status(Status.ERROR);
};

exports.getRequest = function (args) {
	session.custom.applepaysession = 'yes'; // eslint-disable-line

	var Site = require('dw/system/Site');

	var preferences = Site.current.preferences;

	var enableApplePayPDP = false;
	var enableApplePayCart = false;

	if (preferences.custom && preferences.custom.GestPayEnableApplePayCart && preferences.custom.GestPayEnableApplePayCart == true) {
		enableApplePayCart = true;
	}

	if (preferences.custom && preferences.custom.GestPayEnableApplePayPDP && preferences.custom.GestPayEnableApplePayPDP == true) {
		enableApplePayPDP = true;
	}

	session.custom.applepayPDP = enableApplePayPDP;
	session.custom.applepayCart = enableApplePayCart;
};