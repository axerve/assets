'use strict';

function getPreference(name, defaultValue) {
    var site = dw.system.Site.getCurrent();
    let sitePrefs = site.getPreferences();
    let orgPrefs = dw.system.System.getPreferences();

    if (sitePrefs !== null && name in sitePrefs.getCustom()) {
        return sitePrefs.getCustom()[name];
    }

    if (name in orgPrefs.getCustom()) {
        return orgPrefs.getCustom()[name];
    }

    return defaultValue !== undefined ? defaultValue : null;
}

function getShopLogin() {
    return getPreference("GestPayPayByLinkShopLogin", null);
}

function getApikey() {
    return getPreference("GestPayPayByLinkApikey", null);
}

function getChannelTypes() {
    return ["EMAIL"];
}

function getValidityTimeFromNow() {
    return getPreference("GestPayPayByLinkValidityTime", null);
}

module.exports = {
    getShopLogin: getShopLogin,
    getApikey: getApikey,
    getChannelTypes: getChannelTypes,
    getValidityTimeFromNow: getValidityTimeFromNow
}