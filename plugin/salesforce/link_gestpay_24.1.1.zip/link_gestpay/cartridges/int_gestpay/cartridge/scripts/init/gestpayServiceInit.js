/**
 * Registry of all gestpay soap calls (WsS2S API WSCryptDecrypt API)
 */
'use strict';

const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
const PaymentMgr = require('dw/order/PaymentMgr');

var settings = require('int_gestpay/cartridge/scripts/utils/settings');
var utils = require('int_gestpay/cartridge/scripts/utils/utils');

var log = utils.getLogger();
var myPackage = utils.getPackage();
var myPackageS2S = utils.getPackageS2S();
var WSCryptDecryptSoapFactory = new webreferences2[myPackage].ObjectFactory();
var WSs2sSoapFactory = new webreferences2[myPackageS2S].ObjectFactory();

const SERVICE_SOAP_ENCRYPT = 'gestpay.soap.ecomm.encrypt';
const SERVICE_SOAP_DECRYPT = 'gestpay.soap.ecomm.decrypt';
const SERVICE_SOAP_CALL_PAGAM = 'gestpay.soap.ecomm.callPagamS2S';
const SERVICE_SOAP_CALL_SETTLE = 'gestpay.soap.ecomm.callSettleS2S';
const SERVICE_SOAP_CALL_DELETE = 'gestpay.soap.ecomm.callDeleteS2S';
const SERVICE_SOAP_CALL_REFUND = 'gestpay.soap.ecomm.callRefundS2S';
const SERVICE_SOAP_CALL_READ_TRX = 'gestpay.soap.ecomm.callReadTrxS2S';
const SERVICE_SOAP_CALL_VERIFY_CARD = 'gestpay.soap.ecomm.callVerifycardS2S';
const SERVICE_SOAP_CALL_CHECK_CARTA = 'gestpay.soap.ecomm.callCheckCartaS2S';
const SERVICE_SOAP_CALL_REQUEST_TOKEN = 'gestpay.soap.ecomm.callRequestTokenS2S';
const SERVICE_SOAP_CALL_DELETE_TOKEN = 'gestpay.soap.ecomm.callDeleteTokenS2S';
const SERVICE_SOAP_CALL_UPDATE_TOKEN = 'gestpay.soap.ecomm.callUpdateTokenS2S';
const SERVICE_SOAP_CALL_IDEAL_LIST = 'gestpay.soap.ecomm.callIdealListS2S';
const SERVICE_SOAP_CALL_MYBANK_LIST = 'gestpay.soap.ecomm.callMyBankListS2S';
const SERVICE_SOAP_CALL_UPDATE_ORDER = 'gestpay.soap.ecomm.callUpdateOrderS2S';

var serviceMapRegistry = new dw.util.HashMap();

function getXmlValue(responseSections, value) {
	return responseSections.descendants(value).toString();
}

function getXmlBanks(responseSections) {
	var banks = [];

	var bankListXml = responseSections.descendants("BankList");

	if (bankListXml) {
		var banksXml = responseSections.descendants("Bank");

		for (var i = 0; i < banksXml.length(); i++) {
			var bankXml = banksXml[i];

			var item = {
				code: bankXml.descendants("BankCode").toString(),
				name: bankXml.descendants("BankName").toString()
			};

			//bankObj[bank.descendants("BankCode").toString()] = bank.descendants("BankName");
			banks.push(item);
		}
	}

	return banks;
}

/*
 * encrypt
 */
serviceMapRegistry.put(SERVICE_SOAP_ENCRYPT, LocalServiceRegistry.createService(SERVICE_SOAP_ENCRYPT, {
	initServiceClient: function () {
		return webreferences2[myPackage].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSCryptDecryptSoapFactory.createEncrypt();
		//var shippingDetails = requestObject.createShippingDetails();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setUicCode(settings.getUicCurrencyCode(object.currency));
		requestObject.setAmount(object.amount);
		requestObject.setShopTransactionId(object.shopTransactionID);
		requestObject.setLanguageId(settings.getLanguageId());

		requestObject.setBuyerName(object.buyerName);
		requestObject.setBuyerEmail(object.buyerEmail);

		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		if (object.customInfo) {
			requestObject.setCustomInfo(object.customInfo);
		}
		if (object.isEnabledGestPayIframeToken && object.requestToken) {
			requestObject.setRequestToken('MASKEDPAN');
		}
		try {
			if (object.selectedPaymentMethodID) {
				// old value
				// session.forms.billing.paymentMethods.selectedPaymentMethodID.value;
				var paymentMethod = object.selectedPaymentMethodID;
				if (PaymentMgr.getPaymentMethod(paymentMethod).getPaymentProcessor().ID == settings.GESTPAY_PAYMENT_GATEWAY) {
					var paymentTypes = WSCryptDecryptSoapFactory.createPaymentTypes();
					paymentTypes.getPaymentType().add(paymentMethod);
					requestObject.setPaymentTypes(paymentTypes);
				}

				if (paymentMethod == "MYBANK") {
					var paymentTypeDetail = WSCryptDecryptSoapFactory.createPaymentTypeDetail();

					paymentTypeDetail.setMyBankBankCode(object.myBankListValue);

					requestObject.setPaymentTypeDetail(paymentTypeDetail);
				} else if (paymentMethod == "S2PIDE") {
					var paymentTypeDetail = WSCryptDecryptSoapFactory.createPaymentTypeDetail();

					paymentTypeDetail.setIdealBankCode(object.idealListValue);

					requestObject.setPaymentTypeDetail(paymentTypeDetail);
				}

				if (paymentMethod === 'PAYPAL' && settings.isGestpayBillingAgreement() && object.requestToken) {
					requestObject.setPayPalBillingAgreementDescription(settings.getGestpayBillingAgreementTerms());
				}

				if (object.orderDetails) {
					requestObject.setOrderDetails(object.orderDetails);
				}

				if ((object.selectedPaymentMethodID == 'PayPal' && settings.isEnablePPSellerProtection()) || (object.selectedPaymentMethodID == 'PAYPAL_BNPL' && settings.isEnablePPBNPLSellerProtection()) && object && object.shippingDetails) {
					requestObject.setPpSellerProtection(1);
					requestObject.setShippingDetails(object.shippingDetails);
				}
			}

			requestObject.setTransDetails(object.transDetails);
		} catch (e) {
			var error = e;
			log.error(e);
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.encrypt(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.encryptResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			cryptDecryptString: getXmlValue(responseSections, 'CryptDecryptString'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));
/*
 * decrypt
 */
serviceMapRegistry.put(SERVICE_SOAP_DECRYPT, LocalServiceRegistry.createService(SERVICE_SOAP_DECRYPT, {
	initServiceClient: function () {
		return webreferences2[myPackage].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSCryptDecryptSoapFactory.createDecrypt();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setCryptedString(object.cryptedString);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}
		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.decrypt(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.decryptResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			shopTransactionID: getXmlValue(responseSections, 'ShopTransactionID'),
			bankTransactionID: getXmlValue(responseSections, 'BankTransactionID'),
			authorizationCode: getXmlValue(responseSections, 'AuthorizationCode'),
			currency: getXmlValue(responseSections, 'Currency'),
			amount: getXmlValue(responseSections, 'Amount'),
			country: getXmlValue(responseSections, 'Country'),
			customInfo: getXmlValue(responseSections, 'CustomInfo'),
			buyerName: getXmlValue(responseSections, 'BuyerName'),
			buyerEmail: getXmlValue(responseSections, 'BuyerEmail'),
			tdLevel: getXmlValue(responseSections, 'TDLevel'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription'),
			alertCode: getXmlValue(responseSections, 'AlertCode'),
			alertDescription: getXmlValue(responseSections, 'AlertDescription'),
			vbVRisp: getXmlValue(responseSections, 'VbVRisp'),
			vbVBuyer: getXmlValue(responseSections, 'VbVBuyer'),
			vbVFlag: getXmlValue(responseSections, 'VbVFlag'),
			transactionKey: getXmlValue(responseSections, 'TransactionKey'),
			token: getXmlValue(responseSections, 'TOKEN'),
			tokenExpiryMonth: getXmlValue(responseSections, 'TokenExpiryMonth'),
			tokenExpiryYear: getXmlValue(responseSections, 'TokenExpiryYear'),
			avsResultCode: getXmlValue(responseSections, 'AVSResultCode'),
			avsResultDescription: getXmlValue(responseSections, 'AVSResultDescription'),
			riskResponseCode: getXmlValue(responseSections, 'RiskResponseCode'),
			riskResponseDescription: getXmlValue(responseSections, 'RiskResponseDescription'),
			maskedPAN: getXmlValue(responseSections, 'MaskedPAN'),
			productType: getXmlValue(responseSections, 'ProductType'),
			paymentMethod: getXmlValue(responseSections, 'PaymentMethod'),
			threeDS: getXmlValue(responseSections, 'ThreeDS')
		};
	}
}));
/*
 * callPagamS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_PAGAM, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_PAGAM, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject;
		try {
			var objectFactory = new webreferences2[myPackageS2S].ObjectFactory();
			requestObject = new webreferences2[myPackageS2S].ObjectFactory();
			requestObject = WSs2sSoapFactory.createCallPagamS2S();
			requestObject.setLanguageId(settings.getLanguageId());
			requestObject.setShopLogin(object.shopLogin);
			requestObject.setUicCode(settings.getUicCurrencyCode(object.currency));
			requestObject.setAmount(object.amount);
			requestObject.setShopTransactionId(object.shopTransactionID);
			if (!empty(object.buyerEmail)) {
				requestObject.setBuyerEmail(object.buyerEmail);
			}
			if (!empty(object.cvv)) {
				requestObject.setCvv(object.cvv);
			}
			if (object.customInfo) {
				requestObject.setCustomInfo(object.customInfo);
			}
			if (object.hasOwnProperty('transkey') && object.hasOwnProperty('pares')) {
				requestObject.setTransKey(object.transkey);
				requestObject.setPARes(object.pares);
			} else if (object.tokenValue && object.tokenValue !== '') {
				requestObject.setTokenValue(object.tokenValue);
			} else if (object.hasOwnProperty('applePaymentToken')) {
				var applePayRequest = WSs2sSoapFactory.createApplePayRequest();
				applePayRequest.setApplePayPKPaymentToken(JSON.stringify(object.applePaymentToken));
				requestObject.setApplePay(applePayRequest);
			} else if (object.hasOwnProperty('googlePayToken')) {
				var googlePayRequest = WSs2sSoapFactory.createGooglePayRequest();
				var tokenizationData = objectFactory.createTokenizationData();

				tokenizationData.setToken(object.googlePayToken);
				googlePayRequest.setTokenizationData(tokenizationData);

				requestObject.setGooglePay(googlePayRequest);
			} else {
				requestObject.setCardNumber(object.cardNumber);
				requestObject.setExpiryMonth(object.expiryMonth);
				requestObject.setExpiryYear(object.expiryYear);
			}
			// add order details
			if (object.orderDetails) {
				requestObject.setOrderDetails(object.orderDetails);
			}
			if (object.transDetails) {
				requestObject.setTransDetails(object.transDetails);
			}

			if (object.order && object.order.remoteHost) {
				requestObject.setClientIP(object.order.remoteHost);
			}

			if (settings.getApikey()) {
				requestObject.setApikey(settings.getApikey());
			}
		} catch (e) {
			log.error('Gestpay - createRequest - callP failed: ' + e.message);
		}
		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callPagamS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callPagamS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			shopTransactionID: getXmlValue(responseSections, 'ShopTransactionID'),
			bankTransactionID: getXmlValue(responseSections, 'BankTransactionID'),
			authorizationCode: getXmlValue(responseSections, 'AuthorizationCode'),
			currency: getXmlValue(responseSections, 'Currency'),
			country: getXmlValue(responseSections, 'Country'),
			customInfo: {
				PAYMENT_INSTRUMENT_UUID: getXmlValue(responseSections.descendants('CustomInfo'), settings.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID)
			},
			buyerEmail: getXmlValue(responseSections, 'BuyerEmail'),
			buyerName: getXmlValue(responseSections, 'BuyerName'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription'),
			alertCode: getXmlValue(responseSections, 'AlertCode'),
			alertDescription: getXmlValue(responseSections, 'AlertDescription'),
			amount: getXmlValue(responseSections, 'Amount'),
			transKey: getXmlValue(responseSections, 'TransactionKey'),
			vbVFlag: getXmlValue(responseSections, 'VbVFlag'),
			vbVBuyer: getXmlValue(responseSections, 'VbVBuyer'),
			vbVRisp: getXmlValue(responseSections, 'VbVRisp'),
			maskedPAN: getXmlValue(responseSections, 'MaskedPAN'),
			paymentMethod: getXmlValue(responseSections, 'PaymentMethod'),
			productType: getXmlValue(responseSections, 'ProductType'),
			cVVPresent: getXmlValue(responseSections, 'CVVPresent'),
			token: getXmlValue(responseSections, 'TOKEN'),
			tokenExpiryMonth: getXmlValue(responseSections, 'TokenExpiryMonth'),
			tokenExpiryYear: getXmlValue(responseSections, 'TokenExpiryYear'),
			payPalFee: getXmlValue(responseSections, 'PayPalFee'),
			tDLevel: getXmlValue(responseSections, 'TDLevel'),
			riskResponseCode: getXmlValue(responseSections, 'RiskResponseCode'),
			riskResponseDescription: getXmlValue(responseSections, 'RiskResponseDescription'),
			threeDS: getXmlValue(responseSections, 'ThreeDS')
		};
	}
}));
/*
 * callSettleS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_SETTLE, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_SETTLE, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallSettleS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setAmount(object.amount);
		requestObject.setUicCode(object.uicCode || settings.getUicCurrencyCode(object.currency));
		requestObject.setShopTransID(object.shopTransactionID);
		requestObject.setBankTransID(object.bankTransactionID);
		requestObject.setFullFillment(object.fullFillment);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callSettleS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callSettleS2SResult.content.toArray());



		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			bankTransactionID: getXmlValue(responseSections, 'BankTransactionID'),
			shopTransactionID: getXmlValue(responseSections, 'ShopTransactionID'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));
/*
 * callDeleteS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_DELETE, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_DELETE, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallDeleteS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setShopTransactionId(object.shopTransactionID);
		requestObject.setBankTransactionId(object.bankTransactionID);
		requestObject.setCancelReason(object.cancelReason);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callDeleteS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callDeleteS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			bankTransactionID: getXmlValue(responseSections, 'BankTransactionID'),
			shopTransactionID: getXmlValue(responseSections, 'ShopTransactionID'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));
/*
 * callRefundS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_REFUND, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_REFUND, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallRefundS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setUicCode(settings.getUicCurrencyCode(object.currency));
		requestObject.setAmount(object.amount);
		requestObject.setShopTransactionId(object.shopTransactionID);
		requestObject.setBankTransactionId(object.bankTransactionID);
		requestObject.setRefundReason(object.refundReason);
		requestObject.setChargeBackFraud(object.chargeBackFraud);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		if (log.debugEnabled) {
			log.debug('requestObject = {0}', JSON.stringify({
				shopLogin: requestObject.getShopLogin(),
				uicCode: requestObject.getUicCode(),
				amount: requestObject.getAmount(),
				shopTransactionId: requestObject.getShopTransactionId(),
				bankTransactionId: requestObject.getBankTransactionId(),
				refundReason: requestObject.getRefundReason(),
				chargeBackFraud: requestObject.getChargeBackFraud()
			}));
		}
		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callRefundS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callRefundS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			bankTransactionID: getXmlValue(responseSections, 'BankTransactionID'),
			shopTransactionID: getXmlValue(responseSections, 'ShopTransactionID'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));
/*
 * callReadTrxS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_READ_TRX, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_READ_TRX, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallReadTrxS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setShopTransactionId(object.shopTransactionID);
		requestObject.setBankTransactionId(object.bankTransactionID);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callReadTrxS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callReadTrxS2SResult.content.toArray());
		var data = {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			transactionState: getXmlValue(responseSections, 'TransactionState'),
			shopTransactionID: getXmlValue(responseSections, 'ShopTransactionID'),
			bankTransactionID: getXmlValue(responseSections, 'BankTransactionID'),
			authorizationCode: getXmlValue(responseSections, 'AuthorizationCode'),
			currency: getXmlValue(responseSections, 'Currency'),
			country: getXmlValue(responseSections, 'Country'),
			company: getXmlValue(responseSections, 'Company'),
			tDLevel: getXmlValue(responseSections, 'TDLevel'),
			buyerName: getXmlValue(responseSections, 'BuyerName'),
			buyerEmail: getXmlValue(responseSections, 'BuyerEmail'),
			riskResponseCode: getXmlValue(responseSections, 'RiskResponseCode'),
			riskResponseDescription: getXmlValue(responseSections, 'RiskResponseDescription'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription'),
			alertCode: getXmlValue(responseSections, 'AlertCode'),
			alertDescription: getXmlValue(responseSections, 'AlertDescription')
		};
		var isAmazonTransaction = !empty(getXmlValue(responseSections, 'OrderReferenceDetails'));
		if (isAmazonTransaction) {
			var orderReferenceDetails = responseSections.descendants('OrderReferenceDetails');
			var shippingAddress = orderReferenceDetails.descendants('Destination').descendants('PhysicalDestination');
			var buyerInfo = orderReferenceDetails.descendants('Buyer');
			data.buyerEmail = getXmlValue(buyerInfo, 'Email');
			data.buyerName = getXmlValue(buyerInfo, 'Name');
			data.amazonOrderReferenceID = getXmlValue(orderReferenceDetails, 'AmazonOrderReferenceId');
			data.shippingAddress = {
				firstName: getXmlValue(shippingAddress, 'Name').split(' ')[0],
				lastName: getXmlValue(shippingAddress, 'Name').split(' ').filter(function (value, index) {
					return index > 0;
				}).join(' '),
				address1: getXmlValue(shippingAddress, 'AddressLine1') + ' ' + getXmlValue(shippingAddress, 'AddressLine2'),
				postal: getXmlValue(shippingAddress, 'PostalCode'),
				city: getXmlValue(shippingAddress, 'City'),
				country: getXmlValue(shippingAddress, 'CountryCode'),
				stateOrRegion: getXmlValue(shippingAddress, 'StateOrRegion'),
				phone: getXmlValue(shippingAddress, 'Phone')
			};
			var billingAddress = orderReferenceDetails.descendants('BillingAddress').descendants('PhysicalAddress');
			data.billingAddress = {
				firstName: getXmlValue(billingAddress, 'Name').split(' ')[0],
				lastName: getXmlValue(billingAddress, 'Name').split(' ').filter(function (value, index) {
					return index > 0;
				}).join(' '),
				address1: getXmlValue(billingAddress, 'AddressLine1') + ' ' + getXmlValue(shippingAddress, 'AddressLine2'),
				postal: getXmlValue(billingAddress, 'PostalCode'),
				city: getXmlValue(billingAddress, 'City'),
				stateOrRegion: getXmlValue(billingAddress, 'StateOrRegion'),
				country: getXmlValue(billingAddress, 'CountryCode')
			};
		}
		return data;
	}
}));
/*
 * callVerifycardS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_VERIFY_CARD, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_VERIFY_CARD, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallVerifycardS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setShopTransactionId(object.shopTransactionID);
		requestObject.setCardNumber(object.cardNumber);
		requestObject.setExpMonth(object.expMonth);
		requestObject.setExpYear(object.expYear);
		requestObject.setCVV2(object.cvv2);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callVerifycardS2S(callVerifycardS2S);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callVerifycardS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			country: getXmlValue(responseSections, 'Country'),
			company: getXmlValue(responseSections, 'Company'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));
/*
 * callCheckCartaS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_CHECK_CARTA, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_CHECK_CARTA, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallCheckCartaS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setShopTransactionId(object.shopTransactionID);
		if (object.tokenValue && object.tokenValue !== '') {
			requestObject.setTokenValue(object.tokenValue);
		} else {
			requestObject.setCardNumber(object.cardNumber);
			requestObject.setExpMonth(object.expMonth);
			requestObject.setExpYear(object.expYear);
			requestObject.setCVV2(object.cvv2);
		}
		requestObject.setWithAuth(object.withAuth);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callCheckCartaS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callCheckCartaS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			transactionErrorCode: getXmlValue(responseSections, 'TransactionErrorCode'),
			transactionErrorDescription: getXmlValue(responseSections, 'TransactionErrorDescription'),
			authorizationErrorCode: getXmlValue(responseSections, 'AuthorizationErrorCode'),
			authorizationResult: getXmlValue(responseSections, 'AuthorizationResult'),
			authorizationCodeDescription: getXmlValue(responseSections, 'AuthorizationCodeDescription'),
			cardCountry: getXmlValue(responseSections, 'CardCountry'),
			cardCountryCode: getXmlValue(responseSections, 'CardCountryCode'),
			checkCVV: getXmlValue(responseSections, 'CheckCVV'),
			checkCVVDescription: getXmlValue(responseSections, 'CheckCVVDescription'),
			issuerCountry: getXmlValue(responseSections, 'IssuerCountry'),
			issuerCountryCode: getXmlValue(responseSections, 'IssuerCountryCode'),
			companyDescription: getXmlValue(responseSections, 'CompanyDescription'),
			companyCode: getXmlValue(responseSections, 'CompanyCode'),
			commercial: getXmlValue(responseSections, 'Commercial'),
			productDescription: getXmlValue(responseSections, 'ProductDescription'),
			productType: getXmlValue(responseSections, 'ProductType'),
			checkDigit: getXmlValue(responseSections, 'CheckDigit'),
			checkDigitDescription: getXmlValue(responseSections, 'CheckDigitDescription'),
			checkDate: getXmlValue(responseSections, 'CheckDate'),
			checkDateDescription: getXmlValue(responseSections, 'CheckDateDescription'),
			enrolledCode: getXmlValue(responseSections, 'EnrolledCode'),
			enrolledDescription: getXmlValue(responseSections, 'EnrolledDescription'),
			prepaid: getXmlValue(responseSections, 'Prepaid')
		};
	}
}));
/*
 * callRequestTokenS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_REQUEST_TOKEN, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_REQUEST_TOKEN, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallRequestTokenS2S();

		requestObject.setShopLogin(object.shopLogin);
		requestObject.setRequestToken(object.requestToken);
		requestObject.setCardNumber(object.cardNumber);
		requestObject.setExpMonth(object.expMonth);
		requestObject.setExpYear(object.expYear);
		requestObject.setCVV2(object.cvv2);
		requestObject.setWithAuth(object.withAuth);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}


		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callRequestTokenS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callRequestTokenS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			transactionErrorCode: getXmlValue(responseSections, 'TransactionErrorCode'),
			transactionErrorDescription: getXmlValue(responseSections, 'TransactionErrorDescription'),
			authorizationErrorCode: getXmlValue(responseSections, 'AuthorizationErrorCode'),
			authorizationResult: getXmlValue(responseSections, 'AuthorizationResult'),
			authorizationCodeDescription: getXmlValue(responseSections, 'AuthorizationCodeDescription'),
			cardCountry: getXmlValue(responseSections, 'CardCountry'),
			cardCountryCode: getXmlValue(responseSections, 'CardCountryCode'),
			checkCVV: getXmlValue(responseSections, 'CheckCVV'),
			checkCVVDescription: getXmlValue(responseSections, 'CheckCVVDescription'),
			issuerCountry: getXmlValue(responseSections, 'IssuerCountry'),
			issuerCountryCode: getXmlValue(responseSections, 'IssuerCountryCode'),
			companyDescription: getXmlValue(responseSections, 'CompanyDescription'),
			companyCode: getXmlValue(responseSections, 'CompanyCode'),
			commercial: getXmlValue(responseSections, 'Commercial'),
			productDescription: getXmlValue(responseSections, 'ProductDescription'),
			productType: getXmlValue(responseSections, 'ProductType'),
			checkDigit: getXmlValue(responseSections, 'CheckDigit'),
			checkDigitDescription: getXmlValue(responseSections, 'CheckDigitDescription'),
			checkDate: getXmlValue(responseSections, 'CheckDate'),
			checkDateDescription: getXmlValue(responseSections, 'CheckDateDescription'),
			enrolledCode: getXmlValue(responseSections, 'EnrolledCode'),
			enrolledDescription: getXmlValue(responseSections, 'EnrolledDescription'),
			prepaid: getXmlValue(responseSections, 'Prepaid'),
			cardBIN: getXmlValue(responseSections, 'CardBIN'),
			token: getXmlValue(responseSections, 'Token'),
			tokenExpiryMonth: getXmlValue(responseSections, 'TokenExpiryMonth'),
			tokenExpiryYear: getXmlValue(responseSections, 'TokenExpiryYear')
		};
	}
}));
/*
 * callDeleteTokenS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_DELETE_TOKEN, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_DELETE_TOKEN, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallDeleteTokenS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setTokenValue(object.tokenValue);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callDeleteTokenS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callDeleteTokenS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));
/*
 * callUpdateTokenS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_UPDATE_TOKEN, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_UPDATE_TOKEN, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallUpdateTokenS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setExpMonth(object.expMonth);
		requestObject.setExpYear(object.expYear);
		requestObject.setWithAuth(object.withAuth);
		requestObject.setTokenValue(object.tokenValue);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callUpdateTokenS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callUpdateTokenS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));
/*
 * callIdealListS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_IDEAL_LIST, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_IDEAL_LIST, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallIdealListS2S();
		requestObject.setShopLogin(object.shopLogin);
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callIdealListS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callIdealListS2SResult.content.toArray());

		var banks = getXmlBanks(responseSections);

		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription'),
			banks: banks
		};
	}
}));
/*
 * callMyBankListS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_MYBANK_LIST, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_MYBANK_LIST, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallMyBankListS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setLanguageId(object.languageId || settings.getLanguageId());
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callMyBankListS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callMyBankListS2SResult.content.toArray());

		var banks = getXmlBanks(responseSections);

		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription'),
			banks: banks
		};
	}
}));
/*
 * callUpdateOrderS2S
 */
serviceMapRegistry.put(SERVICE_SOAP_CALL_UPDATE_ORDER, LocalServiceRegistry.createService(SERVICE_SOAP_CALL_UPDATE_ORDER, {
	initServiceClient: function () {
		return webreferences2[myPackageS2S].getDefaultService();
	},
	createRequest: function (svc, object) {
		var requestObject = WSs2sSoapFactory.createCallUpdateOrderS2S();
		requestObject.setShopLogin(object.shopLogin);
		requestObject.setShopTransactionId(object.orderNo);
		requestObject.setBankTransactionId(object.bankTransactionId);
		if (object.orderDetails) {
			requestObject.setOrderDetails(object.orderDetails);
		}
		if (settings.getApikey()) {
			requestObject.setApikey(settings.getApikey());
		}

		return requestObject;
	},
	execute: function (svc, requestObject) {
		return svc.serviceClient.callUpdateOrderS2S(requestObject);
	},
	parseResponse: function (svc, responseObject) {
		var responseSections = new XMLList(responseObject.callUpdateOrderS2SResult.content.toArray());
		return {
			transactionType: getXmlValue(responseSections, 'TransactionType'),
			transactionResult: getXmlValue(responseSections, 'TransactionResult'),
			errorCode: getXmlValue(responseSections, 'ErrorCode'),
			errorDescription: getXmlValue(responseSections, 'ErrorDescription')
		};
	}
}));

exports.serviceMapRegistry = serviceMapRegistry;

exports.SERVICE_SOAP_ENCRYPT = SERVICE_SOAP_ENCRYPT;
exports.SERVICE_SOAP_DECRYPT = SERVICE_SOAP_DECRYPT;
exports.SERVICE_SOAP_CALL_PAGAM = SERVICE_SOAP_CALL_PAGAM;
exports.SERVICE_SOAP_CALL_SETTLE = SERVICE_SOAP_CALL_SETTLE;
exports.SERVICE_SOAP_CALL_DELETE = SERVICE_SOAP_CALL_DELETE;
exports.SERVICE_SOAP_CALL_REFUND = SERVICE_SOAP_CALL_REFUND;
exports.SERVICE_SOAP_CALL_READ_TRX = SERVICE_SOAP_CALL_READ_TRX;
exports.SERVICE_SOAP_CALL_VERIFY_CARD = SERVICE_SOAP_CALL_VERIFY_CARD;
exports.SERVICE_SOAP_CALL_CHECK_CARTA = SERVICE_SOAP_CALL_CHECK_CARTA;
exports.SERVICE_SOAP_CALL_REQUEST_TOKEN = SERVICE_SOAP_CALL_REQUEST_TOKEN;
exports.SERVICE_SOAP_CALL_DELETE_TOKEN = SERVICE_SOAP_CALL_DELETE_TOKEN;
exports.SERVICE_SOAP_CALL_UPDATE_TOKEN = SERVICE_SOAP_CALL_UPDATE_TOKEN;
exports.SERVICE_SOAP_CALL_IDEAL_LIST = SERVICE_SOAP_CALL_IDEAL_LIST;
exports.SERVICE_SOAP_CALL_MYBANK_LIST = SERVICE_SOAP_CALL_MYBANK_LIST;
exports.SERVICE_SOAP_CALL_UPDATE_ORDER = SERVICE_SOAP_CALL_UPDATE_ORDER;