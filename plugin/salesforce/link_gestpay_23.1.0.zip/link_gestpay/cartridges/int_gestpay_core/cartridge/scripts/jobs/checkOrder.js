'use strict';

const OrderMgr = require('dw/order/OrderMgr');
const Order = require('dw/order/Order');
const Logger = require('dw/system/Logger');
const log = Logger.getRootLogger();
const Site = require('dw/system/Site');
const PaymentDetatailRequest = require('int_gestpay_mfra/cartridge/scripts/lib/paymentDetailRequest');
const PaymentDetailsService = require('int_gestpay_mfra/cartridge/scripts/service/payment/details/paymentDetailsService');
const checkoutJobHelper = require('int_gestpay_core/cartridge/scripts/helper/checkoutJobHelper');
const Status = require('dw/system/Status');
const Transaction = require('dw/system/Transaction');

var gestPayPendingOrderTimeOut = null; //default value (24H)

function main() {
    var status = new Status(Status.OK);
    log.info("JOB started.");

    var currentSite = Site.getCurrent();
    gestPayPendingOrderTimeOut = currentSite.getCustomPreferenceValue("GestPayPendingOrderTimeOut");

    log.info("'GestPayPendingOrderTimeOut' custom preference value: " + gestPayPendingOrderTimeOut);

    var createdOrders = OrderMgr.searchOrders("status = {0}", null, Order.ORDER_STATUS_CREATED);

    log.info("Found " + createdOrders.count + " orders.");
    status = streamOrders(createdOrders);
    log.info("JOB ended.");

    return status;
}


//iterate over an order iterator
function streamOrders(ordersIterator) {
    var status = new Status(Status.OK);
    var currentSite = Site.getCurrent();
    const shopLogin = currentSite.getCustomPreferenceValue("GestPayShopLogin");
    const gestPayApikey = currentSite.getCustomPreferenceValue("GestPayApikey");
    const gestPayFraudPreventionMode = currentSite.getCustomPreferenceValue("GestPayFraudPreventionMode");

    if (!gestPayFraudPreventionMode) {
        //if "GestpayFraudPreventionMode" preference is null, no check for CARD or PAYPAL will be performed.
        log.warn("Impossible retrive 'GestPayFraudPreventionMode' from custom preference!!");
    }

    if (!shopLogin) {
        log.error("Impossible retrive 'GestPayShopLogin' from custom preference!!");
        status = new Status(Status.ERROR);
    }

    if (!gestPayApikey) {
        log.error("Impossible retrive 'GestPayApikey' from custom preference!!");
        status = new Status(Status.ERROR);
    }

    if (status.code == "OK") {

        while (ordersIterator.hasNext()) {
            var order = ordersIterator.next();

            if (checkPaymentMethod(order, ["KLARNA", "S2PGIR", "S2PIDE", "S2PUNI", "KLARNAPAYNOW", "S2PCRU", "BANCOMATPAY", "BANCONTACT"])) {

                log.info("-------------------------------------------------------------------------");
                log.info("XX orderNo: " + order.orderNo + " found");
                processOrderXX(order, shopLogin, gestPayApikey);
                log.info("-------------------------------------------------------------------------");

            } else if (gestPayFraudPreventionMode == "on" && checkPaymentMethod(order, ["CREDIT_CARD", "PayPal"])) {

                log.info("-------------------------------------------------------------------------");
                log.info("orderNo: " + order.orderNo + " found");
                processOrderRiskified(order, shopLogin, gestPayApikey);
                log.info("-------------------------------------------------------------------------");
            } else {
                log.info("-------------------------------------------------------------------------");
                log.info("Recovery orderNo: " + order.orderNo + " found");
                processOrderXX(order, shopLogin, gestPayApikey);
                log.info("-------------------------------------------------------------------------");
            }
        }
    }

    return status;
}

//Send a request to Gestpay, to retrive the order payment detail .
//Update the order status  (placeOrder, failOrder, no operation) according to the payment status.
function processOrderRiskified(order, shopLogin, gestPayApikey) {

    var request = new PaymentDetatailRequest(order, shopLogin, gestPayApikey);
    var result = PaymentDetailsService.post(request);

    if (result.ok) { //GestPay request success.
        Transaction.wrap(function () {
            order.trackOrderChange("GestPay request-response detail: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        var response = result.object;

        if (checkoutJobHelper.isRiskified(response)) {

            handleTransactionStatusRiskified(response, order); //handle success

        } else if (response.payload && response.payload.transactionResult) {

            handleTransactionStatusXX(response, order);

        } else {
            log.error("Unexpected GestPay response : " + JSON.stringify(response) + "\nGestpay request body: " + request.getBodyStringify());
        }

    } else { //GestPay request failed, if error returned by GestPay is '2011' we handle it, oterwise log and ignore.
        Transaction.wrap(function () {
            order.trackOrderChange("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        log.error("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());

        handlePaymentDetailError(result, order); //handle error

    }

}


//Send a request to Gestpay, to retrive the order payment detail.
//Update the order status (placeOrder, failOrder, no operation) according to the payment status.
function processOrderXX(order, shopLogin, gestPayApikey) {

    var request = new PaymentDetatailRequest(order, shopLogin, gestPayApikey);
    var result = PaymentDetailsService.post(request);

    if (result.ok) { //GestPay request success.
        Transaction.wrap(function () {
            order.trackOrderChange("GestPay request-response detail: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        var response = result.object;

        if (response.payload && response.payload.transactionResult) {

            handleTransactionStatusXX(response, order); //handle success

        } else {

            log.error("Unexpected GestPay response: " + JSON.stringify(response) + "\nGestpay request body: " + request.getBodyStringify());

        }

    } else { //GestPay request failed, if error returned by GestPay is '2011' we handle it, oterwise log and ignore.
        Transaction.wrap(function () {
            order.trackOrderChange("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());
        });

        log.error("Request failed: response.object: " + JSON.stringify(result.object) + "\nresponse.errorMessage : " + result.errorMessage + "\nGestpay request body: " + request.getBodyStringify());

        handlePaymentDetailError(result, order); //handle error

    }

}

/**
 * Check if an order is payed with a given methods ID.
 * @param {dw.order.Order} order - The order object to check.
 * @param {array} methodsId - the payment method ID .
 * @returns {Object} return true if order is payed with KLARNA. , false otherwise.
 */
function checkPaymentMethod(order, methodsId) {

    var result = false;
    var paymentInstruments = order.getPaymentInstruments();

    if (paymentInstruments) {

        var paymentInstyrumentsIterator = paymentInstruments.iterator();

        while (paymentInstyrumentsIterator.hasNext() && !result) {

            var paymentInstrument = paymentInstyrumentsIterator.next();
            var paymentMethod = paymentInstrument.getPaymentMethod();

            if (paymentMethod && methodsId.includes(paymentMethod)) {
                result = true;
            }
        }
    }

    return result;
}

/**
 * Update order status according to payment status, Riskified case.
 * @param {dw.order.Order} order - The order to be handled.
 * @param {Object} paymentDetail - gestpay payment detail associeted to the order.
 */
function handleTransactionStatusRiskified(paymentDetail, order) {
    var riskResponseCode = paymentDetail.payload.risk.riskResponseCode;
    var locale = null;

    log.info("Riskified orderNo: " + order.orderNo + " riskified status: " + riskResponseCode);

    if (riskResponseCode == "approved") {

        var placed = checkoutJobHelper.placeOrder(order, log);

        if (placed) {
            sendConfirmationEmail(paymentDetail, order);
        }

    } else if (riskResponseCode == "declined") {

        if (checkoutJobHelper.failOrder(order, log)) {
            sendFailEmail(paymentDetail, order);
        }

    } else {

        var msg = "Riskified status is '" + riskResponseCode + "' from more than " + gestPayPendingOrderTimeOut + "H. Order will be failed.";

        if (checkoutJobHelper.failOrderIfExpired(order, gestPayPendingOrderTimeOut, log, msg)) {
            sendFailEmail(paymentDetail, order);
        }

    }

}


/**
 * Update order status according to payment status, XX case.
 * @param {dw.order.Order} order - The order to be handled.
 * @param {Object} paymentDetail - gestpay payment detail associeted to the order.
 */
function handleTransactionStatusXX(paymentDetail, order) {
    var paymentStatus = paymentDetail.payload.transactionResult;
    var locale = null;

    log.info("orderNo: " + order.orderNo + " payment status: " + paymentStatus);

    if (paymentStatus == "OK" || paymentStatus == "APPROVED") {

        var placed = checkoutJobHelper.placeOrder(order, log);

        if (placed) {
            sendConfirmationEmail(paymentDetail, order);
        }

    } else if (paymentStatus == "KO" || paymentStatus == "DECLINED") {

        if (checkoutJobHelper.failOrder(order, log)) {
            sendFailEmail(paymentDetail, order);
        }

    } else { //we expect only PENDING here.

        var msg = "Paymemt is PENDING from more than " + gestPayPendingOrderTimeOut + "H. Order will be failed.";

        if (checkoutJobHelper.failOrderIfExpired(order, gestPayPendingOrderTimeOut, log, msg)) {
            sendFailEmail(paymentDetail, order);
        }

    }

}

function handlePaymentDetailError(result, order) {

    // If payment are not completed, some order are not associeted to a transaction
    //in this case error 400 (malformed request) is returned because transaction can't be found.
    //order is failed after some hours if no transaction in associeted.
    if (result.error == "400") {

        var message = null;
        try {
            message = JSON.parse(result.errorMessage);
        } catch (error) {
            log.error("orderNo: " + order.orderNo + "Can't parse Gestpay response error message. error code: " +
                result.error + ", error message: " + result.errorMessage);
        }

        if (message && message.error.code && message.error.description) {
            log.error("orderNo: " + order.orderNo + " error code: " + message.error.code + " description: " + message.error.description);

            // GestPay return error 2011 where there is no transaction associated to an order.
            if (message.error.code == "2011") {
                handleTransactionNotFound(order);
            }

        } else if (message) {
            log.error("Unexpected GestPay error message: " + result.errorMessage);
        }

    } else {
        log.error("orderNo: " + order.orderNo + "Gestpay request failed with: error: " +
            result.error + " and error message: " + result.errorMessage);
    }

}

/**
 * Handle order with no transaction associeted.
 * @param {dw.order.Order} order - The order to be handled.
 */
function handleTransactionNotFound(order) {

    log.info("orderNo: " + order.orderNo + "  have no transaction associated");

    var msg = "Payment is  not found from more than " + gestPayPendingOrderTimeOut + "H. Order will be failed.";

    if (checkoutJobHelper.failOrderIfExpired(order, gestPayPendingOrderTimeOut, log, msg)) {
        sendFailEmail(null, order);
    }

}

function sendConfirmationEmail(paymentDetail, order) {
    var locale = getLocale(paymentDetail, order);

    if (locale) {
        checkoutJobHelper.sendConfirmationEmail(order, locale);
        log.info("orderNo: " + order.orderNo + " confirmation email sended.");
    } else {
        log.error("orderNo: " + order.orderNo + " confirmation email not sended");
    }
}

function sendFailEmail(paymentDetail, order) {
    var locale = getLocale(paymentDetail, order);

    if (locale) {
        checkoutJobHelper.sendFailEmail(order, locale);
        log.info("orderNo: " + order.orderNo + " fail email sended.");
    } else {
        log.error("orderNo: " + order.orderNo + " fail email not sended");
    }
}

function getLocale(paymentDetail, order) {
    var locale = null;

    if (paymentDetail && paymentDetail.payload && paymentDetail.payload.customInfo && paymentDetail.payload.customInfo.LOCALE) {

        locale = paymentDetail.payload.customInfo.LOCALE;

    } else if (order) {

        locale = order.customerLocaleID;

    } else {

        log.error("(Riskified) orderNo: " + order.orderNo + " 'Locale' can't be found in GestPay response.\n" + paymentDetail);

    }

    return locale;
}



exports.execute = main;