'use strict'

function info(msg, logger) {
    if (logger) {
        logger.info(msg);
    }
}

function error(msg, logger) {
    if (logger) {
        logger.error(msg);
    }
}

function warn(msg, logger) {
    if (logger) {
        logger.warn(msg);
    }
}

module.exports = {
    info: info,
    error: error,
    warn: warn
};