'use strict';
/**
 * Utility for check values of site preferences of gestpay like: testmode
 * (boolean) shop login payment mode (iframe or s2s) fraud prevention (boolean)
 * enable gestpay processor (for enable / disable gestpay integration)
 */

const Resource = require('dw/web/Resource');

var site = dw.system.Site.getCurrent();
var sitePrefs = site.getPreferences();
var orgPrefs = dw.system.System.getPreferences();

var utils = require('int_gestpay/cartridge/scripts/utils/utils');
/**
 * @deprecated
 */
var isEnabledGestPayProcessor = getPreference('GestPayProcessor', false);
var isTest = getPreference('GestPayTestMode', true);
var shopLogin = getPreference('GestPayShopLogin');
var shopLoginSavedCards = getPreference('GestPayShopLoginSavedCards');
var paymentMode = getPreference('GestPayPaymentMode', {
	value: 'iframe'
});
var isEnabledGestPayIframeToken = getPreference('GestPayIframeToken', false);
var fraudPreventionEnabled = getPreference('GestPayFraudPrevention', false);
var fraudPreventionMode = getPreference('GestPayFraudPreventionMode', 'off');
var defaultThreadSleep = getPreference('DefaultThreadSleep', 60000);

var baseCartridgeController = getPreference('BaseCartridgeController', 'sitegenesis_storefront_controllers');
var baseCartridgeCore = getPreference('BaseCartridgeCore', 'sitegenesis_storefront_core');

var PaymentMgr = require('dw/order/PaymentMgr');
var PaymentInstrument = require('dw/order/PaymentInstrument');

const GESTPAY_CREDIT = "GESTPAY_CREDIT";
const GESTPAY_PAYMENT_GATEWAY = "GESTPAY_PAYMENT_GATEWAY";

const GESTPAY_S2S_MODE = "GESTPAY_S2S_MODE";
const GESTPAY_IFRAME_MODE = "GESTPAY_IFRAME_MODE";

const CUSTOMINFO_PAYMENT_INSTRUMENT_UUID = 'PAYMENT_INSTRUMENT_UUID';
const CUSTOMINFO_SITE = 'SITE';
const CUSTOMINFO_LOCALE = 'LOCALE';
const CUSTOMINFO_ORDER_TOKEN = 'ORDER_TOKEN';

/**
 * @param {string} name
 * @param {string | number | boolean | object} [defaultValue]
 */
function getPreference(name, defaultValue) {
	if (sitePrefs !== null && name in sitePrefs.getCustom()) {
		return sitePrefs.getCustom()[name];
	}
	if (name in orgPrefs.getCustom()) {
		return orgPrefs.getCustom()[name];
	}
	return defaultValue !== undefined ? defaultValue : '';
}

function getMessage(key, defaultValue) {
	return dw.web.Resource.msg(key, 'gestpay_settings', defaultValue || null);
}

/**
 * The shop login
 */
exports.getShopLogin = function () {
	if (!shopLogin) {
		throw new Error('The Shop Login is mandatory');
	}
	return shopLogin;
};

exports.getShopLoginSavedCards = function () {
	return shopLoginSavedCards;
};

exports.selectShopLogin = function (s2s) {
	return s2s && shopLoginSavedCards || shopLogin;
};

exports.isFraudPreventionEnabled = function () {
	return fraudPreventionEnabled || fraudPreventionMode != "off";
}

exports.isFraudPreventionInShadowMode = function () {
	return fraudPreventionMode == "shadow";
}

exports.getFraudPreventionMode = function () {
	return fraudPreventionMode;
}
/**
 * The test mode can be configured in the Business Manager.
 */
exports.isTest = function () {
	return isTest;
};

exports.isEnabledGestPayProcessor = function () {
	return isEnabledGestPayProcessor;
}

exports.paymentMode = function () {
	return paymentMode;
}

exports.isPaymentModeIframe = function () {
	return paymentMode.value === 'iframe';
}

exports.isEnabledGestPayIframeToken = function () {
	return isEnabledGestPayIframeToken;
}

exports.isPaymentModeS2s = function () {
	return paymentMode.value === 's2s';
}

/**
 * Translates the ISO currency code to the Sella currency code.
 */
exports.getUicCurrencyCode = function (currencyIsoCode) {
	if (!currencyIsoCode) {
		return '';
	}
	var key = 'currency.uiccode.' + currencyIsoCode.toLowerCase();
	return getMessage(key, currencyIsoCode);
};

/**
 * Translates the ISO currency code to the Sella currency code.
 */
exports.getIsoCurrencyCode = function (currencyUicCode) {
	if (!currencyUicCode) {
		return '';
	}
	var key = 'currency.isocode.' + currencyUicCode;
	return getMessage(key, currencyUicCode);
};

/**
 * Translates the ISO currency code to the Sella currency code.
 */
exports.getCurrencyCode = function (currencyIsoCode) {
	if (!currencyIsoCode) {
		return '';
	}
	var key = 'currency.code.' + currencyIsoCode.toLowerCase();
	return getMessage(key);
};

exports.getLanguageId = function () {
	var locale = request.locale == 'default' ? 'en' : request.locale;
	var language = locale && locale.substr(0, 2) || 'NA';
	return dw.web.Resource.msg('gestpay.language.' + language, 'gestpay_settings', dw.web.Resource.msg('gestpay.language.en', 'gestpay_settings', '2'));
}

/**
 * Translates the SFCC payment code to the Sella payment code.
 */
exports.getPaymentTypeCode = function (dwPaymentType) {
	var key = 'paymenttype.code.' + dwPaymentType.toLowerCase();
	return getMessage(key);
};

exports.gestPay3dSecureUrl = function () {
	return Resource.msg('service.url.gestpay.pagam3d', utils.getPropertiesFile(), null);
}

exports.gestPayPagamPageUrl = function () {
	return Resource.msg('service.url.gestpay.pagamPage', utils.getPropertiesFile(), null);
}

exports.getJsGestPay = function () {
	try {
		var file = utils.getPropertiesFile();
		var js = Resource.msg('service.url.gestpay.js', file, null)
		return js;
	} catch (e) {
		var error = e;
		return '';
	}
}

exports.getBaseCartridgeController = function () {
	return baseCartridgeController;
}

exports.getBaseCartridgeCore = function () {
	return baseCartridgeCore;
}

exports.getGestPayWsSuccessCode = function () {
	return Resource.msg('gestpay.ws.success', "gestpay_settings", null);
}

exports.getGestPayWs3dSecureCheck = function () {
	return Resource.msg('gestpay.ws.3dsecurecheck', "gestpay_settings", null);
}

exports.getAppJsFolder = function () {
	return getPreference('GestPayAppJsFolder', 'js');
}

exports.showSummaryCreditCardForm = function (cart) {
	try {
		var paymentInstruments = cart.getPaymentInstruments();
		if (paymentMode.value === 'iframe') {
			for (var i = 0; i < paymentInstruments.length; i++) {
				var paymentInstrument = paymentInstruments[i];
				var paymentProcessor = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor();
				if (paymentInstrument.getPaymentMethod() === PaymentInstrument.METHOD_CREDIT_CARD && paymentProcessor.getID() === 'GESTPAY_CREDIT') {
					return true;
				}
			}
			return false;
		} else {
			return false;
		}
	} catch (e) {
		return false;
	}
}

exports.getDefaultThreadSleep = function () {
	return defaultThreadSleep;
}

exports.isGestpayCreditCardProcessor = function (processorId) {
	return GESTPAY_CREDIT === processorId;
}

exports.isGestpayPaymentGatewayProcessor = function (processorId) {
	return GESTPAY_PAYMENT_GATEWAY === processorId;
}

exports.getGestpayMode = function () {
	switch (paymentMode.value) {
		case 'iframe':
			return GESTPAY_IFRAME_MODE
		case 's2s':
			return GESTPAY_S2S_MODE
		default:
			return ""
	}
}

function containsGestpayProcessor(paymentInstruments) {
	return getGestpayProcessors(paymentInstruments).length > 0;
}

function containsGestpayPaymentGatewayProcessor(paymentInstruments) {
	var gestpayProcessors = getGestpayProcessors(paymentInstruments);
	return gestpayProcessors.length > 0 && gestpayProcessors.indexOf(GESTPAY_PAYMENT_GATEWAY) > -1;
}

function getGestpayProcessors(paymentInstruments) {
	var PaymentMgr = require('dw/order/PaymentMgr');
	return paymentInstruments.toArray().map(function (paymentInstrument) {
		return PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor().getID();
	}) || 0;
}
/**
 * Convert customInfo encrypt parameter to HashMap
 *
 * @param {String} customInfo
 * @returns
 */
function convertCustomInfoToMap(customInfo) {
	var map = new dw.util.HashMap();
	if (customInfo) {
		var customInfos = customInfo.split('*P1*')
		for (var entry in customInfos) {
			map.put(customInfos[entry].split('=')[0], customInfos[entry].split('=')[1]);
		}
	}
	return map;
}

function isGestpayBillingAgreement() {
	return getPreference('GestPayPayPalBillingAgreement', false);
}

function getGestpayBillingAgreementTerms() {
	return getPreference('GestPayPayPalBillingAgreementString', null);
}

function isAmazonPayEnabled() {
	return dw.order.PaymentMgr.getPaymentMethod('AMAZONPAY').active;
}

function isAmazonPayCheckoutEnabled() {
	return dw.order.PaymentMgr.getPaymentMethod('AMAZONPAY').active && getPreference('GestPayAmazonPayCheckout', false);
}

function getVendorID() {
	return getPreference('GestPayVendorID', null);
}

function getVendorName() {
	return getPreference('GestPayVendorName', null);
}

function getApikey() {
	return getPreference('GestPayApikey', null);
}

function isEnablePPSellerProtection() {
	return getPreference("GestPayEnableSellerProtection", false);
}

function isEnablePPBNPLSellerProtection() {
	return getPreference("GestPayEnableSellerProtectionBNPL", false);
}

function getViewTypeImage() {
	return getPreference("GestPayViewTypeImage", 'small');
}

function isNewKlarna() {
	return getPreference("GestPayNewKlarna", false);
}

exports.convertCustomInfoToMap = convertCustomInfoToMap;

exports.containsGestpayProcessor = containsGestpayProcessor;

exports.containsGestpayPaymentGatewayProcessor = containsGestpayPaymentGatewayProcessor;

exports.getGestpayProcessors = getGestpayProcessors;

exports.isGestpayBillingAgreement = isGestpayBillingAgreement;

exports.getGestpayBillingAgreementTerms = getGestpayBillingAgreementTerms;

exports.isAmazonPayEnabled = isAmazonPayEnabled;
exports.isAmazonPayCheckoutEnabled = isAmazonPayCheckoutEnabled;

exports.getVendorID = getVendorID;
exports.getVendorName = getVendorName;

exports.getApikey = getApikey;

exports.isEnablePPSellerProtection = isEnablePPSellerProtection;
exports.isEnablePPBNPLSellerProtection = isEnablePPBNPLSellerProtection;
exports.getViewTypeImage = getViewTypeImage;
exports.isNewKlarna = isNewKlarna;

exports.GESTPAY_CREDIT = GESTPAY_CREDIT;

exports.GESTPAY_PAYMENT_GATEWAY = GESTPAY_PAYMENT_GATEWAY;

exports.GESTPAY_S2S_MODE = GESTPAY_S2S_MODE;

exports.GESTPAY_IFRAME_MODE = GESTPAY_IFRAME_MODE;

exports.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID = CUSTOMINFO_PAYMENT_INSTRUMENT_UUID;
exports.CUSTOMINFO_SITE = CUSTOMINFO_SITE;
exports.CUSTOMINFO_LOCALE = CUSTOMINFO_LOCALE;
exports.CUSTOMINFO_ORDER_TOKEN = CUSTOMINFO_ORDER_TOKEN;