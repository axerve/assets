'use strict';
/**
 * Utility for configure service and set url before soap call
 */
var gPrequest = function () {
  var self = this;
  /** @type {dw.svc.Service} */
  var service;
  var requestData;

  self.configureService = function (name) {
    try {
      var utils = require('int_gestpay/cartridge/scripts/utils/utils');
      var gestpayServiceInit = require('int_gestpay/cartridge/scripts/init/gestpayServiceInit');
      service = gestpayServiceInit.serviceMapRegistry.get(name);
      service.setURL(utils.getUrlByName(name));
      return self;
    } catch (e) {
      var error = e;
      throw new Error(e);
    }
  };

  self.getUrl = function () {
    return service.getURL();
  };

  self.setUrl = function (url) {
    service.setURL(url);
    return self;
  };

  self.setUrlParameters = function (params) {
    var url = service.getURL();
    for (var param in params) {
      if (params.hasOwnProperty(param)) {
        url = url.replace('{' + param + '}', params[param]);
      }
    }
    service.setURL(url);
    return self;
  };

  self.setParams = function (object) {
    return self;
  };

  self.call = function (args) {
    return service.call(args);
  }
};

module.exports = gPrequest;