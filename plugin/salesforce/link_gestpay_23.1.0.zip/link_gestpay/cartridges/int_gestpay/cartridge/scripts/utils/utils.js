/**
 * Utility for basic webservice info
 */
const Resource = require('dw/web/Resource');


var logger = dw.system.Logger;
var settings = require('int_gestpay/cartridge/scripts/utils/settings');

function getBaseCartridge() {
	return settings.getBaseCartridgeController();
}

function getPropertiesFile() {
	return settings.isTest() ? 'gestpay_test' : 'gestpay';
}

exports.getPackage = function () {
	return settings.isTest() ? 'WSCryptDecryptSoap' : 'WSCryptDecryptSoap';
}

exports.getPackageS2S = function () {
	return settings.isTest() ? 'WSs2sSoap' : 'WSs2sSoap';
}

function getBaseUrl() {
	return Resource.msg('service.url.gestpay.soap.baseurl', getPropertiesFile(), null);
}

function getBaseRestUrl() {
	return Resource.msg('service.url.gestpay.rest.baseurl', getPropertiesFile(), null);
}

exports.getLogger = function () {
	return logger;
};

exports.getUrlByName = function (name) {
	var path = Resource.msg('service.url.' + name, getPropertiesFile(), null);

	if (!path) {
		throw new Error('Unknown service URL for "' + name + '"');
	}

	var baseUrl = getBaseUrl();
	var url = baseUrl + path;

	logger.debug('url = {0}', url);

	return url;
};

exports.getRestUrlByName = function (name) {
	var path = Resource.msg('service.url.' + name, getPropertiesFile(), null);

	if (!path) {
		throw new Error('Unknown service URL for "' + name + '"');
	}

	var baseUrl = getBaseRestUrl();
	var url = baseUrl + path;

	logger.debug('url = {0}', url);

	return url;
};

exports.setTimeout = function (cb, timeout) {
	var finishTime = (new Date().getTime()) + timeout
	var timerStatus = '';

	if (cb && timeout) {

		while (new Date().getTime() < finishTime) {
			timerStatus = 'waiting';
		}

		cb();
	}
};

exports.getPropertiesFile = getPropertiesFile;