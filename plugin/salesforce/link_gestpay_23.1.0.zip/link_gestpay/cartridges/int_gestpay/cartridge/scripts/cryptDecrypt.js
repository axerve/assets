/**
 * GestPay WsCryptDecrypt web service encrypt: Encrypt is the main entrypoint
 * for Gestpay. You must call Encrypt either if you want to use the standard
 * payment page, or the custom iframe solution. decrypt: GestPay communicates
 * the payment transaction result to the merchant through an encrypted string
 * (parameter b of the call to the url preconfigured by the merchant) with a set
 * of transaction’s informations.
 */
const Transaction = require('dw/system/Transaction');

const gestpay = require('int_gestpay/cartridge/scripts/gestpay');
const settings = require('int_gestpay/cartridge/scripts/utils/settings');
const orderUtils = require('int_gestpay/cartridge/scripts/utils/orderUtils');
const utils = require('int_gestpay/cartridge/scripts/utils/utils');
var WSCryptDecryptSoapFactory = new webreferences2[utils.getPackage()].ObjectFactory();
const threeDsUtils = require('int_gestpay/cartridge/scripts/utils/threeDsUtils');
var logger = utils.getLogger();
const currentSiteId = dw.system.Site.getCurrent().getID();

/**
 * @deprecated use encryptByCurrentBasket
 * @param {dw.order.Basket} basket
 * @param {boolean} requestToken
 * @param {{ paymentMethod: string }} extraInfo
 * @returns
 */
function encrypt(basket, requestToken, extraInfo) {
    var paymentInstrumentAmount = computePaymentInstrumentAmount(basket);
    var customInfo = [settings.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID, '=', ''].join('');

    var encryptObj = {
        currency: basket.getCurrencyCode(),
        amount: paymentInstrumentAmount.valueOrNull,
        shopTransactionID: orderUtils.createGestPayShopTransactionID(basket),
        customInfo: customInfo,
        requestToken: requestToken,
        orderDetails: orderUtils.createOrderDetails(basket, WSCryptDecryptSoapFactory),
        transDetails: threeDsUtils.createTransDetails(basket, WSCryptDecryptSoapFactory)
    };

    if (extraInfo && extraInfo.paymentMethod) {
        encryptObj.selectedPaymentMethodID = extraInfo.paymentMethod;
    }

    addBuyerData(basket, encryptObj);
    addSiteAndLocaleToCustomInfo(encryptObj);
    var result = gestpay.encrypt(encryptObj);
    return result;
}

/**
 * @param {dw.order.Basket} basket
 * @returns {dw.value.Money}
 */
function computePaymentInstrumentAmount(basket) {
    var paymentInstrumentAmount = basket.getTotalGrossPrice();
    if (!paymentInstrumentAmount.isAvailable()) {
        paymentInstrumentAmount = basket.getAdjustedMerchandizeTotalPrice(true).add(basket.getGiftCertificateTotalPrice());
    }
    if (dw.system.HookMgr.hasHook('gestpay.paymentInstrumentAmount')) {
        paymentInstrumentAmount = dw.system.HookMgr.callHook('gestpay.paymentInstrumentAmount', 'computePaymentInstrumentAmount', {
            lineItemCtnr: basket
        });
    }
    return paymentInstrumentAmount;
}

/**
 * @param {dw.order.LineItemCtnr} lineItemCtnr
 * @param {Object} obj
 */
function addBuyerData(lineItemCtnr, obj) {
    obj.buyerEmail = lineItemCtnr.getCustomerEmail();
    obj.buyerName = lineItemCtnr.getCustomerName();
}

/**
 * @param {Object} obj
 * @param {string} obj.customInfo
 */
function addSiteAndLocaleToCustomInfo(obj) {
    var siteAndLocaleInfos = [
        [settings.CUSTOMINFO_SITE, '=', currentSiteId].join(''),
        [settings.CUSTOMINFO_LOCALE, '=', request.locale].join('')
    ];
    if (obj.customInfo) siteAndLocaleInfos.unshift(obj.customInfo);
    obj.customInfo = siteAndLocaleInfos.join('*P1*');
}

/**
 * @param {Object} obj
 * @param {string} obj.customInfo
 */
function addOrderTokenToCustomInfo(order, obj) {
    var siteAndLocaleInfos = [
        [settings.CUSTOMINFO_ORDER_TOKEN, '=', order.getOrderToken()].join('')
    ];

    if (obj.customInfo) siteAndLocaleInfos.unshift(obj.customInfo);

    obj.customInfo = siteAndLocaleInfos.join('*P1*');
}

/**
 * used only for validate credit card iframe
 * @param {string} shopLogin
 * @param {boolean} requestToken
 * @returns {object}
 */
function encryptByCurrentBasket(shopLogin, requestToken) {
    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.getCurrentBasket();
    var paymentInstrumentAmount = computePaymentInstrumentAmount(currentBasket);
    var customInfo = [settings.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID, '=', ''].join('');
    var transDetails = threeDsUtils.createTransDetails(currentBasket, WSCryptDecryptSoapFactory);
    var encryptObj = {
        currency: currentBasket.getCurrencyCode(),
        amount: paymentInstrumentAmount.decimalValue,
        shopTransactionID: orderUtils.createGestPayShopTransactionID(currentBasket),
        customInfo: customInfo,
        requestToken: requestToken,
        transDetails: transDetails
    };
    if (shopLogin) {
        encryptObj.shopLogin = shopLogin;
    }
    const alterativePaymentInstruments = currentBasket.getPaymentInstruments().toArray().filter(function (pi) {
        return pi.paymentMethod !== dw.order.PaymentInstrument.METHOD_CREDIT_CARD;
    });
    if (alterativePaymentInstruments.length > 0) {
        encryptObj.selectedPaymentMethodID = alterativePaymentInstruments[0].paymentMethod;
    }
    addBuyerData(currentBasket, encryptObj);
    addSiteAndLocaleToCustomInfo(encryptObj);
    return gestpay.encrypt(encryptObj);
}

/**
 * @param {dw.order.OrderPaymentInstrument} orderPaymentInstrument
 * @param {dw.order.Order} order
 * @param {Boolean} requestToken
 * @returns {Object} encryptResult
 */
function encryptByOrderPaymentInstrument(orderPaymentInstrument, order, requestToken, currentBasket) {
    var result = {};
    var amount = orderPaymentInstrument.getPaymentTransaction().getAmount();
    var customInfo = [settings.CUSTOMINFO_PAYMENT_INSTRUMENT_UUID, '=', orderPaymentInstrument.getUUID()].join('');

    logger.info('[cryptDecrypt.encryptByOrderPaymentInstrument] amount = {0}', amount.valueOrNull);
    var transDetails = threeDsUtils.createTransDetails(currentBasket, WSCryptDecryptSoapFactory);
    var encryptObj = {
        currency: order.getCurrencyCode(),
        amount: amount.valueOrNull,
        shopTransactionID: order.getOrderNo(),
        selectedPaymentMethodID: orderPaymentInstrument.getPaymentMethod(),
        customInfo: customInfo,
        requestToken: requestToken,
        orderDetails: orderUtils.createOrderDetails(order, WSCryptDecryptSoapFactory),
        transDetails: transDetails
    };

    if (settings.isEnablePPSellerProtection() || settings.isEnablePPBNPLSellerProtection()) {
        encryptObj.shippingDetails = orderUtils.createShippingDetails(order, WSCryptDecryptSoapFactory);
    }

    addBuyerData(order, encryptObj);
    addSiteAndLocaleToCustomInfo(encryptObj);
    addOrderTokenToCustomInfo(order, encryptObj);
    result = gestpay.encrypt(encryptObj);
    Transaction.wrap(function () {
        order.trackOrderChange('GestpayService - createOrder - encrypt created: ' + JSON.stringify(result.getObject()));
        orderPaymentInstrument.getPaymentTransaction().getCustom().gestPayEncryptResult = JSON.stringify(result.getObject());
    });
    return result;
}

/**
 * @deprecated use encryptByOrderPaymentInstrument
 * @param {dw.order.Order} order
 * @param {Boolean} requestToken
 * @returns {Object}
 */
function encryptByOrder(order, requestToken) {
    var orderAmount = order.getTotalGrossPrice();
    var paymentInstrumentAmount;
    var selectedPaymentMethodID;
    try {
        var gestpayPaymentMethods = order.getPaymentInstruments().toArray().filter(function (paymentInstrumentTemp) {
            var paymentProcessor = dw.order.PaymentMgr.getPaymentMethod(paymentInstrumentTemp.getPaymentMethod()).getPaymentProcessor();
            return ([settings.GESTPAY_PAYMENT_GATEWAY, settings.GESTPAY_CREDIT].indexOf(paymentProcessor.getID()) > -1);
        });
        selectedPaymentMethodID = gestpayPaymentMethods[0].paymentMethod;
        if (gestpayPaymentMethods[0].paymentTransaction) {
            paymentInstrumentAmount = gestpayPaymentMethods[0].paymentTransaction.amount;
        }
    } catch (e) {
        logger.error(e);
    }
    var amount = (paymentInstrumentAmount || orderAmount);
    logger.info('[cryptDecrypt.encryptByOrder] orderAmount = {0}, paymentInstrumentAmount = {1}, amount = {2}', (orderAmount && orderAmount.decimalValue), (paymentInstrumentAmount && paymentInstrumentAmount.decimalValue), (amount && amount.decimalValue));
    var encryptObj = {
        currency: order.getCurrencyCode(),
        amount: amount.decimalValue,
        shopTransactionID: order.getOrderNo(),
        selectedPaymentMethodID: selectedPaymentMethodID || session.forms.billing.paymentMethods.selectedPaymentMethodID.value,
        requestToken: requestToken,
        orderDetails: orderUtils.createOrderDetails(order, WSCryptDecryptSoapFactory)
    };
    addBuyerData(order, encryptObj);
    addSiteAndLocaleToCustomInfo(encryptObj);
    addOrderTokenToCustomInfo(order, encryptObj);
    var result = gestpay.encrypt(encryptObj);
    Transaction.wrap(function () {
        order.trackOrderChange('GestpayService - createOrder - encrypt created: ' + JSON.stringify(result));
    });
    return result;
}

/**
 * @param {string} cryptedString
 * @param {string} shopLogin
 * @returns {Object}
 */
function decrypt(cryptedString, shopLogin) {
    var params = {
        cryptedString: cryptedString,
        shopLogin: shopLogin
    };
    return gestpay.decrypt(params);
}

/**
 * @param {string} cryptedString
 * @param {string} shopLogin
 * @returns {Object}
 */
function decryptNotificationS2S(cryptedString, shopLogin) {
    var params = {
        cryptedString: cryptedString,
        shopLogin: shopLogin
    };
    var result = gestpay.decryptNotificationS2S(params);
    return result;
}

/**
 * Starts a payment with Sella.
 */
exports.encrypt = encrypt;

exports.encryptByCurrentBasket = encryptByCurrentBasket;

exports.encryptByOrder = encryptByOrder;

exports.encryptByOrderPaymentInstrument = encryptByOrderPaymentInstrument;

/**
 * Ends a payment.
 */
exports.decrypt = decrypt;

exports.decryptNotificationS2S = decryptNotificationS2S;