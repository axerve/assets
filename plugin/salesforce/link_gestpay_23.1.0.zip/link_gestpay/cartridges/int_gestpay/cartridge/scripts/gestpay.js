/**
 * Proxy for call all WSCryptDecrypt API and WsS2S API methods
 */
const utils = require('int_gestpay/cartridge/scripts/utils/utils');
const logger = utils.getLogger();
const settings = require('int_gestpay/cartridge/scripts/utils/settings');
const gestpayServiceInit = require('int_gestpay/cartridge/scripts/init/gestpayServiceInit');

const currentSiteId = dw.system.Site.getCurrent().getID();


function configureService(serviceName) {
	var gPrequest = require('int_gestpay/cartridge/scripts/utils/gPrequest');
	var gpRequest = new gPrequest();

	return gpRequest.configureService(serviceName);
}

/**
 * @param {string} serviceName
 * @param {{ isEnabledGestPayIframeToken: any; }} obj
 * @param {boolean} [createOrderDetail]
 * @returns {dw.svc.Result}
 */
function configureAndCallService(serviceName, obj, createOrderDetail) {
	var result;
	try {
		fillShopLoginOnEmpty(obj);
		obj.isEnabledGestPayIframeToken = settings.isEnabledGestPayIframeToken();
		logRequestParams(obj, serviceName);
		var service = configureService(serviceName);
		result = service.call(obj);
	} catch (e) {
		logger.error('[gestpay.configureAndCallService] Site {0}, Service {1} failed: {2}', currentSiteId, serviceName, e.message);
	}

	return result;
}

function fillShopLoginOnEmpty(obj) {
	if (!obj.shopLogin) {
		try {
			extractShopLoginFromCurrentBasket(obj);
		} catch (e) {
			// java.lang.IllegalArgumentException: session without customer
		}
	}
	if (!obj.shopLogin) {
		obj.shopLogin = settings.getShopLogin();
	}
}

/**
 * @param {Object} obj
 */
function extractShopLoginFromCurrentBasket(obj) {
	var BasketMgr = require('dw/order/BasketMgr');
	var lic = BasketMgr.getCurrentBasket() || obj.order;
	if (lic) {
		var paymentInstruments = lic.getPaymentInstruments().toArray().filter(function (pi) {
			return !empty(pi.custom.gestPayShopLogin);
		});
		if (paymentInstruments && paymentInstruments.length > 0) {
			obj.shopLogin = paymentInstruments[0].custom.gestPayShopLogin;
		}
	}
}

/**
 * @param {Object} obj
 * @param {string} serviceName
 */
function logRequestParams(obj, serviceName) {
	var loggedObj = Object.keys(obj).filter(function (key) {
		return key !== 'orderDetails' && key !== 'transDetails' && key !== 'shippingDetails';
	}).reduce(function (acc, key) {
		acc[key] = obj[key];
		return acc;
	}, {});

	logger.info(
		'[gestpay.configureAndCallService] Site {0}, calling the service {1} with params {2} and transDetails keys {3} and order detail keys {4} and shipping details keys {5}',
		currentSiteId, serviceName, JSON.stringify(loggedObj),
		obj.transDetails ? JSON.stringify(Object.keys(obj.transDetails)) : '',
		obj.orderDetails ? JSON.stringify(Object.keys(obj.orderDetails)) : '',
		obj.shippingDetails ? JSON.stringify(Object.keys(obj.shippingDetails)) : '');
}

function encrypt(encrypt) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_ENCRYPT, encrypt, true);
}

function decrypt(decrypt) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_DECRYPT, decrypt);
}

function decryptNotificationS2S(decrypt) {
	return configureService(gestpayServiceInit.SERVICE_SOAP_DECRYPT).call(decrypt);
}

function callPagamS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_PAGAM, params, true);
}

function callSettleS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_SETTLE, params);
}

function callDeleteS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_DELETE, params);
}

function callRefundS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_REFUND, params, true);
}

function callReadTrxS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_READ_TRX, params);
}

function callVerifycardS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_VERIFY_CARD, params);
}

function callCheckCartaS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_CHECK_CARTA, params);
}

function callRequestTokenS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_REQUEST_TOKEN, params);
}

function callDeleteTokenS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_DELETE_TOKEN, params);
}

function callUpdateTokenS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_UPDATE_TOKEN, params);
}

function callIdealListS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_IDEAL_LIST, params);
}

function callMyBankListS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_MYBANK_LIST, params);
}

function callUpdateOrderS2S(params) {
	return configureAndCallService(gestpayServiceInit.SERVICE_SOAP_CALL_UPDATE_ORDER, params, true);
}

/*
 * encrypt
 */
exports.encrypt = encrypt;
/*
 * decrypt
 */
exports.decrypt = decrypt;

exports.decryptNotificationS2S = decryptNotificationS2S;
/*
 *  method
 */
exports.callPagamS2S = callPagamS2S;
/*
 * callSettleS2S method
 */
exports.callSettleS2S = callSettleS2S;
/*
 * callDeleteS2S method
 */
exports.callDeleteS2S = callDeleteS2S;
/*
 * callRefundS2S method
 */
exports.callRefundS2S = callRefundS2S;
/*
 * callReadTrxS2S method
 */
exports.callReadTrxS2S = callReadTrxS2S;
/*
 * callVerifycardS2S method
 */
exports.callVerifycardS2S = callVerifycardS2S;
/*
 * callCheckCartaS2S method
 */
exports.callCheckCartaS2S = callCheckCartaS2S;
/*
 * callRequestTokenS2S method
 */
exports.callRequestTokenS2S = callRequestTokenS2S;
/*
 * callDeleteTokenS2S method
 */
exports.callDeleteTokenS2S = callDeleteTokenS2S;
/*
 * callUpdateTokenS2S method
 */
exports.callUpdateTokenS2S = callUpdateTokenS2S;
/*
 * callIdealListS2S method
 */
exports.callIdealListS2S = callIdealListS2S;
/*
 * callMyBankListS2S method
 */
exports.callMyBankListS2S = callMyBankListS2S;
/*
 * callUpdateOrderS2S method
 */
exports.callUpdateOrderS2S = callUpdateOrderS2S;