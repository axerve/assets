/**
 * gestpay jobs for manage notification s2s
 */
var Transaction = require('dw/system/Transaction');
var Site = require('dw/system/Site');
var CustomObjectMgr = require('dw/object/CustomObjectMgr');

var app;
var settings;
var utils;
var log;
var defaultThreadSleep;
var gestpayService;


function execute(pdict) {
  try {
    app = require('*/cartridge/scripts/app');
    settings = require('int_gestpay/cartridge/scripts/utils/settings');
    utils = require('int_gestpay/cartridge/scripts/utils/utils');
    log = utils.getLogger();
    defaultThreadSleep = settings.getDefaultThreadSleep();
    gestpayService = require('*/cartridge/scripts/service/gestpayService');
    processNotifications(pdict);
    clearNotifications(pdict);
  } catch (e) {
    dw.system.Logger.error('[gestpay - notification.execute] error: ' + e.message);
  }
}

function processNotifications(pdict) {
  try {
    var notificationObj;
    var threadSleep = pdict.threadSleep ? Number(pdict.threadSleep) : defaultThreadSleep;
    var searchQuery = CustomObjectMgr.queryCustomObjects("gestpayNotification", "custom.status = {0} AND (custom.notificationSiteId = {1} OR custom.notificationSiteId = NULL AND custom.requestShopLogin = {2})", null, 'PROCESS', Site.getCurrent().getID(), settings.getShopLogin());
    log.info("Process notifications start with count " + searchQuery.count);
    while (searchQuery.hasNext()) {
      notificationObj = searchQuery.next();
      try {
        if (notificationObj.custom.requestShopLogin && notificationObj.custom.requestCryptDecryptString) {
          if (notificationObj.custom.requestShopLogin === settings.getShopLogin() && notificationObj.creationDate.getTime() < (new Date().getTime() - threadSleep)) {
            var shopLogin = notificationObj.custom.requestShopLogin;
            var cryptDecryptString = notificationObj.custom.requestCryptDecryptString;
            log.info("start gestpayPlaceOrder");
            Transaction.wrap(function () {
              notificationObj.custom.status = 'PENDING';
            });

            session.privacy.decryptNotificationResultS2S = JSON.parse(notificationObj.custom.decryptNotificationResult);

            var coPlaceOrderController = app.getController('COPlaceOrder');
            var placeOrderResult;
            if (coPlaceOrderController.hasOwnProperty('IncludeGestpayPlaceOrder')) {
              placeOrderResult = app.getController('COPlaceOrder').IncludeGestpayPlaceOrder({
                cryptDecryptString: cryptDecryptString,
                shopLogin: shopLogin
              });
            } else {
              placeOrderResult = gestpayService.placeOrderByNotificationObj(notificationObj, null);
            }

            if (placeOrderResult.error || placeOrderResult.fraudCheckInProgress) {
              Transaction.wrap(function () {
                notificationObj.custom.status = 'PROCESS';
              });
              continue;
            } else {
              Transaction.wrap(function () {
                notificationObj.custom.status = 'SUCCESS';
                notificationObj.custom.message = "Order created";
              });
            }
            log.info("placeOrderResult: " + JSON.stringify(placeOrderResult));
          } else {
            log.info("skip notification");
          }
        } else {
          log.error("shop login or cryptDecryptString not found in httpParameters");
          Transaction.wrap(function () {
            notificationObj.custom.status = 'ERROR';
            notificationObj.custom.message = 'shop login or cryptDecryptString not found in httpParameters';
          });
        }
      } catch (e) {
        var error = e;
        log.error(e);
        Transaction.wrap(function () {
          notificationObj.custom.status = 'ERROR';
          notificationObj.custom.message = e;
        });
      }
      session.privacy.decryptNotificationResultS2S = null;
    }
    log.info("Process notifications finished with count " + searchQuery.count);
    searchQuery.close();
  } catch (e) {
    var error = e;
    log.error(error);
    log.error("Error during processed gestpay notifications " + error);
  }
}

function clearNotifications(pdict) {
  try {
    var searchQuery = CustomObjectMgr.queryCustomObjects("gestpayNotification", "custom.status = 'SUCCESS'", null);
    log.info("Removing Processed Custom Objects start with count " + searchQuery.count);

    var notificationObj;
    while (searchQuery.hasNext()) {
      notificationObj = searchQuery.next();
      Transaction.wrap(function () {
        CustomObjectMgr.remove(notificationObj);
      });
    }
    log.info("Removing Processed Custom Objects finished with count " + searchQuery.count);
    searchQuery.close();
  } catch (e) {
    var error = e;
    log.error("Error during processed custom objects" + error);
  }
}


exports.execute = execute;
exports.clearNotifications = clearNotifications;
exports.processNotifications = processNotifications;