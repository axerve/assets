'use strict';

/**
 * This controller implements encrypt, 3d secure callback, s2s notifications and
 * payment gateway response
 */
var utils = require('int_gestpay/cartridge/scripts/utils/utils');
var log = utils.getLogger();
var settings = require('int_gestpay/cartridge/scripts/utils/settings');

var OrderMgr = require('dw/order/OrderMgr');
var Site = require('dw/system/Site');

var server = require('server');

const currentSiteId = dw.system.Site.getCurrent().getID();

/**
 * Encrypt is the main entrypoint for Gestpay. You must call Encrypt either if
 * you want to use the standard payment page, or the custom iframe solution.
 */
server.get('Encrypt', server.middleware.https, function (req, res, next) {
	var result = {};
	var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	var isS2s = req.querystring.savedcard === 'true';
	var saveCard = session.forms.billing.creditCardFields.saveCard.value === true;
	try {
		var paymentMethod = request.httpParameterMap.paymentmethod.submitted ?
			request.httpParameterMap.paymentmethod.stringValue : '';
		var hookName = 'app.payment.extension.GESTPAY_' + paymentMethod.toUpperCase();
		if (dw.system.HookMgr.hasHook(hookName)) {
			dw.system.HookMgr.callHook(hookName, 'PreEncrypt', {
				Basket: dw.order.BasketMgr.getCurrentBasket()
			});
		}
		var encrypt = cryptDecrypt.encryptByCurrentBasket(settings.selectShopLogin(isS2s), saveCard).getObject();
		encrypt.shopLogin = settings.selectShopLogin(isS2s);
		session.privacy.shopLogin = encrypt.shopLogin;
		result = encrypt;
		log.info('[GestPay.Encrypt] Site {0}, encrypt result: {1}', currentSiteId, JSON.stringify(result));
	} catch (e) {
		var error = e;
		log.error(error);
		res.json({
			success: false,
			error: error
		});
	}
	res.json(result);
	return next();
});

/**
 * Encrypt is the main entrypoint for Gestpay. You must call Encrypt either if
 * you want to use the standard payment page, or the custom iframe solution.
 */
server.get('AmazonPayCart', server.middleware.https, function (req, res, next) {
	var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	var error = null;
	var order = null;
	try {
		const gestpayAmazonUtils = require('*/cartridge/scripts/payment/extension/GESTPAY_AMAZONPAY');

		var basket = dw.order.BasketMgr.getCurrentBasket();
		if (basket) {
			// @ts-ignore
			gestpayAmazonUtils.preEncrypt({
				Basket: basket
			});
			var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
			order = COHelpers.createOrder(basket);

			if (order) {
				var result = cryptDecrypt.encryptByOrderPaymentInstrument(order.paymentInstruments[0], order, false).getObject();

				if (result.errorCode == 0) {
					var shopLogin = settings.getShopLogin();
					res.redirect(settings.gestPayPagamPageUrl() + '?a=' + shopLogin + '&b=' + result.cryptDecryptString);
					log.info('[GestPay.AmazonPayCart] Encrypt result: {0}', JSON.stringify(result));

					return next();
				}

				error = result.errorCode;
			} else {
				error = 'createorder';
			}
		} else {
			error = 'nocart';
		}
	} catch (e) {
		log.error('[GestPay.AmazonPayCart] Error result: {0}', error);
	}
	if (order && !dw.order.BasketMgr.getCurrentBasket()) {
		dw.order.OrderMgr.failOrder(order, true);
	}
	// there is an error, go back to cart
	res.redirect(dw.web.URLUtils.url('Cart-Show', 'paymentGatewayResponseError', true, 'message', dw.web.Resource.msg('gestpay.checkout.error.' + error, 'checkout', dw.web.Resource.msgf('gestpay.checkout.default', 'checkout', 'Error'))));
	return next();
});

/**
 * 3d secure callback
 */
server.use('GestPay3dSecureCallback', server.middleware.https, function (req, res, next) {
	var order;
	var token;
	var URLUtils = require('dw/web/URLUtils');
	var OrderMgr = require('dw/order/OrderMgr');
	var Transaction = require('dw/system/Transaction');
	var redirectUrl = 'Cart-Show';
	var redirectParamsGenericError = ['paymentGatewayResponseError', true];
	var redirectErrorUrl = URLUtils.url(redirectUrl, redirectParamsGenericError);
	try {
		order = OrderMgr.getOrder(req.querystring.orderId, req.querystring.orderToken);
		token = req.querystring.orderToken ? req.querystring.orderToken : null;
		if (!order || !token || token !== order.orderToken) {
			res.redirect(redirectErrorUrl);
		} else {
			Transaction.wrap(function () {
				order.trackOrderChange("Start GestPay3dSecureCallback, render gestpay-3dsecuretemplate");
			});
			var paymentInstrument = order.getPaymentInstruments().toArray().filter(function (paymentInstrumentTemp) {
				return paymentInstrumentTemp.paymentTransaction.custom.gestPayTransKey == req.querystring.transKey;
			})[0];
			res.render('checkout/billing/gestpay-3dsecure', {
				gestpayApiJs: settings.getJsGestPay(),
				redirectErrorUrl: redirectErrorUrl,
				orderId: req.querystring.orderId,
				orderToken: req.querystring.orderToken,
				shopLogin: paymentInstrument.custom.gestPayShopLogin,
				PaRes: req.form.PaRes || req.form.pares,
				transKey: paymentInstrument.paymentTransaction.custom.gestPayTransKey,
				cryptDecryptString: JSON.parse(paymentInstrument.getPaymentTransaction().getCustom().gestPayEncryptResult).cryptDecryptString
			});
		}
	} catch (e) {
		var error = e;
		log.error(error);
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange("GestPay3dSecureCallback error: " + e);
				OrderMgr.failOrder(order);
			});
		}
		res.redirect(redirectErrorUrl);
	}
	return next();
});

server.post('CheckIFrameCreation3dSecure', server.middleware.https, function (req, res, next) {
	var result = {};
	var order;
	var token;
	var OrderMgr = require('dw/order/OrderMgr');
	var Transaction = require('dw/system/Transaction');
	try {
		order = OrderMgr.getOrder(req.form.orderId, req.form.orderToken);
		token = req.form.orderToken ? req.form.orderToken : null;
		if (!order || !token || token !== order.orderToken) {
			result.error = true
		} else {
			Transaction.wrap(function () {
				order.trackOrderChange("Start CheckIFrameCreation3dSecure, iframe creation result: " + JSON.stringify(req.form));
			});
			if (req.form.ErrorCode == 10) {
				result.error = false;
			} else {
				result.error = true;
				Transaction.wrap(function () {
					order.trackOrderChange("CheckIFrameCreation3dSecure error, fail order");
					OrderMgr.failOrder(order);
				});
			}
		}
	} catch (e) {
		var error = e;
		log.error(error);
		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange("IFrame3dSecureResponse error: " + e);
				OrderMgr.failOrder(order);
			});
		}
	} finally {
		res.json(result);
	}
	return next();
});

server.post('IFrame3dSecureSendResponse', server.middleware.https, function (req, res, next) {
	var result = {
		error: true
	};

	var order;
	var token;
	var URLUtils = require('dw/web/URLUtils');
	var OrderMgr = require('dw/order/OrderMgr');
	var Transaction = require('dw/system/Transaction');
	var gestpayService = require('*/cartridge/scripts/service/gestpayService');

	var version = Site.current.preferences.custom.GestPayCompatibilityVersion.value;

	try {
		order = OrderMgr.getOrder(req.form.orderId, req.form.orderToken);
		token = req.form.orderToken ? req.form.orderToken : null;

		if (order && token && token === order.orderToken) {
			Transaction.wrap(function () {
				order.trackOrderChange("Start IFrame3dSecureResponse, iframe send result: " + JSON.stringify(req.form));
			});

			if (req.form.ErrorCode == settings.getGestPayWsSuccessCode()) {
				result = gestpayService.placeOrderByCryptDecryptString(req.form.EncryptedString || req.form.cryptDecryptString, req, res);

				if (!result.error) {

					if (version == 6) {
						result.redirectUrl = URLUtils.url('Order-Confirm').toString();
					} else if (version == 5) {
						result.redirectUrl = URLUtils.url('Order-Confirm', 'ID', req.form.orderId, 'token', req.form.orderToken).toString();
					}

					result.version = version;

					log.info('GestPay.js redirectUrl is ' + result.redirectUrl);
				}
			} else {
				Transaction.wrap(function () {
					order.trackOrderChange("IFrame3dSecureResponse error, fail order");
					OrderMgr.failOrder(order);
				});
			}
		}
	} catch (e) {
		var error = e;

		log.error(error);

		if (order) {
			Transaction.wrap(function () {
				order.trackOrderChange("IFrame3dSecureResponse error: " + e);
				OrderMgr.failOrder(order);
			});
		}
	} finally {

		if (result.error && !result.errorMessage) {
			result.errorMessage = dw.web.Resource.msgf('gestpay.checkout.error', 'checkout', null);
		}

		if (result.errorMessage && !result.redirectUrl) {
			result.redirectUrl = URLUtils.url('Cart-Show', 'paymentGatewayResponseError', true, 'message', result.errorMessage).toString();
		}

		res.json(result);
	}
	return next();
});

server.use('PaymentGatewayResponse', server.middleware.https, function (req, res, next) {
	var URLUtils = require('dw/web/URLUtils');
	var gestpayService = require('*/cartridge/scripts/service/gestpayService');
	var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
	var cryptDecryptString = req.querystring.b;
	var decrypt = cryptDecrypt.decrypt(cryptDecryptString, null).getObject();
	var infoMap = settings.convertCustomInfoToMap(decrypt.customInfo);
	var sentRedirectSiteId = infoMap.get('SITE');
	var sentRedirectLocale = infoMap.get('LOCALE') || dw.system.Site.getCurrent().getDefaultLocale();
	var currentLocale = req.locale.id;

	if (sentRedirectSiteId && (currentSiteId != sentRedirectSiteId || currentLocale != sentRedirectLocale)) {
		var redirectURL = URLUtils.url(new dw.web.URLAction('GestPay-PaymentGatewayResponse', sentRedirectSiteId, sentRedirectLocale)).toString() + '?' + req.querystring;
		res.redirect(redirectURL);
		return next();
	}

	var version = Site.current.preferences.custom.GestPayCompatibilityVersion.value;
	var error = false;
	var result = {};

	var redirectUrl = 'Cart-Show';
	var redirectParams = [];
	var redirectParamsGenericError = ['paymentGatewayResponseError', true];
	try {
		var placeOrderResult = gestpayService.placeOrderByCryptDecryptString(req.querystring.b, req, res);

		if (placeOrderResult.Order) {
			placeOrderResult.orderID = placeOrderResult.Order.orderNo;
			placeOrderResult.orderToken = placeOrderResult.Order.orderToken;
		}

		if (!placeOrderResult.error) {

			if (version == 6) {
				result.redirectUrl = URLUtils.url('Order-Confirm').toString();
				result.orderId = placeOrderResult.orderID;
				result.orderToken = placeOrderResult.orderToken;
			} else if (version == 5) {
				redirectParams = ['ID', placeOrderResult.orderID, 'token', dw.crypto.Encoding.toURI(placeOrderResult.orderToken)];
				redirectUrl = 'Order-Confirm';
			}

		} else {
			error = true;
			redirectParams = redirectParamsGenericError;
			redirectParams = redirectParams.concat('code', placeOrderResult.errorCode, 'message', placeOrderResult.errorMessage);
		}
	} catch (e) {
		redirectParams = redirectParamsGenericError;
		log.error(e);
	} finally {
		if (error) {
			res.redirect(URLUtils.url(redirectUrl, redirectParams));
		} else {
			if (version == 6) {
				res.render("checkout/billing/gestpayGatewayResponse", {
					result: result
				});
			} else if (version == 5) {
				res.redirect(URLUtils.url(redirectUrl, redirectParams));
			}
		}
	}
	return next();
});

server.use('S2S', server.middleware.https, function (req, res, next) {
	var message = '';
	try {
		var cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
		var Transaction = require('dw/system/Transaction');
		var StringUtils = require('dw/util/StringUtils');
		var Calendar = require('dw/util/Calendar');
		var CustomObjectMgr = require('dw/object/CustomObjectMgr');
		var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

		log.info("Gestpay S2S called with params");

		if (req.querystring.a && req.querystring.b) {
			// get parameter map values
			var requestShopLogin = req.querystring.a;
			var requestCryptDecryptString = req.querystring.b;
			var decryptNotificationResult = cryptDecrypt.decryptNotificationS2S(requestCryptDecryptString, requestShopLogin).getObject();

			var infoMap = settings.convertCustomInfoToMap(decryptNotificationResult.customInfo);
			var notificationSiteId = infoMap.get('SITE');
			var orderToken = infoMap.get("ORDER_TOKEN");

			Transaction.wrap(function () {
				// create custom object
				var keyValue = settings.selectShopLogin(true) + '-' + StringUtils.formatCalendar(new Calendar(), 'yyyyMMddhhmmssSSS');
				var decryptNotificationResultStringify = JSON.stringify(decryptNotificationResult);

				if (decryptNotificationResult && decryptNotificationResult.shopTransactionID) {
					// save with order number
					keyValue = decryptNotificationResult.shopTransactionID + '-' + StringUtils.formatCalendar(new Calendar(), 'yyyyMMddhhmmssSSS');
				}

				var customObj = CustomObjectMgr.createCustomObject('gestpayNotification', keyValue);
				customObj.custom.requestShopLogin = requestShopLogin;
				customObj.custom.requestCryptDecryptString = requestCryptDecryptString;
				customObj.custom.status = "PROCESS";
				customObj.custom.notificationSiteId = notificationSiteId;
				customObj.custom.decryptNotificationResult = decryptNotificationResultStringify;
				log.info('Gestpay - s2s - save notification (' + keyValue + ') from banca sella, decryptNotificationResult: ' + decryptNotificationResultStringify);

				var order = OrderMgr.getOrder(decryptNotificationResult.shopTransactionID, orderToken);
				var paymentsXX = ["S2PGIR", "S2PIDE", "S2PUNI"];

				if (order.status == dw.order.Order.ORDER_STATUS_CREATED && paymentsXX.indexOf(order.paymentInstrument.paymentMethod) >= 0) {
					if (decryptNotificationResult.transactionResult == 'OK') {
						OrderMgr.placeOrder(order);

						COHelpers.sendConfirmationEmail(order, req.locale.id);
					} else if (decryptNotificationResult.transactionResult == 'K0') {
						order.status == dw.order.Order.ORDER_STATUS_FAILED;
					}
				}
			});

			message = "{notificationCreated}"
		} else {
			message = "{error: shop login or cryptDecryptString not found in httpParameters}";
			log.error(message);
		}
	} catch (e) {
		var error = e;
		log.error(error);
	}
	res.json(message);
	return next();
});

server.post('GestPay3dSecureResponse', server.middleware.https, function (req, res, next) {
	var URLUtils = require('dw/web/URLUtils');
	var gestpayService = require('*/cartridge/scripts/service/gestpayService');
	var redirectUrl = 'Cart-Show';

	var version = Site.current.preferences.custom.GestPayCompatibilityVersion.value;
	var error = false;
	var result = {};

	var redirectParams = [];
	var redirectParamsGenericError = ['paymentGatewayResponseError', true];
	try {
		var placeOrderResult = gestpayService.placeOrderBy3dSecureResponse(req.querystring.transKey, req.form.PaRes || req.form.pares, req.querystring.orderNo, req.querystring.orderToken, req);

		if (!placeOrderResult.error) {

			redirectParams = ['ID', placeOrderResult.orderID, 'token', dw.crypto.Encoding.toURI(placeOrderResult.orderToken)];
			redirectUrl = 'Order-Confirm';

			if (version == 6) {
				result.redirectUrl = URLUtils.url('Order-Confirm').toString();
				result.orderId = placeOrderResult.orderID;
				result.orderToken = placeOrderResult.orderToken;
			} else if (version == 5) {
				redirectParams = ['ID', placeOrderResult.orderID, 'token', dw.crypto.Encoding.toURI(placeOrderResult.orderToken)];
				redirectUrl = 'Order-Confirm';
			}
		} else {
			error = true
			redirectParams = redirectParamsGenericError;
		}
	} catch (e) {
		redirectParams = redirectParamsGenericError;
		log.error(e);
	} finally {

		if (error) {
			res.redirect(URLUtils.url(redirectUrl, redirectParams));
		} else {
			if (version == 6) {
				res.render("checkout/billing/gestpayGatewayResponse", {
					result: result
				});
			} else if (version == 5) {
				res.redirect(URLUtils.url(redirectUrl, redirectParams));
			}
		}
	}
	return next()
});

module.exports = server.exports();