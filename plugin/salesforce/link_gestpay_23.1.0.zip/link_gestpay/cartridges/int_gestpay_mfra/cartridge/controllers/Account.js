'use strict';

var page = module.superModule;
var server = require('server');

server.extend(page);

server.append('Show', function (req, res, next) {
	var settings = require('int_gestpay/cartridge/scripts/utils/settings');
	res.setViewData({
		enableAddCreditCard: settings.isPaymentModeS2s()
	});
	return next();
});

module.exports = server.exports();