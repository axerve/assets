'use strict'

var paymentDetailsService = {
	post: function (paymentStatusRequest) {
		const LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

		const constants = require("*/cartridge/scripts/gestpayConstants")
		const PaymentStatusServiceCallBack = require('*/cartridge/scripts/service/payment/details/paymentDetailsServiceCallBack');

		var serviceName = constants.services.payment.detail.name + "." + constants.services.payment.detail.method.toLowerCase();

		var service = LocalServiceRegistry.createService(serviceName, PaymentStatusServiceCallBack.post);

		var response = service.call(paymentStatusRequest);
		return response;
	}

};

module.exports = paymentDetailsService;