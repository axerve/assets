'use strict';


/**
 * Validate current basket and calculate totals before create order
 * @param {dw.order.Basket} currentBasket the basket to validate
 * @param {Object} req the request module instance
 * @returns {Object} the validation result
 */
var validateCurrentBasket = function(currentBasket, req) {
    var HookMgr = require('dw/system/HookMgr');
    var Resource = require('dw/web/Resource');
    var Transaction = require('dw/system/Transaction');
    var URLUtils = require('dw/web/URLUtils');
    var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var technicalError = {
        error: true,
        errorMessage: Resource.msg('error.technical', 'checkout', null)
    };

    try {
        if (!currentBasket) {
            return {
                error: true,
                cartError: true,
                fieldErrors: [],
                serverErrors: [],
                redirectUrl: URLUtils.url('Cart-Show').toString()
            };
        }

        var hooksHelper = require('*/cartridge/scripts/helpers/hooks');
        var validationBasketStatus = hooksHelper('app.validate.basket', 'validateBasket', currentBasket, false, require('*/cartridge/scripts/hooks/validateBasket').validateBasket);
        if (validationBasketStatus.error) {
            return {
                error: true,
                errorMessage: validationBasketStatus.message
            };
        }

        // Check to make sure there is a shipping address
        if (currentBasket.defaultShipment.shippingAddress === null) {
            return {
                error: true,
                errorStage: {
                    stage: 'shipping',
                    step: 'address'
                },
                errorMessage: Resource.msg('error.no.shipping.address', 'checkout', null)
            };
        }

        // Check to make sure billing address exists
        if (!currentBasket.billingAddress) {
            return {
                error: true,
                errorStage: {
                    stage: 'payment',
                    step: 'billingAddress'
                },
                errorMessage: Resource.msg('error.no.billing.address', 'checkout', null)
            };
        }

        // Calculate the basket
        Transaction.wrap(function() {
            basketCalculationHelpers.calculateTotals(currentBasket);
        });

        // Re-validates existing payment instruments
        var validPayment = COHelpers.validatePayment(req, currentBasket);
        if (validPayment.error) {
            return {
                error: true,
                errorStage: {
                    stage: 'payment',
                    step: 'paymentInstrument'
                },
                errorMessage: Resource.msg('error.payment.not.valid', 'checkout', null)
            };
        }

        // Re-calculate the payments.
        var calculatedPaymentTransactionTotal = COHelpers.calculatePaymentTransaction(currentBasket);
        if (calculatedPaymentTransactionTotal.error) {
            return technicalError;
        }

        return {
            error: false
        };
    } catch (e) {
        return technicalError;
    }
};

exports.validateCurrentBasket = validateCurrentBasket;
