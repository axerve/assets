'use strict';

module.exports = {
    services: {
        payment: {
            detail: {
                name: "gestpay.rest.paymentDetails",
                method: "POST"
            }
        }
    }
};