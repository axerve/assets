/**
 * GestPay processor service
 *
 * service for handle processor methods (Handle - Authorize - Capture)
 *
 * Handle: Verifies a credit card against a valid card number and expiration
 * date and possibly invalidates invalid form fields or create paymentinstrument
 * with selected payment gateway. If the verification was successful a credit
 * card payment instrument is created
 *
 * Authorize: Authorizes a payment using a credit card or save order number as
 * transaction id if current payment processor is PAYMENT_GATEWAY
 */
'use strict';

const PaymentInstrument = require('dw/order/PaymentInstrument');
const PaymentMgr = require('dw/order/PaymentMgr');
const Resource = require('dw/web/Resource');
const Transaction = require('dw/system/Transaction');

var server = require('server');

/* API Includes */
const utils = require('int_gestpay/cartridge/scripts/utils/utils');
const settings = require('int_gestpay/cartridge/scripts/utils/settings');
const cryptDecrypt = require('int_gestpay/cartridge/scripts/cryptDecrypt');
const orderUtils = require('int_gestpay/cartridge/scripts/utils/orderUtils');
const CustomerPaymentInstrument = require('int_gestpay/cartridge/scripts/utils/customerPaymentUtils');

const logger = utils.getLogger();
const currentSiteId = dw.system.Site.getCurrent().getID();


/**
 * Handle main method
 *
 * @param args
 * @return {Object}
 * @constructor
 */
function Handle() {
	/** @type {dw.order.Basket} */
	var currentBasket = arguments[0][0];
	var billingData = arguments[0][1];
	var paymentInformation = billingData.paymentInformation;
	var paymentMethod = billingData.paymentMethod.value;
	var serverErrors = [];
	var result = {
		fieldErrors: [],
		serverErrors: serverErrors,
		error: false
	};

	try {
		var paymentInstrumentAmount = computeAmount(currentBasket, paymentInformation.amount);
		removeAllGestPayProcessorsFromBasket(currentBasket);
		var paymentInstrument = createNewPaymentInstrument(currentBasket, paymentMethod, paymentInstrumentAmount, billingData);

		switch (billingData.paymentProcessor.ID) {
			case settings.GESTPAY_CREDIT:
				handleCreditCardProcessor(currentBasket, paymentInstrument, billingData, result);
				break;
			case settings.GESTPAY_PAYMENT_GATEWAY:
				result.error = false;
				break;
			default:
				result.error = true;
				serverErrors.push(Resource.msg('error.technical', 'checkout', null));
				break;
		}
	} catch (e) {
		logger.error(e);
		result.error = true;
		serverErrors.push(Resource.msg('error.technical', 'checkout', null));
	}

	return result;
}

/**
 *
 * @param {dw.order.Basket} basket
 * @param {dw.value.Money} amountIfNotHook
 * @returns {dw.value.Money}
 */
function computeAmount(basket, amountIfNotHook) {
	if (dw.system.HookMgr.hasHook('gestpay.paymentInstrumentAmount')) {
		return dw.system.HookMgr.callHook('gestpay.paymentInstrumentAmount', "computePaymentInstrumentAmount", {
			lineItemCtnr: basket
		});
	}
	return amountIfNotHook || basket.getTotalGrossPrice();
}

/**
 *
 * @param {dw.order.Basket} basket
 */
function removeAllGestPayProcessorsFromBasket(basket) {
	Transaction.wrap(function () {
		basket.getPaymentInstruments().toArray().forEach(function (paymentInstrument) {
			var paymentMethod = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod());
			if (!paymentMethod) {
				return;
			}
			var paymentProcessor = paymentMethod.getPaymentProcessor();
			if ([settings.GESTPAY_PAYMENT_GATEWAY, settings.GESTPAY_CREDIT].indexOf(paymentProcessor.getID()) > -1) {
				basket.removePaymentInstrument(paymentInstrument);
			}
		});
	});
}

/**
 * @param {dw.order.Basket} basket
 * @param {string} paymentMethod
 * @param {dw.value.Money} amount
 * @param {Object} billingData
 * @returns {dw.order.OrderPaymentInstrument}
 */
function createNewPaymentInstrument(basket, paymentMethod, amount, billingData) {
	return Transaction.wrap(function () {
		var paymentInstrument = basket.createPaymentInstrument(paymentMethod, amount);
		paymentInstrument.paymentTransaction.custom.gestPayShopTransactionID = orderUtils.createGestPayShopTransactionID(basket);
		paymentInstrument.paymentTransaction.paymentProcessor = billingData.paymentProcessor;
		if (billingData.extraPaymentInfo) {
			paymentInstrument.custom.gestPayShopLogin = billingData.extraPaymentInfo.shopLogin;
		}
		CustomerPaymentInstrument.addTokenToOrderPaymentIfNecessary(paymentInstrument);
		return paymentInstrument;
	});
}

/**
 * @param {dw.order.Basket} currentBasket
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns
 */
function handleCreditCardProcessor(currentBasket, paymentInstrument, billingData, result) {
	var paymentInformation = billingData.paymentInformation;
	var expirationMonth = paymentInformation.expirationMonth.value;
	var expirationYear = paymentInformation.expirationYear.value;
	var cardType = paymentInformation.cardType.value;

	switch (settings.getGestpayMode()) {
		case settings.GESTPAY_IFRAME_MODE:
			Transaction.wrap(function () {
				paymentInstrument.setCreditCardHolder(currentBasket.billingAddress.fullName);
				paymentInstrument.setCreditCardType(cardType);
				paymentInstrument.setCreditCardExpirationMonth(expirationMonth);
				paymentInstrument.setCreditCardExpirationYear(expirationYear);
				paymentInstrument.setCreditCardNumber('XXXXXXXXXXXX' + paymentInformation.cardNumber.value.substring(12));
				if (paymentInformation.creditCardToken) {
					paymentInstrument.setCreditCardToken(paymentInformation.creditCardToken);
				}
			});
			break;
		case settings.GESTPAY_S2S_MODE:
			var cardNumber = paymentInformation.cardNumber.value;
			var cardSecurityCode = paymentInformation.securityCode.value;
			var wsS2S = require('int_gestpay/cartridge/scripts/wsS2S');
			var creditCardStatus = wsS2S.callCheckCartaS2S(
				paymentInstrument.paymentTransaction.custom.gestPayShopTransactionID,
				cardNumber,
				expirationMonth,
				expirationYear,
				cardSecurityCode,
				paymentInformation.creditCardToken,
				'N', {
					shopLogin: paymentInstrument.custom.gestPayShopLogin || settings.getShopLogin()
				}).object;
			if (creditCardStatus.transactionResult == 'KO') {
				setS2sErrors(creditCardStatus, result, paymentInformation)
			} else {
				Transaction.wrap(function () {
					paymentInstrument.setCreditCardHolder(currentBasket.billingAddress.fullName);
					paymentInstrument.setCreditCardNumber(cardNumber);
					paymentInstrument.setCreditCardType(cardType);
					paymentInstrument.setCreditCardExpirationMonth(expirationMonth);
					paymentInstrument.setCreditCardExpirationYear(expirationYear);
					paymentInstrument.setCreditCardToken(paymentInformation.creditCardToken ? paymentInformation.creditCardToken : cardNumber);
				});
			}
			break;
	}
}

function setS2sErrors(creditCardStatus, result, paymentInformation) {
	dw.system.Logger.error('[gestpayProcessorService.handleCreditCardProcessor] Site {0}, failed callCheckCartaS2S: {1}',
		currentSiteId, JSON.stringify(creditCardStatus));
	result.error = true;
	result.serverErrors.push(Resource.msg('error.card.information.error', 'creditCard', null));
	// error, check fields
	var cardErrors = {};
	if (creditCardStatus.checkDigit == 'KO' || creditCardStatus.transactionErrorCode == "1119") {
		cardErrors[paymentInformation.cardNumber.htmlName] = Resource.msg('error.invalid.card.number', 'creditCard', null);
	}
	if (creditCardStatus.checkDate == 'KO') {
		cardErrors[paymentInformation.expirationMonth.htmlName] = Resource.msg('error.expired.credit.card', 'creditCard', null);
		cardErrors[paymentInformation.expirationYear.htmlName] = Resource.msg('error.expired.credit.card', 'creditCard', null);
	}
	if (creditCardStatus.checkCVV == 'KO') {
		cardErrors[paymentInformation.securityCode.htmlName] = Resource.msg('error.invalid.security.code', 'creditCard', null);
	}
	result.fieldErrors = [cardErrors];
}

/**
 * Authorizes a payment using a credit card. Customizations may use other
 * processors and custom logic to authorize credit card payment.
 *
 * @param {number} orderNumber - The current order's number
 * @param {dw.order.PaymentInstrument} paymentInstrument - The payment instrument to authorize
 * @param {dw.order.PaymentProcessor} paymentProcessor - The payment processor of the current payment method
 * @return {Object} returns an error object
 */
function Authorize() {
	var URLUtils = require('dw/web/URLUtils');
	var Transaction = require("dw/system/Transaction");
	var orderNumber = arguments[0][0];
	var paymentInstrument = arguments[0][1];
	var paymentProcessor = arguments[0][2];
	var orderToken = arguments[0][3];
	var serverErrors = [];
	var fieldErrors = {};
	var authorizeResult = {};
	var error = false;
	var result = {
		fieldErrors: fieldErrors,
		serverErrors: serverErrors,
		error: error
	};
	try {
		var order = dw.order.OrderMgr.getOrder(orderNumber, orderToken);

		Transaction.wrap(function () {
			order.trackOrderChange(['Authorization', paymentInstrument.getPaymentMethod(), 'in progress'].join(' '));
		});

		switch (paymentProcessor.ID) {
			case settings.GESTPAY_CREDIT:
				authorizeResult = authorizeCreditCardProcessor(orderNumber, orderToken, paymentInstrument);
				if (authorizeResult.redirect3dSecure) {
					result.redirect3dSecure = authorizeResult.redirect3dSecure;
				}
				break;
			case settings.GESTPAY_PAYMENT_GATEWAY:
				authorizeResult = authorizePaymentGatewayProcessor(order, paymentInstrument);
				break;
			default:
				result.error = true;
				var errorMsg = 'No payment processor found';
				logger.error('[gestpayProcessorService.Authorize] Site {0}: {1}', currentSiteId, errorMsg);
				serverErrors.push(errorMsg);
				serverErrors.push(Resource.msg('error.technical', 'checkout', null));
				break;
		}
		Transaction.wrap(function () {
			order.trackOrderChange('Authorize - ' + paymentInstrument.getPaymentMethod() + ' - result: ' + JSON.stringify(authorizeResult));
			// set payment instrument info from authorize result
			paymentInstrument.paymentTransaction.transactionID = authorizeResult.bankTransactionID;
			orderUtils.changePaymentTransactionResult(paymentInstrument, order, authorizeResult.transactionResult);
		});
		// check authorize result
		if (authorizeResult.errorCode == settings.getGestPayWsSuccessCode() || authorizeResult.errorCode === settings.getGestPayWs3dSecureCheck()) {
			result.error = false;
		} else {
			logger.warn('AuthorizeResult failed for ' + currentSiteId + ' ' + authorizeResult.shopTransactionID + ': ' + authorizeResult.errorDescription + '\n' + JSON.stringify(authorizeResult, null, 2));
			result.error = true;
			serverErrors.push(Resource.msg('error.technical', 'checkout', null));
			result.errorCode = authorizeResult.errorCode;
		}
	} catch (e) {
		result.error = true;
		logger.error(e);
		serverErrors.push(e);
		serverErrors.push(Resource.msg('error.technical', 'checkout', null));
	} finally {
		Transaction.wrap(function () {
			order.trackOrderChange(['Authorization', paymentInstrument.getPaymentMethod(), 'result:', JSON.stringify(result)].join(' '));
		});
	}
	return result;
}

/**
 * check authorize using decrypt string from request (response from payment
 * gateway) or session (Job)
 *
 * @param {dw.order.Order} order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @returns
 */
function authorizePaymentGatewayProcessor(order, paymentInstrument) {
	var result;
	var billingData = server.forms.getForm('billing');
	if (session.privacy.decryptNotificationResultS2S) {
		result = session.privacy.decryptNotificationResultS2S;
	} else {
		result = cryptDecrypt.decrypt(request.httpParameterMap.b.value, null).getObject();
	}
	// check save token
	if (!paymentInstrument.creditCardToken && customer && customer.authenticated && customer.registered && result.token &&
		(billingData.creditCardFields.saveCard.checked || paymentInstrument.paymentMethod !== 'CREDIT_CARD')) {
		// save credit card
		try {
			substitutePaymentInstrumentOfMethod(paymentInstrument.paymentMethod, result.token);
		} catch (e) {
			Transaction.wrap(function () {
				order.trackOrderChange(['Authorization', paymentInstrument.getPaymentMethod(), 'error during save credit card:', e].join(' '));
			});
		}
	} else if (paymentInstrument.creditCardToken) {
		const wsS2S = require('int_gestpay/cartridge/scripts/wsS2S');
		result = wsS2S.callPagamS2S(
			paymentInstrument.getPaymentTransaction().getAmount().getValue(),
			paymentInstrument.getPaymentTransaction().getAmount().getCurrencyCode(),
			order.getOrderNo(),
			null, null, null, paymentInstrument.creditCardToken, null, paymentInstrument, order).getObject();
	}

	return result;
}

/**
 * @param {string} method
 * @param {string} token
 * @returns {dw.customer.CustomerPaymentInstrument}
 */
function substitutePaymentInstrumentOfMethod(method, token) {
	const walvar = customer.getProfile().getWallet();
	return Transaction.wrap(function () {
		wallet.getPaymentInstruments(method).toArray()
			.filter(function (pi) {
				return (method === 'PAYPAL' || method === 'PAYPAL_BNPL') && pi.paymentMethod === method;
			})
			.forEach(function (pi) {
				wallet.removePaymentInstrument(pi);
			});

		var storedPaymentInstrument = wallet.createPaymentInstrument(method);
		storedPaymentInstrument.setCreditCardToken(token);

		return storedPaymentInstrument;
	});
}

/**
 * Check authorize result for credit card processor (IFRAME and S2S mode)
 *
 * @param {String} orderNumber
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument
 * @return {Object}
 */
function authorizeCreditCardProcessor(orderNumber, orderToken, paymentInstrument) {
	var authorizeResult = null;
	var URLUtils = require('dw/web/URLUtils');
	var wsS2S = require('int_gestpay/cartridge/scripts/wsS2S');
	var billingData = server.forms.getForm('billing');

	var order = dw.order.OrderMgr.getOrder(orderNumber, orderToken);
	// check gestpay mode
	switch (settings.getGestpayMode()) {
		case settings.GESTPAY_IFRAME_MODE:
			if (paymentInstrument.creditCardToken) {
				var cardNumber = '';
				var expiryYear = '';
				var expiryMonth = '';
				var shopTransactionID = orderNumber;
				var currency = paymentInstrument.paymentTransaction.amount.currencyCode;
				var amount = paymentInstrument.paymentTransaction.amount.decimalValue;
				var cvvValue = (billingData.creditCardFields.securityCode.value && billingData.creditCardFields.securityCode.value !== 'undefined') ? billingData.creditCardFields.securityCode.value : '';
				var cvv = cvvValue;
				var tokenValue = paymentInstrument.creditCardToken;
				// call pagamS2S using token
				authorizeResult = wsS2S.callPagamS2S(amount, currency, shopTransactionID, cardNumber, expiryMonth, expiryYear, tokenValue, cvv, paymentInstrument, order).getObject();
			} else {
				// get decrypt result
				authorizeResult = JSON.parse(paymentInstrument.getPaymentTransaction().getCustom().gestPayDencryptResult);
			}
			// check save credit card
			if (!paymentInstrument.creditCardToken && customer.authenticated && customer.registered && billingData.creditCardFields.saveCard.checked && authorizeResult.token) {
				// save credit card
				try {
					var walvar = customer.getProfile().getWallet();
					Transaction.wrap(function () {
						// wallet.getPaymentInstruments('CREDIT_CARD').toArray()
						var storedPaymentInstrument = wallet.createPaymentInstrument('CREDIT_CARD');
						storedPaymentInstrument.setCreditCardHolder(paymentInstrument.creditCardHolder);
						storedPaymentInstrument.setCreditCardNumber(authorizeResult.token);
						storedPaymentInstrument.setCreditCardType(paymentInstrument.creditCardType);
						storedPaymentInstrument.setCreditCardExpirationMonth(paymentInstrument.creditCardExpirationMonth);
						storedPaymentInstrument.setCreditCardExpirationYear(paymentInstrument.creditCardExpirationYear);
						storedPaymentInstrument.setCreditCardToken(authorizeResult.token);
						storedPaymentInstrument.custom.isGestPayToken = true;
					});
				} catch (e) {
					Transaction.wrap(function () {
						order.trackOrderChange(['Authorization', paymentInstrument.getPaymentMethod(), 'error during save credit card:', e].join(' '));
					});
				}
			}
			break;
		case settings.GESTPAY_S2S_MODE:
			// S2S mode
			var currency = paymentInstrument.paymentTransaction.amount.currencyCode;
			var amount = paymentInstrument.paymentTransaction.amount.decimalValue;
			var cardNumber = paymentInstrument.custom.isGestPayToken ? null : paymentInstrument.creditCardToken;
			var expiryMonth = paymentInstrument.creditCardExpirationMonth;
			var expiryYear = paymentInstrument.creditCardExpirationYear;
			var tokenValue = paymentInstrument.custom.isGestPayToken ? paymentInstrument.creditCardToken : null;
			var cvv = billingData.creditCardFields.securityCode.value;
			// call pagam S2S using card number or token
			authorizeResult = wsS2S.callPagamS2S(amount, currency, orderNumber, cardNumber, expiryMonth, expiryYear, tokenValue, cvv, paymentInstrument, order).getObject();
			break;
	}
	// check 3d secure
	if (authorizeResult.errorCode == settings.getGestPayWs3dSecureCheck()) {
		// save transKey 3d secure
		Transaction.wrap(function () {
			paymentInstrument.paymentTransaction.custom.gestPayTransKey = String(authorizeResult.transKey);
		});
		// set 3d redirect url
		var urlResponse = URLUtils.https('GestPay-GestPay3dSecureResponse', 'transKey', String(authorizeResult.transKey), 'orderNo', orderNumber);
		authorizeResult.redirect3dSecure = [settings.gestPay3dSecureUrl(), '?a=', paymentInstrument.custom.gestPayShopLogin, '&b=', authorizeResult.vbVRisp, '&c=', dw.crypto.Encoding.toURI(urlResponse)].join('');

	}
	return authorizeResult;
}

exports.Handle = Handle;

exports.Authorize = Authorize;