'use strict';

var paymentDetailsServiceCallBack = {
	post: {
		createRequest: function (svc, params) {
			const constants = require("*/cartridge/scripts/gestpayConstants")

			svc.setRequestMethod(constants.services.payment.detail.method.toLowerCase());
			svc.setURL(params.getUrl());

			var headers = params.getHeaders();
			var headersKeys = headers.keySet().iterator();

			while (headersKeys.hasNext()) {
				var key = headersKeys.next();
				svc.addHeader(key, headers[key]);
			}

			var body = params.getBodyStringify();

			return body;
		},
		parseResponse: function (svc, response) {
			var res = JSON.parse(response.text)

			return res;
		},
		filterLogMessage: function (msg) {
			return msg;
		}
	}
};

module.exports = paymentDetailsServiceCallBack;