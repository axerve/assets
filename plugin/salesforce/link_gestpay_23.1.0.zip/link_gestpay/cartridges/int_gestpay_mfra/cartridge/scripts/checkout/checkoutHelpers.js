'use strict';

var base = module.superModule;

if (!base) {
    base = {};
}

/**
 * handles the payment authorization for each payment instrument
 * @param {dw.order.Order} order - the order object
 * @param {string} orderNumber - The order number for the order
 * @returns {Object} an error object
 */
function handlePayments(order, orderNumber) {
    var PaymentMgr = require('dw/order/PaymentMgr');
    var Transaction = require('dw/system/Transaction');
    var HookMgr = require('dw/system/HookMgr');
    var OrderMgr = require('dw/order/OrderMgr');

    var result = {};

    var orderToken = order.getOrderToken();

    if (order.totalNetPrice !== 0.00) {
        var paymentInstruments = order.paymentInstruments;

        if (paymentInstruments.length === 0) {
            Transaction.wrap(function () {
                OrderMgr.failOrder(order);
            });
            result.error = true;
        }

        if (!result.error) {
            for (var i = 0; i < paymentInstruments.length; i++) {
                var paymentInstrument = paymentInstruments[i];
                var paymentProcessor = PaymentMgr
                    .getPaymentMethod(paymentInstrument.paymentMethod)
                    .paymentProcessor;
                var authorizationResult;
                if (paymentProcessor === null) {
                    Transaction.begin();
                    paymentInstrument.paymentTransaction.setTransactionID(orderNumber);
                    Transaction.commit();
                } else {
                    if (HookMgr.hasHook('app.payment.processor.' +
                            paymentProcessor.ID.toLowerCase())) {
                        authorizationResult = HookMgr.callHook(
                            'app.payment.processor.' + paymentProcessor.ID.toLowerCase(),
                            'Authorize',
                            orderNumber,
                            paymentInstrument,
                            paymentProcessor,
                            orderToken
                        );
                    } else {
                        authorizationResult = HookMgr.callHook(
                            'app.payment.processor.default',
                            'Authorize'
                        );
                    }

                    if (authorizationResult.error) {
                        Transaction.wrap(function () {
                            OrderMgr.failOrder(order);
                        });
                        result.error = true;
                        break;
                    }

                    if (authorizationResult.redirect3dSecure) {
                        result.redirect3dSecure = authorizationResult.redirect3dSecure;
                    }
                }
            }
        }
    }

    return result;
}

/**
 * checks if the current order has a specified payment method
 * @param {Object} order - The current order
 * @param {string} paymentMethodID - The payment method to look for
 * @returns {boolean} paymentMethodFlag - true if the searched payment method is found
 */
function checkOrderPaymentMethod(order, paymentMethodID) {
    var result = false;
    var paymentInstruments = order.getPaymentInstruments();

    if (paymentInstruments) {

        var paymentInstyrumentsIterator = paymentInstruments.iterator();

        while (paymentInstyrumentsIterator.hasNext() && !result) {

            var paymentInstrument = paymentInstyrumentsIterator.next();
            var paymentMethod = paymentInstrument.getPaymentMethod();

            if (paymentMethod) {
                result = paymentMethodID == paymentMethod;
            }

        }
    }

    return result;
}

function updateImageOnProductLineItem(dwBasket, orderModel) {
    var Transaction = require('dw/system/Transaction');

    var settings = require('*/cartridge/scripts/utils/settings');

    var viewType = settings.getViewTypeImage();

    var items = orderModel.items.items;

    for (var i = 0; i < items.length && viewType; i++) {
        var productLineItem = findProductLineItemByID(dwBasket, items[i].id);

        if (productLineItem) {
            Transaction.wrap(function () {
                productLineItem.custom.GestPayProductImage = items[i].images[viewType][0].absURL;
            });
        }
    }
}

function findProductLineItemByID(dwBasket, productID) {
    var productLineItem = null;

    var iterator = dwBasket.productLineItems.iterator();

    while (iterator.hasNext() && !productLineItem) {
        var current = iterator.next();

        if (current.productID == productID) {
            productLineItem = current;
        }
    }

    return productLineItem;
}

base.handlePayments = handlePayments;
base.checkOrderPaymentMethod = checkOrderPaymentMethod;
base.updateImageOnProductLineItem = updateImageOnProductLineItem;

module.exports = base;