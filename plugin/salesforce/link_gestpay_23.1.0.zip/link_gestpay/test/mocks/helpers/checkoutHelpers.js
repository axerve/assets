'use strict';

var proxyquire = require('proxyquire').noCallThru().noPreserveCache();

var transaction = {
    wrap: function (callBack) {
        return callBack.call();
    },
    begin: function () {},
    commit: function () {}
};

var settings = {
    getViewTypeImage: function () {
        return "large";
    }
}

function proxyModel() {
    return proxyquire('../../../cartridges/int_gestpay_mfra/cartridge/scripts/checkout/checkoutHelpers', {
        'dw/system/Transaction': transaction,
        "*/cartridge/scripts/utils/settings": settings
    });
}

module.__proto__.superModule = require("../../../../storefront-reference-architecture/test/mocks/helpers/checkoutHelpers");

module.exports = proxyModel();