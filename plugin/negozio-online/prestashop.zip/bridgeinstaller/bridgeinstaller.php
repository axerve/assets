<?php
/**
 * 2007-2019 PrestaShop SA and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2019 PrestaShop SA and Contributors
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

require_once(dirname(__FILE__) . '/../../config/config.inc.php');
require_once(dirname(__FILE__) . '/../../init.php');
require_once(dirname(__FILE__) . '/worker.php');

if (!defined('_PS_VERSION_')) {
    exit;
}

class Bridgeinstaller extends Module
{

    public function __construct()
    {
        $this->name = 'bridgeinstaller';
        $this->tab = 'others';
        $this->version = '1.0.0';
        $this->author = 'Api2cart';
        $this->cart_name = 'Prestashop';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.5');

        $this->module_key = md5($this->name . $this->author);
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        parent::__construct();

        $this->displayName = $this->l('Bridge Installer');
        $this->description = $this->l('Plugin for downloading bridge files');
    }

    public function ajaxProcessAPIRequest()
    {
        $worker = new BridgeIntegration();
        $returnData = array(
            'install' => false,
            'storeKeyUpdate' => false,
            'remove' => false,
        );

        switch (Tools::getValue('method')) {
            case 'installBridge':
                $storeKey = BridgeIntegration::generateStoreKey();
                $returnData['install'] = $worker->installBridge();
                $returnData['storeKeyUpdate'] = $worker->updateToken($storeKey);
                $returnData['storeKey'] = $storeKey;
                break;

            case 'removeBridge':
                $returnData['remove'] = $worker->unInstallBridge();
                break;

            case 'updateToken':
                $storeKey = BridgeIntegration::generateStoreKey();
                $returnData['storeKeyUpdate'] = $worker->updateToken($storeKey);
                $returnData['storeKey'] = $storeKey;
        }

        die('<div id="jsonResultAjax">' . Tools::jsonEncode(array('result' => $returnData)) . '</div>');
    }

    public function install()
    {
        return parent::install();
    }

    public function uninstall()
    {
        $worker = new BridgeIntegration();
        if (!$worker->canUninstallModule()) {
            return false;
        } else {
            return parent::uninstall();
        }
    }

    public function displayOutput()
    {
        return $this->display(__FILE__, 'views/templates/admin/header.tpl');
    }

    public function getContent()
    {
        if (Tools::getValue('action') == 'APIRequest') {
            $this->ajaxProcessAPIRequest();
        }

        $worker = new BridgeIntegration();
        $showButton = 'install';
        $storeKey = '';

        if ($worker->isBridgeExist()) {
            $storeKey = $worker->getStoreKey();
            $showButton = 'uninstall';
        }

        $prestashopVersion = (float)_PS_VERSION_;

        if ($prestashopVersion >= 1.5) {
            $this->smarty->assign(array(
                'showButton' => $showButton,
                'storeKey' => $storeKey,
                'cartName' => $this->cart_name
            ));

            $this->context->controller->addCSS($this->_path . 'views/css/main.css', 'all');
            $this->context->controller->addJS($this->_path . 'views/js/scripts.js');

            $html = '
            <script type="text/javascript">
            var ajaxUrl = "' . $this->context->link->getAdminLink('AdminModules') . '&configure=' . $this->name . '";
            </script>
            ';
        }

        return $html . $this->displayOutput();
    }
}
