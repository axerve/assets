<?php
/**
 * @category EasyNolo
 * @package  EasyNolo_BancaSellaPro
 * @author   Easy Nolo <ecommerce@sella.it>
 */
class EasyNolo_BancaSellaPro_Block_Confirm3d extends Mage_Core_Block_Template {

    public function getPARes(){
        $pares = $this->getRequest()->get('PaRes');
        $helper = Mage::helper('easynolo_bancasellapro');
        $pares = $helper->normalizePARes($pares);
        return $pares;
    }

    public function getCartUrl(){
        return Mage::getUrl('checkout/cart',array('_secure' => Mage::app()->getStore()->isCurrentlySecure()));
    }

}