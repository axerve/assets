<?php
/**
 * Created by PhpStorm.
 * User: Massimo Maino
 * Date: 28/10/16
 * Time: 16:39
 */ 
class EasyNolo_BancaSellaPro_Model_Sales_Order_FingerPrint extends Mage_Core_Model_Abstract
{

    protected function _construct()
    {
        $this->_init('easynolo_bancasellapro/sales_order_fingerPrint');
    }

}