<?php
/**
 * @category EasyNolo
 * @package  EasyNolo_BancaSellaPro
 * @author   Easy Nolo <ecommerce@sella.it>
 */

class EasyNolo_BancaSellaPro_Model_Observer extends Mage_Core_Model_Abstract{


    public function processPaymentReviewStatuses()
    {
        foreach (Mage::app()->getStores() as $store)
        {
            $active = Mage::getStoreConfig('payment/gestpaypro/active', $store->getId());
            if (empty($active)) {
                continue;
            }

            $plan = Mage::getStoreConfig('payment/gestpaypro/plan', $store->getId());
            if (empty($plan) || $plan == EasyNolo_BancaSellaPro_Helper_Data::PLAN_STARTER) {
                continue;
            }

            $appEmulation = Mage::getSingleton('core/app_emulation');
            $initialEnvironmentInfo = $appEmulation->startEnvironmentEmulation($store->getId());

            $statuses = array(Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW, Mage_Sales_Model_Order::STATE_PENDING_PAYMENT);
            if (Mage::getStoreConfig('payment/gestpaypro_riskified/enable')) {
                $status = Mage::getStoreConfig('payment/gestpaypro_riskified/submitted_order_status');
                if ($status) {
                    $statuses[$status] = $status;
                }
            }
            if (Mage::getStoreConfig('payment/gestpaypro_red/enable')) {
                $status = Mage::getStoreConfig('payment/gestpaypro_red/challenge_order_status');
                if ($status) {
                    $statuses[$status] = $status;
                }
            }

            if (!empty($statuses)) {
                $collection = Mage::getResourceModel('sales/order_collection')
                    ->join(array('payment' => 'sales/order_payment'),'main_table.entity_id=payment.parent_id',
                        array('payment_method' => 'payment.method')
                    )
                    ->addFieldToFilter('store_id', $store->getId())
                    ->addFieldToFilter('status', $statuses)
                    ->addFieldToFilter('payment.method', EasyNolo_BancaSellaPro_Model_Gestpay::METHOD_CODE)
                ;

                foreach ($collection as $order) {
                    Mage::helper('easynolo_bancasellapro/s2s')->checkTransaction($order);
                }
            }

            // Stop store emulation process
            $appEmulation->stopEnvironmentEmulation($initialEnvironmentInfo);
        }
    }

    /**
     * Metodo che si occupa dell'esecuzione dei pagamenti per i profili ricorrenti
     */
    public function chargeRecurringProfiles(){

        //recuperare tutte i profili attivi da eseguire
        $recurringProfieles = Mage::getModel('sales/recurring_profile')
            ->getCollection()
            ->addFieldToFilter('method_code', EasyNolo_BancaSellaPro_Model_Gestpay::METHOD_CODE)
            ->addFieldToFilter('state', Mage_Sales_Model_Recurring_Profile::STATE_ACTIVE)
            ->addFieldToFilter('start_datetime',array('lteq' => Varien_Date::now(true)));

        /** @var EasyNolo_BancaSellaPro_Helper_Data $_helper */
        $_helper = Mage::helper('easynolo_bancasellapro');
        $_helper->log('Cron per il pagamento dei reccuring profile. Ci sono '.count($recurringProfieles).' profili da analizzare');

        foreach($recurringProfieles as $recurringProfile){

            //metodo per deserializzare i dati all'interno del profilo
            $recurringProfieles->getResource()->unserializeFields($recurringProfile);

            //recupero il metodo di pagamento, è certo che è gestpay perché è uno dei criteri della query sopra
            $methodInstance = Mage::helper('payment')->getMethodInstance($recurringProfile->getMethodCode());
            $info = Mage::getModel('payment/info');

            $methodInstance->submitRecurringProfile($recurringProfile, $info);

        }
    }

    public function saveFingerPrint($event){
        $order = $event->getOrder();
        if($payment = Mage::app()->getRequest()->getParam('payment')) {
            if(isset($payment['blackBox']) && $fingerPrint = $payment['blackBox']) {
                $fp = Mage::getModel('easynolo_bancasellapro/sales_order_fingerPrint');
                $fp->setData('order_id', $order->getId());
                $fp->setData('finger_print', $fingerPrint);
                $fp->save();
            }
        }
        return $this;
    }

} 