<?php
/**
 * Created by PhpStorm.
 * User: maintux
 * Date: 18/01/17
 * Time: 17:48
 */ 
class EasyNolo_BancaSellaPro_Helper_AlternativePayments_Sofort extends Mage_Core_Helper_Abstract {

    public function getEncryptParams(Mage_Sales_Model_Order $order){

        $billing_address = $order->getBillingAddress();

        $params = array('OrderDetails' => array('CustomerDetail' => array(), 'BillingAddress' => array()));

        $params['OrderDetails']['CustomerDetail']['FirstName'] = $order->getCustomerFirstname();
        $params['OrderDetails']['CustomerDetail']['Lastname'] = $order->getCustomerLastname();
        $params['OrderDetails']['CustomerDetail']['PrimaryEmail'] = $order->getCustomerEmail();
        $params['OrderDetails']['BillingAddress']['CountryCode'] = $billing_address->getCountryModel()->getIso2Code();

        return $params;
    }

}