<?php

abstract class EasyNolo_BancaSellaPro_Checkout_OnepageController_Abstract extends Mage_Checkout_OnepageController {}