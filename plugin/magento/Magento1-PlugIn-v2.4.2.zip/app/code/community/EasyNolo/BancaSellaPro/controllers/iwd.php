<?php

abstract class EasyNolo_BancaSellaPro_Checkout_OnepageController_Abstract extends IWD_Opc_Checkout_OnepageController {}