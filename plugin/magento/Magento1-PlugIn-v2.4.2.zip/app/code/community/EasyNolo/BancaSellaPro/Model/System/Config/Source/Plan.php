<?php
/**
 * Created by PhpStorm.
 * User: caccia
 * Date: 30/07/17
 * Time: 14.19
 */
class EasyNolo_BancaSellaPro_Model_System_Config_Source_Plan{

    public function toOptionArray()
    {
        return array(
            array(
                'value' => EasyNolo_BancaSellaPro_Helper_Data::PLAN_STARTER,
                'label' => Mage::helper('easynolo_bancasellapro')->__('Starter')
            ),
            array(
                'value' => EasyNolo_BancaSellaPro_Helper_Data::PLAN_UNLIMITED,
                'label' => Mage::helper('easynolo_bancasellapro')->__('Professional/Unlimited')
            )
        );
    }

}