<?php

class EasyNolo_BancaSellaPro_Block_AlternativePayments_Info extends Mage_Core_Block_Template
{

}