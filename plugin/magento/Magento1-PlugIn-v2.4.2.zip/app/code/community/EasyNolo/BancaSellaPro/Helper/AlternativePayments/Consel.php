<?php

class EasyNolo_BancaSellaPro_Helper_AlternativePayments_Consel extends Mage_Core_Helper_Abstract implements EasyNolo_BancaSellaPro_Helper_AlternativePayments_Interface {

    public function getEncryptParams(Mage_Sales_Model_Order $order){
        $storeId = $order->getStoreId();

        $params = array();
        $params['Consel_MerchantPro'] = Mage::getStoreConfig('payment/gestpaypro_alternative_payments/consel_promocode', $storeId);
        return $params;
    }

}