<?php
/**
 * @category Bitbull
 * @package  Bitbull_BancaSellaPro
 * @author   Mirko Cesaro <mirko.cesaro@bitbull.it>
 */

class EasyNolo_BancaSellaPro_Helper_S2s extends EasyNolo_BancaSellaPro_Helper_Baseclient {

    protected $_webserviceClassName ='easynolo_bancasellapro/webservice_wss2s';

    const STATUS_REFUND_TOTAL  = 'refund_bancasella';

    const TRANSACTION_AUT = 'AUT';
    const TRANSACTION_MOV = 'MOV';
    const TRANSACTION_CAN = 'CAN';

    public function readTrxS2s($order)
    {
        $_helper = Mage::helper('easynolo_bancasellapro');
        $shopTransactionId = $_helper->getShopTransactionId($order);
        $_helper->log('check Transaction status ' . $shopTransactionId);

        //inizializza il webservice
        $webservice = $this->getInitWebservice();
        //imposta l'ordine
        $webservice->setOrder($order);

        if ($tokenShopLogin = Mage::getModel('easynolo_bancasellapro/gestpay')->getTransactionKeyMerchantID($order->getStoreId())) {
            $webservice->setData('shopLogin', $tokenShopLogin);
        }

        $webservice = $this->executeCallReadTrxS2S($webservice);

        return $webservice;
    }


    public function checkTransaction($order)
    {
        $_helper = Mage::helper('easynolo_bancasellapro');
        $shopTransactionId = $_helper->getShopTransactionId($order);
        $_helper->log('check Riskified status ' . $shopTransactionId);        

        $webservice = $this->readTrxS2s($order);

        if($webservice->getTransactionState() == self::TRANSACTION_CAN)
        {
            $this->_manageKOTransaction($order, $webservice);
        }
        else
        {
            switch ($webservice->getTransactionResult()) {

                case EasyNolo_BancaSellaPro_Model_Webservice_Wscryptdecrypt::TRANSACTION_RESULT_PENDING :
    
                    if ($order->getState() != Mage_Sales_Model_Order::STATE_PENDING_PAYMENT)
                    {
                        $this->_manageXXtransaction($order, $webservice);
                    }
                    break;
    
                case EasyNolo_BancaSellaPro_Model_Webservice_Wscryptdecrypt::TRANSACTION_RESULT_OK :
    
                    $this->_manageOKTransaction($order, $webservice);
                    break;
    
                case EasyNolo_BancaSellaPro_Model_Webservice_Wscryptdecrypt::TRANSACTION_RESULT_KO :
    
                    $this->_manageKOTransaction($order, $webservice);
                    break;
            }
        }
        

        return $this;
    }

    public function capturePayment($payment, $amount){
        $order = $payment->getOrder();
        $_helper= Mage::helper('easynolo_bancasellapro');
        $shopTransactionId = $_helper->getShopTransactionId($order);
        $_helper->log('richiesto capture per ordine '. $shopTransactionId);
        //inizializza il webservice
        $webservice = $this->getInitWebservice();
        //imposta l'ordine
        $webservice->setOrder($order);

        if ($tokenShopLogin = Mage::getModel('easynolo_bancasellapro/gestpay')->getTransactionKeyMerchantID($order->getStoreId())) {
            $webservice->setData('shopLogin', $tokenShopLogin);
        }

        $result = $this->executeCaptureS2S($webservice, $amount);
        if ($result->getTransactionResult() == "KO") {
            $payment->setIsTransactionPending(true);
            $message = $this->__('Capture amount of %s online failed: %s', $order->getBaseCurrency()->formatTxt($amount), $result->getErrorDescription());
            $order->addStatusHistoryComment($message, false);
            Mage::throwException($message);
        }

        return $this;
    }

    public function refundPayment($payment,$amount){
        $order = $payment->getOrder();
        $_helper= Mage::helper('easynolo_bancasellapro');
        $shopTransactionId = $_helper->getShopTransactionId($order);
        $_helper->log('richiesto refund per ordine '. $shopTransactionId);

        //inizializza il webservice
        $webservice = $this->getInitWebservice();

        //imposta l'ordine
        $webservice->setOrder($order);

        if ($tokenShopLogin = Mage::getModel('easynolo_bancasellapro/gestpay')->getTransactionKeyMerchantID($order->getStoreId())) {
            $webservice->setData('shopLogin', $tokenShopLogin);
        }

        if (!$webservice->getData('RefundReason')) {
            $refundReason = $this->__('Refund transaction');
            $webservice->setData('RefundReason', $refundReason);
        }

        $result = $this->executeRefundS2S($webservice,$amount);

        if($result->getTransactionResult() == "KO") {
            $payment->setIsTransactionPending(true);
            $message = $this->__('Refund amount of %s online failed: %s', $order->getBaseCurrency()->formatTxt($amount), $result->getErrorDescription());
            $order->addStatusHistoryComment($message, false);
            Mage::throwException($message);
        }

        return $this;
    }

    public function refundTokenizationPayment($payment, $webserviceResult){
        $amount = $webserviceResult->getAmount();
        $order = $payment->getOrder();
        $_helper= Mage::helper('easynolo_bancasellapro');
        $shopTransactionId = $_helper->getShopTransactionId($order);
        $_helper->log('richiesto refund per ordine '. $shopTransactionId);
        //inizializza il webservice
        $webservice = $this->getInitWebservice();
        //imposta l'ordine
        $webservice->setOrder($order);

        $webservice->setData('bankTransactionId', $webserviceResult->getData('bank_transaction_id'));

        $result = $this->executeVoidS2S($webservice);

        if($result->getTransactionResult() == "KO") {
            $payment->setIsTransactionPending(true);
            $message = $this->__('Refund amount of %s online failed: %s', $order->getBaseCurrency()->formatTxt($amount), $result->getErrorDescription());
            $order->addStatusHistoryComment($message, false);
            Mage::throwException($message);
        }

        return $this;
    }

    public function voidPayment($payment){
        $order = $payment->getOrder();
        $_helper= Mage::helper('easynolo_bancasellapro');
        $shopTransactionId = $_helper->getShopTransactionId($order);
        $_helper->log('richiesto annullamento per ordine '. $shopTransactionId);
        //inizializza il webservice
        $webservice = $this->getInitWebservice();
        //imposta l'ordine
        $webservice->setOrder($order);

        if ($tokenShopLogin = Mage::getModel('easynolo_bancasellapro/gestpay')->getTransactionKeyMerchantID($order->getStoreId())) {
            $webservice->setData('shopLogin', $tokenShopLogin);
        }

        $result = $this->executeVoidS2S($webservice);
        if($result->getTransactionResult() == "KO"){
            $payment->setIsTransactionPending(true);
            $message = $this->__('Void online failed: %s', $result->getErrorDescription());
            $order->addStatusHistoryComment($message, false);
            Mage::throwException($message);
        }

        return $this;
    }

    protected function executeCaptureS2S($webService,$amount){
        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToCallCaptureS2S($amount);

        $result = $client->callSettleS2S($param);

        $webService->setResponseCallSettleS2S($result);
        return $webService;
    }

    protected function executeRefundS2S($webService, $amount){
        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToCallRefundS2S($amount);

        $result = $client->callRefundS2S($param);

        $webService->setResponseCallRefundS2S($result);
        return $webService;
    }

    protected function executeVoidS2S($webService){
        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToCallDeleteS2S();

        $result = $client->callDeleteS2S($param);

        $webService->setResponseCallDeleteS2S($result);
        return $webService;
    }

    public function acceptPayment(Mage_Payment_Model_Info $payment){

        /* implementato per gestire accept su payment review a backend, in caso di capture non andato a buon fine*/
        return true;

    }
    public function denyPayment(Mage_Payment_Model_Info $payment)
    {
        return true;
    }

    public function execute3DPaymentS2S($webService, $order, $transactionKey, $paRes)
    {
        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToCall3DPaymentS2S($order, $transactionKey, $paRes);

        $result = $client->callPagamS2S($param);

        $webService->setResponseCallPagamS2S($result);
        // fix for callReadTrxS2s with bankTransactionId start
        $payment = $order->getPayment();
        $payment->setAdditionalData(serialize($webService->getData()));
        $payment->save();
        // fix for callReadTrxS2s with bankTransactionId end
        return $webService;
    }

    public function executeCallReadTrxS2S($webService)
    {
        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToCallReadTrxS2S();

        $result = $client->callReadTrxS2S($param);

        $webService->setResponseCallReadTrxS2S($result);

        return $webService;
    }

    private function _manageXXtransaction($order, $webservice)
    {
        if (Mage::getStoreConfig('payment/gestpaypro/log_order')) {
            $_helper = Mage::helper('easynolo_bancasellapro');
            $message = $this->__("Authorizing amount of %s is pending approval on gateway.", $order->getBaseCurrency()->formatTxt($order->getBaseGrandTotal()));
            //$order->setState(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT, true, $message);
            $order->setState(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT, Mage_Sales_Model_Order::STATE_PENDING_PAYMENT, $message);
            $_helper->log('Pagamento effettuato con bonifico bancario, verificare a mano la transazione');
            $waitMessage = $this->__("Payment attempt, gestpay status XX. Order status will be updated later. GestPay Transaction ID: %s, Gestpay Company: %s", $webservice->getBankTransactionID(), $webservice->getCompany());
            $order->addStatusHistoryComment($waitMessage);
        } else {
            $order->setState(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT);
            $status = $order->getConfig()->getStateDefaultStatus(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT);
            $order->setStatus($status);
        }
        $order->save();
    }

    private function _manageOKtransaction($order, $webservice)
    {
        if ($webservice->getRedResponseCode())
        {
            $this->_manageRedResponse($order, $webservice);
        }
        elseif ($webservice->getRiskResponseCode())
        {
            $this->_manageRiskifiedResponse($order, $webservice);
        }
        else
        {
            $this->_manageGenericResponse($order, $webservice);
        }
    }

    private function _manageKOTransaction($order, $webservice)
    {
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        $_helper= Mage::helper('easynolo_bancasellapro');

        $_helper->log('Pagamento non andato a buon fine. Cambio stato all\'ordine e salvo l\'id della transazione');
        $message = $this->__("Authorizing amount of %s is pending approval on gateway.", $order->getBaseCurrency()->formatTxt($order->getBaseGrandTotal()));
        $order->cancel();
        //$order->setState($method->getOrderStatusKoGestPay(), true, $message);
        //$order->setState($method->getOrderStatusKoGestPay($order->getStoreId()), $method->getOrderStatusKoGestPay($order->getStoreId()), $message);

        $message = $this->__("Payment attempt has been declined. GestPay Transaction ID: %s, Gestpay Company: %s", $webservice->getBankTransactionID(), $webservice->getCompany());
        if($paymentMethod = $webservice->getPaymentMethod()){
            $message .= " (".$paymentMethod.")";
        }

        $order->setData('state', $method->getOrderStatusKoGestPay($order->getStoreId()));
        $order->addStatusToHistory($method->getOrderStatusKoGestPay($order->getStoreId()));
        $order->addStatusHistoryComment($message);

        //$order->addStatusHistoryComment($message, $method->getOrderStatusKoGestPay());
        $order->save();
    }

    private function _manageRedResponse($order, $webservice)
    {
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        $_helper = Mage::helper('easynolo_bancasellapro');
        switch (strtoupper($webservice->getRedResponseCode())) {
            case 'ACCEPT':

                $this->_setOrderPaid($order, $webservice);
                break;

            case 'DENY':

                $status = $method->getRedConfigData('deny_order_status');
                $message = $this->__("Authorizing amount of %s is pending approval on gateway.", $order->getBaseCurrency()->formatTxt($order->getBaseGrandTotal()));
                $order->cancel();
                //$order->setState($method->getOrderStatusKoGestPay(), true, $message);
                //$order->setState($method->getOrderStatusKoGestPay($order->getStoreId()), $method->getOrderStatusKoGestPay($order->getStoreId()), $message);

                $message = $this->__("Payment attempt has been declined by RED. GestPay Transaction ID: %s", $webservice->getBankTransactionID());
                if($paymentMethod = $webservice->getPaymentMethod()){
                    $message .= " (".$paymentMethod.")";
                }

                $order->setData('state', $method->getOrderStatusKoGestPay($order->getStoreId()));
                $order->addStatusToHistory($status);
                

                $order->addStatusHistoryComment($message, $status);
                $order->save();
                break;

            case 'CHALLENGE':

                $status = $method->getRedConfigData('challenge_order_status');

                if ($status != $order->getStatus() || Mage::getStoreConfig('payment/gestpaypro/log_order')) {
                    $_helper->log('Pagamento effettuato correttamente ma il check RED è risultato \'' . $webservice->getRedResponseCode() . '\'. Cambio stato all\'ordine e salvo l\'id della transazione');
                    $message = $this->__("Authorization approved on gateway but RED return with '%s' status. GestPay Transaction ID: %s", $webservice->getRedResponseCode(), $webservice->getBankTransactionID());
                    if ($paymentMethod = $webservice->getPaymentMethod()) {
                        $message .= " (" . $paymentMethod . ")";
                    }
                    $payment->setAdditionalData(serialize($webservice->getData()))
                        ->setTransactionAdditionalInfo(array(Mage_Sales_Model_Order_Payment_Transaction::RAW_DETAILS => $webservice->getData()), "");
                    $payment->setTransactionId($webservice->getShopTransactionId())
                        ->setCurrencyCode($order->getBaseCurrencyCode())
                        ->setIsTransactionClosed(0)
                        ->registerPaymentReviewAction(Mage_Sales_Model_Order_Payment::REVIEW_ACTION_UPDATE, false);


                    if (Mage::getStoreConfig('payment/gestpaypro/log_order')) {
                        $order->setState(Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW, $status, $message);
                    } else {
                        $order->setState(Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW);
                        $order->setStatus($status);
                    }

                    $order->save();
                }

                break;
        }

    }

    private function _manageRiskifiedResponse($order, $webservice)
    {
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        $_helper = Mage::helper('easynolo_bancasellapro');
        switch (strtolower($webservice->getRiskResponseCode())) {

            case 'approved':
            case 'captured':

                $this->_setOrderPaid($order, $webservice);

                break;

            case 'declined':

                $status = $method->getRiskifiedConfigData('declined_order_status');

                $message = $this->__("Authorizing amount of %s is pending approval on gateway.", $order->getBaseCurrency()->formatTxt($order->getBaseGrandTotal()));
                $order->cancel();
                //$order->setState($method->getOrderStatusKoGestPay(), true, $message);
                //$order->setState($method->getOrderStatusKoGestPay($order->getStoreId()), $method->getOrderStatusKoGestPay($order->getStoreId()), $message);

                $message = $this->__("Payment attempt has been declined by riskified. GestPay Transaction ID: %s", $webservice->getBankTransactionID());
                if($paymentMethod = $webservice->getPaymentMethod()){
                    $message .= " (".$paymentMethod.")";
                }

                $order->setData('state', $method->getOrderStatusKoGestPay($order->getStoreId()));
                $order->addStatusToHistory($status);

                $order->addStatusHistoryComment($message, $status);
                $order->save();
                break;

            case 'submitted':
            case 'created':

                $status = $method->getRiskifiedConfigData('submitted_order_status');
                if ($status != $order->getStatus() || Mage::getStoreConfig('payment/gestpaypro/log_order')) {
                    $_helper->log('Pagamento effettuato correttamente ma il check Riskified è risultato \'' . $webservice->getRiskResponseCode() . '\'. Cambio stato all\'ordine e salvo l\'id della transazione');
                    $message = $this->__("Authorization approved on gateway but Riskified return with '%s' status. Response description: %s. GestPay Transaction ID: %s", $webservice->getRiskResponseCode(), $webservice->getRiskResponseDescription(), $webservice->getBankTransactionID());
                    if ($paymentMethod = $webservice->getPaymentMethod()) {
                        $message .= " (" . $paymentMethod . ")";
                    }
                    $payment->setAdditionalData(serialize($webservice->getData()))
                        ->setTransactionAdditionalInfo(array(Mage_Sales_Model_Order_Payment_Transaction::RAW_DETAILS => $webservice->getData()), "");
                    $payment->setTransactionId($webservice->getShopTransactionId())
                        ->setCurrencyCode($order->getBaseCurrencyCode())
                        ->setIsTransactionClosed(0)
                        ->registerPaymentReviewAction(Mage_Sales_Model_Order_Payment::REVIEW_ACTION_UPDATE, false);

                    if (Mage::getStoreConfig('payment/gestpaypro/log_order')) {
                        $order->setState(Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW, $status, $message);
                    } else {
                        $order->setState(Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW);
                        $order->setStatus($status);
                    }

                    $order->save();
                }

                break;
        }

    }

    private function _manageGenericResponse($order, $webservice)
    {
        $this->_setOrderPaid($order, $webservice);
    }

    private function _setOrderPaid($order, $webservice)
    {
        $_helper= Mage::helper('easynolo_bancasellapro');
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        $_helper->log('Pagamento effettuato correttamente. Cambio stato all\'ordine e salvo l\'id della transazione');

        $message = $this->__("Authorization approved on gateway. GestPay Transaction ID: %s, Gestpay Company: %s", $webservice->getBankTransactionID(), $webservice->getCompany());
        if($paymentMethod = $webservice->getPaymentMethod()){
            $message .= " (".$paymentMethod.")";
        }

        $state = $method->getOrderStatusOkGestPay($order->getStoreId());
        $status = $method->getOrderStatusOkGestPay($order->getStoreId());

        $order->addStatusHistoryComment($message, $status);

        // create the authorization transaction
        $webservice->unsetData('alternativePayments');
        $payment->setAdditionalData(serialize($webservice->getData()));

        $payment->setTransactionAdditionalInfo(array(Mage_Sales_Model_Order_Payment_Transaction::RAW_DETAILS => $webservice->getData()), "");
        $payment->setTransactionId($webservice->getShopTransactionId());
        $payment->setCurrencyCode($order->getBaseCurrencyCode());
        $payment->setIsTransactionClosed(0);
        $payment->registerAuthorizationNotification($order->getBaseGrandTotal());
        
        $order->save();
        $message = '';
        $_helper->log('Authorized amount is :'. $order->getBaseGrandTotal());
        $_helper->log('Order base currency code on authorize: '. $order->getBaseCurrencyCode());
        $_helper->log('Order currency code on authorize: '. $order->getOrderCurrencyCode());
        if($webservice->getTransactionState() == self::TRANSACTION_MOV)
        {
            if($method->getConfigPaymentAction() == Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE_CAPTURE)
            {
                if ($method->getUseS2sApiForSalesActions()) {
                    $payment->registerCaptureNotification($order->getBaseGrandTotal());
                    $payment->setIsTransactionClosed(1);                    
                }
            }
        }
        else
        {
            // reload the order and the related payment entities
            // $order = Mage::getModel('sales/order')->load($order->getId());
            // $payment = $order->getPayment();

            // perform the capture
            if($method->getConfigData('payment_action', $order->getStoreId()) == Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE_CAPTURE) {
                // capture online if enabled
                if($method->getUseS2sApiForSalesActions($order->getStoreId())){
                    try{
                        $payment->capture(null);
                        $order->save();
                        $message = $this->__("Payment attempt has been approved. GestPay Transaction ID: %s , Gestpay Company: %s", $webservice->getBankTransactionID(), $webservice->getCompany());
                        if($paymentMethod = $webservice->getPaymentMethod()){
                            $message .= " (".$paymentMethod.")";
                        }
                    }catch(Exception $e){
                        $message = $this->__("Failed capture online: %s", $e->getMessage());  
                        $state = Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW;
                        $status = Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW;
                    }
                }
            }
        }

        $order->setData('state', $state);
        $order->addStatusToHistory($status);
        if($message != '')
        {
            $order->addStatusHistoryComment($message);
        }
        
        //$payment->save();
        $order->save();

        if (!$order->getEmailSent()) {
            $order->sendNewOrderEmail();
        }

        return $order;

    }

    public function getMyBankList($quote){
        $storeId = $quote->getStoreId();
        $webservice = $this->getInitWebservice();
        $client = $this->_initClient($webservice);
        if(!$client){
            return false;
        }
        $param = array();
        $gestpay = Mage::getModel('easynolo_bancasellapro/gestpay');
        $param['shopLogin'] = $gestpay->getMerchantId($storeId);
        if($gestpay->getLanguage($storeId)!=0){
            $param['languageId'] = $gestpay->getLanguage($storeId);
        }
        $result = $client->CallMyBankListS2S($param);
        $webservice->setResponseCallMyBankListS2S($result);
        return $webservice;
    }
} 