<?php

class EasyNolo_BancaSellaPro_Block_Cart_Totals extends Mage_Checkout_Block_Cart_Totals
{
    public function needDisplayBaseGrandtotal()
    {
        return false;
    }
}