<?php

class EasyNolo_BancaSellaPro_Helper_AlternativePayments_Mybank extends Mage_Core_Helper_Abstract implements EasyNolo_BancaSellaPro_Helper_AlternativePayments_Interface {

    public function getEncryptParams(Mage_Sales_Model_Order $order){
        $storeId = $order->getStoreId();

        $params = array();
        $method = $order->getPayment()->getMethodInstance();
        $additionalData = $method->getInfoInstance()->getAdditionalData();
        $additionalData = @unserialize($additionalData);
        if (isset($additionalData['mybank_bank_code'])) {
            $params['paymentTypeDetail']['MyBankBankCode'] = trim($additionalData['mybank_bank_code']);
        }
        return $params;
    }

    public function getBankList($quote){
        $helper = Mage::helper('easynolo_bancasellapro');
        $s2sHelper = Mage::helper('easynolo_bancasellapro/S2s');
        $getMyBankList = $s2sHelper->getMyBankList($quote);
        $html = '';
        if($getMyBankList->getTransactionResult() == "OK") {
            $bankList = json_decode(json_encode((array)$getMyBankList->getBankList()), TRUE);
            $bankList = array_filter($bankList['Bank']);
            if(count($bankList) > 0) {
                foreach($bankList as $bank){
                    $html .= '<option value="'.$bank['BankCode'].'">'.$bank['BankName'].'</option>';
                }
            }
        }
        return $html;
    }

}