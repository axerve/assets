<?php
/**
 * @category EasyNolo
 * @package  EasyNolo_BancaSellaPro
 * @author   Easy Nolo <ecommerce@sella.it>
 */

class EasyNolo_BancaSellaPro_Helper_Crypt extends EasyNolo_BancaSellaPro_Helper_Baseclient{

    protected $_webserviceClassName ='easynolo_bancasellapro/webservice_wscryptdecrypt';

    protected $_shopLogin  = '';

    /**
     * Effettua l'encypt dei dati memorizzati nel webserice
     * @param $webService contiene le info da criptare
     *
     * @return string stringa criptata
     */
    protected function getEncryptString($webService){

        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToEncrypt();

        $result = $client->Encrypt($param);

        $webService->setResponseEncrypt($result);

        $_helper= Mage::helper('easynolo_bancasellapro');

        $_helper->log('Encrypt string: ' .$webService->getCryptDecryptString());

        return $webService->getCryptDecryptString();

    }

    public function getShopLogin()
    {
        return $this->_shopLogin;
    }

    /**
     * Funzione che dall'ordine restituisce la stringa criptata delle sue info
     * @param $order ordine da criptare
     *
     * @return mixed stringa criptate
     */
    public function getEncryptStringByOrder($order) {
        $method = $order->getPayment()->getMethodInstance();        

        /** @var $webService EasyNolo_BancaSellaPro_Model_Webservice_Wscryptdecrypt  */
        $webService = Mage::getModel('easynolo_bancasellapro/webservice_wscryptdecrypt');
        $webService->setOrder($order);
        $webService->setPaymentInfo($order);
        $webService->setBaseUrl($method->getBaseWSDLUrlSella());

        $this->_shopLogin = $webService->getData('shopLogin');

        return $this->getEncryptString($webService);
    }

    /**
     * @param $method EasyNolo_BancaSellaPro_Model_Gestpay
     *
     * @return string
     */
    public function  getEncryptStringBeforeOrder ($method){
        /** @var EasyNolo_BancaSellaPro_Model_Webservice_Wscryptdecrypt $webService */
        $webService = Mage::getModel('easynolo_bancasellapro/webservice_wscryptdecrypt');

        $webService->setInfoBeforeOrder($method);
        $webService->setBaseUrl($method->getBaseWSDLUrlSella());

        $this->_shopLogin = $webService->getData('shopLogin');

        return $this->getEncryptString($webService);
    }


    /**
     * funzione che si occupa di decriptare i dati ricevuti da gestpay
     * @param $webService
     *
     * @return mixed
     */
    public function decryptPaymentRequest($webService){

        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToDecrypt();

        $result = $client->Decrypt($param);

        $webService->setResponseDecrypt($result);

        return $webService;

    }

    public function isPaymentOk($a, $b ){
        $_helper= Mage::helper('easynolo_bancasellapro');

        $webService =$this->getInitWebservice();

        $webService->setDecryptParam($a , $b);

        $result = $this->decryptPaymentRequest($webService);

        if(!$result){
            return false;
        }

        $orderId = $_helper->getIncrementIdByShopTransactionId($webService->getShopTransactionID());
        /** @var Mage_Sales_Model_Order $order */

        $order = Mage::getModel('sales/order')->loadByIncrementId($orderId);
        //salvo lo store per effettuare il redirect a completamento della verifica
        Mage::register('easynolo_bancasellapro_store_maked_order', $order->getStore());
        Mage::register('easynolo_bancasellapro_order', $order);

        $gestpay = Mage::getModel('easynolo_bancasellapro/gestpay');

        if($order->getId()){
            // fix for callReadTrxS2s with bankTransactionId start
            $payment = $order->getPayment();
            $new_additional_data = $result->getData();
            if(!empty($payment->getAdditionalData())) {
                $existing_additional_data = unserialize($payment->getAdditionalData());
                if(is_array($existing_additional_data)) {
                    $new_additional_data = array_merge($existing_additional_data, $result->getData()); // Not merging right now
                } 
            }
            $payment->setAdditionalData(serialize($new_additional_data));
            $payment->save();
            // fix for callReadTrxS2s with bankTransactionId end
            $isCustomerloggedIn = Mage::getSingleton('customer/session')->isLoggedIn();
            if(!$isCustomerloggedIn && !$order->getCustomerIsGuest() && $order->getCustomerId()) {
                $_helper->log('login customer from order in crypt');
                $customer_id = $order->getCustomerId();
                $customer = Mage::getModel('customer/customer')->load($customer_id);
                // Log the customer in
                $session = Mage::getSingleton('customer/session')->setCustomerAsLoggedIn($customer);
            }
            $checkoutSession = Mage::getSingleton('checkout/session');
            if(!$checkoutSession->getLastRealOrderId()) {
                $checkoutSession->setLastRealOrderId($order->getIncrementId());
            }
            if(!$checkoutSession->getLastQuoteId()) {
                $checkoutSession->setLastQuoteId($order->getQuoteId());
            }
            if(!$checkoutSession->getLastOrderId()) {
                $checkoutSession->setLastOrderId($order->getId());
            }
            if($webService->getFastResultPayment()){
                $_helper->log('Il web service ha dato esito positivo al pagamento');

                //controllo se la richiesta s2s è già stata elaborata
                if (!$_helper->isElaborateS2S($order)) {
                    $_helper->log('La transazione non è ancora stata inviata sul s2s');

                    //in questo punto l'utente ha completato l'ordine ma aspettiamo la chiamata s2s per confermare lo stato
                    if($order->getId()){

                        $message = $this->__("Authorizing amount of %s is pending approval on gateway.", $order->getBaseCurrency()->formatTxt($order->getBaseGrandTotal()));
                        if ($gestpay->isUseTransactionKeyEnabled($order->getStoreId())){
                            if ($gestpay->getMerchantID() == $a && $webService->getAmount() == EasyNolo_BancaSellaPro_Helper_TransactionKey::PREAUTH_AMOUNT) {
                                $message = $this->__("Card tokenization (with an authorization of %s)", $order->getBaseCurrency()->formatTxt($webService->getAmount()));
                            }

                            if ($token = Mage::helper('easynolo_bancasellapro')->saveToken($order, $webService)) {
                                if (!Mage::helper('easynolo_bancasellapro/transactionKey')->processWithTransactionKey($order, $webService, $token)) {
                                    $order->cancel();

                                    $message = $this->__("Payment attempt has been declined.");
                                    $cancel = true;
                                }
                            }

                            $order->addStatusHistoryComment($message);
                        }

                        if (empty($cancel)) {
                            $order = $this->setStatusOrderByS2SRequest($order, $webService);

                            if ($order->getStatus() == $gestpay->getOrderStatusOkGestPay()) {
                                if(!$order->getEmailSent()){
                                    $order->sendNewOrderEmail();
                                }
                            }
                        }

                        $order->save();
                    }
                } else {
                    $_helper->log('La tranzazione è gia stata salvata, non cambio lo stato');

                    //$order = $this->setStatusOrderByS2SRequest($order, $webService);
                    if ($order->getStatus() == $gestpay->getOrderStatusOkGestPay()) {
                        if(!$order->getEmailSent()){
                            $order->sendNewOrderEmail();
                        }
                    } else if ($order->getStatus() == $gestpay->getOrderStatusKoGestPay()) {
                        $message = $this->__("There was an error processing your order. Please contact us or try again later.");
                        $cancel = true;
                    }
                    $order->save();
                }

                if (empty($cancel)) {
                    if(!$checkoutSession->getLastSuccessQuoteId()) {
                        $checkoutSession->setLastSuccessQuoteId($checkoutSession->getLastQuoteId());
                    }
                    return true;
                } else {
                    return $message;
                }
            } else {
                $_helper->log('Il web service ha restituito KO');
                $message = $this->__('Payment transaction not authorized: %s.', $result->getErrorDescription());
                //in questo punto l'ordine è stato annullato dall'utente
                if($order->getId()) {
                    $this->_declineOrderPayment($order, $result);
                }

                return $message;
            }
        }else{
            $message = $this->__("There was an error processing your order. Please contact us or try again later.");
            $_helper->log('L\'ordine restituito da bancasella non esiste. Increment id= '.$orderId);
            return $message;
        }
    }

    public function getInitWebservice(){
        $webService = Mage::getModel('easynolo_bancasellapro/webservice_wscryptdecrypt');
        $gestPay=Mage::getModel('easynolo_bancasellapro/gestpay');
        $webService->setBaseUrl($gestPay->getBaseWSDLUrlSella());

        return $webService;
    }

    public function setStatusOrderByS2SRequest($order, $webservice){
        $linkedOrder = $order;
        $order = Mage::getModel('sales/order')->load($order->getId());
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        $_helper= Mage::helper('easynolo_bancasellapro');
        $_helper->log('Controllo l\'ordine in base alle risposte della S2S');

        if($method->getConfigData('order_status_fraud_gestpay', $order->getStoreId())){
            if (!$method->getConfigData('use_transactionkey', $order->getStoreId()) ||
                abs($webservice->getAmount() - EasyNolo_BancaSellaPro_Helper_TransactionKey::PREAUTH_AMOUNT) > 0.001) {

                $_helper->log('Controllo frode');

                $message = false;
                $total = $method->getTotalByOrder($order);

                $_helper->log('controllo il totale dell\'ordine : ' . $webservice->getAmount() . ' = ' . round($total, 2));
                if (round($webservice->getAmount(), 2) != round($total, 2)) {
                    $vs = '(' . round($webservice->getAmount(), 2) . ' vs ' . round($total, 2) . ')';
                    // il totatle dell'ordine non corrisponde al totale della transazione
                    $message = $this->__('Transaction amount differs from order grand total. ' . $vs);
                }

                if ($webservice->getAlertCode() != '' & $webservice->getAlertCode() != 0) {
                    $_helper->log('controllo alert della transazione : ' . $webservice->getAlertCode());
                    $message = $webservice->getAlertDescription();
                }

                if ($message) {
                    $_helper->log('rilevata possibile frode: ' . $message);
                    $payment->setTransactionAdditionalInfo(array(Mage_Sales_Model_Order_Payment_Transaction::RAW_DETAILS => $webservice->getData()), "");
                    $payment->setTransactionId($webservice->getShopTransactionId())
                        ->setCurrencyCode($order->getBaseCurrencyCode())
                        ->setIsTransactionClosed(0)
                        ->setPreparedMessage($message)
                        ->registerPaymentReviewAction(Mage_Sales_Model_Order_Payment::REVIEW_ACTION_UPDATE, false);
                    $order->setState(Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW, Mage_Sales_Model_Order::STATUS_FRAUD, $message);
                    $order->save();
                    return $order;
                }
            }
        }

        if($method->getConfigData('plan') == EasyNolo_BancaSellaPro_Helper_Data::PLAN_STARTER)
        {
            switch ($webservice->getTransactionResult())
            {
                case EasyNolo_BancaSellaPro_Model_Webservice_Wscryptdecrypt::TRANSACTION_RESULT_OK :
                    $this->_authorizeOrderPayment($order, $webservice);
                    break;
                case EasyNolo_BancaSellaPro_Model_Webservice_Wscryptdecrypt::TRANSACTION_RESULT_KO :
                    $this->_declineOrderPayment($order, $webservice);
                    break;
            }
        }
        else
        {
            Mage::helper('easynolo_bancasellapro/s2s')->checkTransaction($order);
        }
        
        $_order = Mage::getModel('sales/order')->load($order->getId());
        $_helper->log('Dopo l\'elaborazione della s2s l\'ordine con id: '.$_order->getIncrementId().' ha state: '.$_order->getState().' e status: '.$_order->getStatus());

        $linkedOrder->setData('state', $_order->getData('state'));
        $linkedOrder->setData('status', $_order->getData('status'));
        return $_order;
    }

    private function _authorizeOrderPayment($order, $webservice){
        $_helper= Mage::helper('easynolo_bancasellapro');
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();

        $_helper->log('Pagamento effettuato correttamente. Cambio stato all\'ordine e salvo l\'id della transazione');
        $message = $this->__("Authorization approved on gateway. GestPay Transaction ID: %s", $webservice->getBankTransactionID());
        if($paymentMethod = $webservice->getPaymentMethod()){
            $message .= " (".$paymentMethod.")";
        }    

        $payment->setOrder($order);

        // create the authorization transaction
        $payment->setAdditionalData(serialize($webservice->getData()));
        $payment->setTransactionAdditionalInfo(array(Mage_Sales_Model_Order_Payment_Transaction::RAW_DETAILS => $webservice->getData()), "");
        $payment->setTransactionId($webservice->getShopTransactionId());
        $payment->setCurrencyCode($order->getBaseCurrencyCode());
        $payment->setIsTransactionClosed(0);
        $payment->registerAuthorizationNotification($order->getBaseGrandTotal());

        $state = $method->getOrderStatusOkGestPay($order->getStoreId());
        $status = $method->getOrderStatusOkGestPay($order->getStoreId());        

        $order->setState($state, $status, $message);

        $order->save();
    }

    private function _declineOrderPayment($order, $webservice){
        $_helper= Mage::helper('easynolo_bancasellapro');
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();

        $_helper->log('Pagamento non andato a buon fine. Cambio stato all\'ordine e salvo l\'id della transazione');      

        $message = $this->__("Authorization was not approved. GestPay Transaction ID: %s", $webservice->getBankTransactionID());

        if($paymentMethod = $webservice->getPaymentMethod()){
            $message .= " (".$paymentMethod.")";
        }

        $order->cancel();

        $state = $method->getOrderStatusKoGestPay($order->getStoreId());
        $status = $method->getOrderStatusKoGestPay($order->getStoreId());
        $order->setState($state, $status, $message);

        
        $order->save();
    }
}