<?php
/**
 * @category EasyNolo
 * @package  EasyNolo_BancaSellaPro
 * @author   Easy Nolo <ecommerce@sella.it>
 */
class EasyNolo_BancaSellaPro_GestpayController extends Mage_Core_Controller_Front_Action {

    private $_order, $_profile;

    private function getOrder()
    {
        if ($this->_order == null) {
            $session = Mage::getSingleton('checkout/session');
            $this->_order = Mage::getModel('sales/order');
            $this->_order->loadByIncrementId($session->getLastRealOrderId());
        }
        return $this->_order;
    }

    // This action is used to retrieve the EncryptedString via Ajax call when iFrame is enabled
    public function getEncryptedStringAction() {
        if ($cvv = $this->getRequest()->getParam('cvv')) {
            Mage::getSingleton('checkout/session')->setData('gestpay_cvv', $cvv);
        }
        $crypt = Mage::helper('easynolo_bancasellapro/crypt');
        $this->getResponse()->setHeader('Content-type','application/json', true);

        $result = array('b'=>$crypt->getEncryptStringByOrder($this->getOrder()), 'a'=>$crypt->getShopLogin());

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
    }

    public function postCvvAction(){
        Mage::getSingleton('checkout/session')->setData('gestpay_cvv', $this->getRequest()->getParam('cvv'));
        $this->getResponse()->setBody('ok');
    }

    public function updateCustomerAddressAction(){

        $street = (array)$this->getRequest()->getPost('street');
        $id = $this->getRequest()->getPost('id');

        if ($id && $street && Mage::getSingleton('customer/session')->isLoggedIn()) {
            foreach (Mage::getSingleton('customer/session')->getCustomer()->getAddresses() as $address) {
                if ($address->getId() == $id) {
                    $address->setStreet($street)->save();
                    break;
                }
            }
        }

        $this->getResponse()->setBody('ok');
    }

    public function redirectAction(){
        $order = $this->getOrder();

        if (!$order->getId()) {
            $this->norouteAction();
            return;
        }

        $order->addStatusHistoryComment($this->__('User correctly redirected to Banca Sella for completion of payment.'));
        $order->save();

        /** @var EasyNolo_BancaSellaPro_Helper_Data $_helper */
        $_helper= Mage::helper('easynolo_bancasellapro');
        $_helper->log('Reindirizzamento utente sul sito di bancasella dopo aver effettuato l\'ordine con id='.$order->getId());


        Mage::register('current_order', $order);

        try{

            $this->loadLayout();
            $this->renderLayout();

        }catch (Exception $e){
            $_helper->log($e->getMessage());
            $checkoutSession = Mage::getSingleton('checkout/session');
            $checkoutSession->addError($this->__('Payment has been declined. Please try again.'));
            // set order quote to active
            if ($lastQuoteId = $checkoutSession->getLastQuoteId()){
            	$quote = Mage::getModel('sales/quote')->load($lastQuoteId);
            	if ($quoteId = $quote->getId()) {
            		$quote->setIsActive(true);
            		$quote->setReservedOrderId(null);
            		$quote->save();
            		$checkoutSession->setQuoteId($quoteId);
            	}
            }
            
            $this->_redirect('checkout/cart');
            return;
        }
    }

    // This action is used by GestPay as return URL after payment on Banca Sella page
    public function resultAction(){

        $a = $this->getRequest()->getParam('a',false);
        $b = $this->getRequest()->getParam('b',false);

        $_helper= Mage::helper('easynolo_bancasellapro');
        $_helper->log('resultAction');
        $_helper->log('Is customer logged in or not in resutltAction entrance:'. Mage::getSingleton('customer/session')->isLoggedIn());          

        if(!$a || !$b){
            $this->_redirect('*/*/redirect');
            return;
        }

        Mage::register('bancasella_param_a', $a);
        Mage::register('bancasella_param_b', $b);

        /** @var EasyNolo_BancaSellaPro_Helper_Crypt $helper */
        $helper= Mage::helper('easynolo_bancasellapro/crypt');

        $checkoutSession = Mage::getSingleton('checkout/session');
        $paymentCheckResult = $helper->isPaymentOk( $a , $b );
        if($paymentCheckResult === true){
            $_helper->log('L\'utente ha completato correttamente l\'inserimento dei dati su bancasella');
            // reset quote on checkout session
            if ($lastQuoteId = $checkoutSession->getLastQuoteId()){
                $quote = Mage::getModel('sales/quote')->load($lastQuoteId);
                if ($quoteId = $quote->getId()) {
                    $quote->setIsActive(false)->save();
                    $checkoutSession->setQuoteId(null);
                }
            }

            $redirect ='checkout/onepage/success';
        }
        else{
            $_helper->log('L\'utente ha annullato il pagamento, oppure qualche dato non corrisponde');
            // set order quote to active
            if ($lastQuoteId = $checkoutSession->getLastQuoteId()){
                $quote = Mage::getModel('sales/quote')->load($lastQuoteId);
                if ($quoteId = $quote->getId()) {
                    $quote->setIsActive(true);
                    $quote->setReservedOrderId(null);
                    $quote->save();
                    $checkoutSession->setQuoteId($quoteId);
                }
            }

            $checkoutSession->addError($paymentCheckResult);
            $redirect = 'checkout/cart';
        }

        //se è impostato lo store allora reindirizzo l'utente allo store corretto
        $store= Mage::registry('easynolo_bancasellapro_store_maked_order');
        $_helper->log('redirect url in resutltAction :'. $redirect);
        $_helper->log('Is customer logged in or not in resutltAction exit:'. Mage::getSingleton('customer/session')->isLoggedIn());          
        if($store && $store->getId()){
            $_helper->log('storeid url in resutltAction :'. $store->getId());
            Mage::app()->setCurrentStore($store->getId());
        }
        $this->_redirect($redirect);

        return $this;
    }

    // This function is used by GestPay to notify payment callbacks
    public function s2sAction(){
        $a = $this->getRequest()->getParam('a',false);
        $b = $this->getRequest()->getParam('b',false);
        /** @var EasyNolo_BancaSellaPro_Helper_Data $_helper */

        $_helper= Mage::helper('easynolo_bancasellapro');
        $_helper->log('s2sAction');

        if(!$a || !$b){
            $_helper->log('Richiesta S2S, mancano i parametri di input');
            $this->norouteAction();
            return;
        }

        Mage::register('bancasella_param_a', $a);
        Mage::register('bancasella_param_b', $b);

        /** @var EasyNolo_BancaSellaPro_Helper_Crypt $helper */
        $helper= Mage::helper('easynolo_bancasellapro/crypt');

        $webservice = $helper->getInitWebservice();

        $webservice->setDecryptParam($a, $b);
        $helper->decryptPaymentRequest ($webservice);

        $orderId = $_helper->getIncrementIdByShopTransactionId($webservice->getShopTransactionID());
        $order = Mage::getModel('sales/order')->loadByIncrementId($orderId);

        $payment = $order->getPayment();
        $method = Mage::getModel('easynolo_bancasellapro/gestpay');

        if($order->getId()){
            if (Mage::app()->getStore()->getId() != $order->getStoreId()) {
                $appEmulation = Mage::getSingleton('core/app_emulation');
                $initialEnvironmentInfo = $appEmulation->startEnvironmentEmulation($order->getStoreId());
            }

            $_helper->log('Imposto lo stato dell\'ordine in base al decrypt');
            $token = Mage::helper('easynolo_bancasellapro')->saveToken($order, $webservice);

            if (!Mage::helper('easynolo_bancasellapro/transactionKey')->refundTransactionAuth($order, $webservice, $token)) {
                if ($order->getStatus() != $method->getOrderStatusOkGestPay()) {
                    $order = $helper->setStatusOrderByS2SRequest($order, $webservice);

                    if ($order->getStatus() == $method->getOrderStatusOkGestPay()) {
                        if(!$order->getEmailSent()){
                            $order->sendNewOrderEmail();
                        }
                    }
                }
            }

            if ($token && $order->getStatus() != $method->getOrderStatusKoGestPay()) {
                Mage::helper('easynolo_bancasellapro/recurringprofile')->checkAndSave($order, $webservice, $token);
            }

            if (!empty($initialEnvironmentInfo) && !empty($appEmulation)) {
                $appEmulation->stopEnvironmentEmulation($initialEnvironmentInfo);
            }
        } else {
            $_helper->log('La richiesta effettuata non ha un corrispettivo ordine. Id ordine= '.$webservice->getShopTransactionID());
        }

        //restiutisco una pagina vuota per notifica a GestPay
        $this->getResponse()->setBody('<html></html>');

        return;
    }

    // This function is used to check 3D payment using iframe
    public function confirm3dAction(){
        $_helper= Mage::helper('easynolo_bancasellapro');
        $_helper->log('Richiamata azione conferma 3dsecure');

        $order = $this->getOrder();
        $_helper->log('orderId in confirm3dAction'. $order->getId());
        if($order->getId()){
        	$order->addStatusHistoryComment($this->__('User is redirecting to issuing bank for 3d authentification.'));
        	$order->save();
        }
        
        $this->loadLayout();
        $this->renderLayout();
    }

    // This function is used to check 3D payment using S2S method (eg. when tokenization is enabled)
    public function confirm3dS2SAction(){
        $_helper = Mage::helper('easynolo_bancasellapro');
        if (empty($this->getRequest()->get('PaRes'))) {
            $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : false;
            $_helper->log('direct access restricted :'. $ip);
            echo "<h1>Oops!! Access restricted!</h1>"; exit;
        }
        $gestpay = Mage::getModel('easynolo_bancasellapro/gestpay');
        $checkoutSession = Mage::getSingleton('checkout/session');
        $_helper->log('Is customer logged in or not in confirm3dS2SAction entrance:'. Mage::getSingleton('customer/session')->isLoggedIn());          
        $orderIdFromUrl = $this->getRequest()->getParam("oid");
        if(!empty($orderIdFromUrl)) {
            $orderIdFromUrl = base64_decode($orderIdFromUrl); 
        }
        
        if(!$checkoutSession->getLastRealOrderId() && !empty($orderIdFromUrl)) {
            $_helper->log('orderid from url :'. $orderIdFromUrl);
            $checkoutSession->setLastRealOrderId($orderIdFromUrl);
        }
        $order = $this->getOrder();

        $isCustomerloggedIn = Mage::getSingleton('customer/session')->isLoggedIn();
        if(!$isCustomerloggedIn && !$order->getCustomerIsGuest() && $order->getCustomerId()) {
            $_helper->log('login customer from order');
            $customer_id = $order->getCustomerId();
            $customer = Mage::getModel('customer/customer')->load($customer_id);
            // Log the customer in
            $session = Mage::getSingleton('customer/session')->setCustomerAsLoggedIn($customer);
        }
        $_helper->log('orderid in confirm3dS2SAction :'. $order->getId());
        if($order->getId()){
            $order->addStatusHistoryComment($this->__('User is redirecting to issuing bank for 3d authentification.'));
            $transactionKey = Mage::getSingleton('checkout/session')->getGestpayTransactionKey();
            if(empty($transactionKey) && !empty($this->getRequest()->getParam("tkey"))) {
                $transactionKey = base64_decode($this->getRequest()->getParam("tkey"));
                $_helper->log('transaction key in url :'. $transactionKey);
            }
            $paRes = $this->getRequest()->get('PaRes');
            $paRes = $_helper->normalizePARes($paRes);
            $webservice = Mage::helper('easynolo_bancasellapro/s2s')->getInitWebservice();
            $result = Mage::helper('easynolo_bancasellapro/s2s')->execute3DPaymentS2S($webservice, $order, $transactionKey, $paRes);
            if(!$checkoutSession->getLastQuoteId()) {
                $checkoutSession->setLastQuoteId($order->getQuoteId());
            }
            if(!$checkoutSession->getLastOrderId()) {
                $checkoutSession->setLastOrderId($order->getId());
            }
            if(!$result->getTransactionResult() || $result->getTransactionResult() == 'KO') {
                if ($lastQuoteId = $checkoutSession->getLastQuoteId()){
                    $quote = Mage::getModel('sales/quote')->load($lastQuoteId);
                    if ($quoteId = $quote->getId()) {
                        $quote->setIsActive(true);
                        $quote->setReservedOrderId(null);
                        $quote->save();
                        $checkoutSession->setQuoteId($quoteId);
                    }
                }
                $checkoutSession->addError($result->getErrorDescription());
                $redirect = 'checkout/cart';
            } else {
                $helperDecrypt = Mage::helper('easynolo_bancasellapro/crypt');
                $helperDecrypt->setStatusOrderByS2SRequest($order, $webservice);
                if ($order->getStatus() == $gestpay->getOrderStatusOkGestPay()) {
                    if(!$order->getEmailSent()){
                        $order->sendNewOrderEmail();
                    }
                }
                $order->save();
                if(!$checkoutSession->getLastSuccessQuoteId()) {
                    $checkoutSession->setLastSuccessQuoteId($checkoutSession->getLastQuoteId()); // Required, otherwise getOrderId() is empty on success.phtml
                }
                // reset quote on checkout session
                if ($lastQuoteId = $checkoutSession->getLastQuoteId()){
                    $quote = Mage::getModel('sales/quote')->load($lastQuoteId);
                    if ($quoteId = $quote->getId()) {
                        $quote->setIsActive(false)->save();
                        $checkoutSession->setQuoteId(null);
                    }
                }
                $redirect ='checkout/onepage/success';
            } 

            $store = Mage::registry('easynolo_bancasellapro_store_maked_order');
            $_helper->log('redirect in confirm3dS2SAction :'. $redirect);  
            $_helper->log('Is customer logged in or not in confirm3dS2SAction exit:'. Mage::getSingleton('customer/session')->isLoggedIn());          
            if($store && $store->getId()){
                $_helper->log('storeid in confirm3dS2SAction :'. $store->getId());
                Mage::app()->setCurrentStore($store->getId());
            }
            $this->_redirect($redirect);
            return $this;
        }
    }

    protected function redirectInCorrectStore($store, $path, $arguments = array())
    {
        $params = array_merge(
            $arguments,
            array(
                '_use_rewrite' => false,
                '_store' => $store,
                '_store_to_url' => true,
                '_secure' => $store->isCurrentlySecure()
            ) );
        $url = Mage::getUrl($path,$params);

        $this->getResponse()->setRedirect($url);
        return;
    }


}