<?php


class EasyNolo_BancaSellaPro_Helper_TransactionKey extends EasyNolo_BancaSellaPro_Helper_Baseclient
{
    protected $_webserviceClassName = 'easynolo_bancasellapro/webservice_wss2s';

    const PREAUTH_AMOUNT = 0.01;

    /**
     * Method to process new token order when transactionKey used
     * @param Mage_Sales_Model_Order $order
     * @param $webservice
     */
    public function processWithTransactionKey(Mage_Sales_Model_Order $order, $webservice, $tokenInfo){
        if (!Mage::getModel('easynolo_bancasellapro/gestpay')->isUseTransactionKeyEnabled($order->getStoreId())) {
            return true;
        }

        if (!$tokenInfo || !$tokenInfo->getToken()) {
            return false;
        }

        $amount = $webservice->getAmount();

        if ($amount < 0.001) {
            return false;
        }

        try {
            $webservice = $this->getInitWebservice();
            //imposta l'ordine
            $webservice->setOrder($order);
            //imposta il token
            $webservice->setToken($tokenInfo);

            $amount = $webservice->getAmount();

            //effettua la chiamata
            $result = $this->executePaymentS2S($webservice);
            // fix for callReadTrxS2s with bankTransactionId start
            $payment = $order->getPayment();
            $payment->setAdditionalData(serialize($result->getData()));
            $payment->save();
            // fix for callReadTrxS2s with bankTransactionId end
            if ($result->getErrorCode()) {
                $message = $this->__('Capture amount of %s using token failed: (error code %s) %s', $order->getBaseCurrency()->formatTxt($amount), $result->getErrorCode(), $result->getErrorDescription());
                $order->addStatusHistoryComment($message, false);
                Mage::throwException($result->getErrorDescription());
            } else {
                $message = $this->__('Capture amount of %s using token successfully done', $order->getBaseCurrency()->formatTxt($amount));
                $order->addStatusHistoryComment($message,  Mage::getModel('easynolo_bancasellapro/gestpay')->getOrderStatusOkGestPay());

                return true;
            }
        } catch (Mage_Core_Exception $e) {
            Mage::logException($e);
        }

        return false;
    }

    /**
     * Method to refund tokenization auth
     * @param Mage_Sales_Model_Order $order
     * @param $webservice
     */
    public function refundTransactionAuth(Mage_Sales_Model_Order $order, $webservice, $tokenInfo){
        if (!Mage::getModel('easynolo_bancasellapro/gestpay')->isUseTransactionKeyEnabled()){
            return false;
        }

        if (!$tokenInfo || !$tokenInfo->getToken()) {
            return false;
        }

        $amount = $webservice->getAmount();
        if (abs($amount - self::PREAUTH_AMOUNT) > 0.001) {
            return false;
        }

        try {
            $helper = Mage::helper('easynolo_bancasellapro/s2s');
            $helper->refundTokenizationPayment($order->getPayment(), $webservice);

            $message = $this->__('Authorization of %s voided', $order->getBaseCurrency()->formatTxt($amount));
            $order->addStatusHistoryComment($message, false);
            $order->save();

            return true;
        } catch (Mage_Core_Exception $e) {
            Mage::logException($e);
        }

        return false;
    }

    public function executePaymentS2S($webService){
        $client = $this->_initClient($webService);
        if(!$client){
            return false;
        }

        $param = $webService->getParamToCallPagamS2S($webService->getAmount());

        $checkoutSession = Mage::getSingleton('checkout/session');
        if ($cvv = $checkoutSession->getData('gestpay_cvv')) {
            $param['cvv'] = $cvv;
        }

        $result = $client->callPagamS2S($param);

        $webService->setResponseCallPagamS2S($result);
        return $webService;
    }

    public function getMerchantId(){
        $gestpay = Mage::getModel('easynolo_bancasellapro/gestpay');
        /* if ($gestpay->isUseTransactionKeyEnabled()){
            return $gestpay->getTransactionKeyMerchantID();
        } */
        return $gestpay->getMerchantId();
    }
}